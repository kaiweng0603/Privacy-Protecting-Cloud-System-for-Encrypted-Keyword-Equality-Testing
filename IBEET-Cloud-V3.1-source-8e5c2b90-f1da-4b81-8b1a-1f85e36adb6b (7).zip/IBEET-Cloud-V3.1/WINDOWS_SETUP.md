# V3.1 Windows 設定

此交付是待補完整驗收的候選來源。先看 TEST_REPORT.md；目前環境拒絕 WSL、localhost 與 junction 夾具，不可把個別元件成功視為本機全流程已完成。

1. 將來源解壓至新的 IBEET-Cloud-V3.1 目錄，例如 C:\IBEET-Cloud-V3.1。不可放在 V1/V2/V3 內或經過符號連結／junction；保留 .ibeet-v31。不可複製舊 runtime、資料庫或金鑰。
2. 本機需有 PowerShell 7、Java 26、Node.js 24/npm 11、WSL Ubuntu-26.04 及已安裝的 gcc、make、PBC、GMP、OpenSSL、Python 3。腳本不修改全域設定或安裝系統套件。
3. 在本版根目錄執行 .\scripts\Build-V3.ps1 -InstallFrontendDependencies。首次 Maven/npm 可能需要網路取專案相依套件；只能在執行環境允許時進行，失敗即停止。快取位於本版 .cache，ZIP 不含快取。
4. 執行 .\scripts\Run-Validation.ps1；所有 C／Java／HTTP／前端檢查均通過，且沒有 skipped，才可評估展示。每次測試建立全新 .test-runs UUID；不要刪除或重設正式 runtime-v31 來測試。
5. 之後才執行 .\scripts\Initialize-V3.ps1。本人輸入 Alice/Bob/Admin 三組不同的 12–72 UTF-8 byte 密碼；沒有預設密碼。產生新的 32-byte root.key，先核對 NTFS ACL，再透過 stdin 初始化真實 C 金鑰及 BCrypt 帳號。任何現存 runtime-v31 都會被拒絕，不會覆寫。
6. 分開執行 Start-Backend.ps1 與 Start-Frontend.ps1，使用 http://localhost:5176/。後端只聽 127.0.0.1:8083；Vite 同源 proxy，Session Cookie IBEET_V31_SESSION。舊 V3 8082/5175 與 Cookie 沒有改動。

沿用 Build-V3／Initialize-V3 檔名是為保留操作入口；腳本內容僅接受 V3.1。Common.ps1 設定的 IBEET_V31_ROOT 只影響目前程序；C 路徑從同一根目錄推導，沒有獨立 c-runtime 覆寫。

執行資料位置：runtime-v31/secrets/root.key、runtime-v31/crypto/system.gcm、runtime-v31/crypto/<IBEET_ID SHA-256>.gcm、runtime-v31/db/cloud.mv.db。root.key 未經自我加密，依靠 NTFS ACL／主機信任；資料庫沒有全檔加密，但檔案內容、金鑰及關鍵字名稱在寫入前加密。

腳本提供 Java -Xmx768m，配合兩個重型檔案名額；仍須做實際負載評估。預設 H2 使用本機 sa 與空白密碼，沒有 TCP／Console；正式本機使用可在初始化前設定程序層級 IBEET_DB_PASSWORD，後續需一致。禁止把密碼寫入來源或命令列。測試明確使用獨立空白 H2 測試密碼，不讀取既有 DB 認證。

若 ACL、路徑、金鑰驗證、配對參數或 DataSource 被拒絕，保留現場並查明原因；不能刪除金鑰後自動重試。8083/5176 被占用時先確認占用者，不能停止 V1/V2/V3。正式 HTTPS 需另設 Secure Cookie 與受信任同源反向代理，這次未部署。

備份需一致涵蓋本版新 DB、root.key 與 crypto；備份也需加密與 ACL。禁止將其加入原始碼 ZIP。互動初始化、備援還原與 Windows/WSL 整機重啟尚未驗收。
