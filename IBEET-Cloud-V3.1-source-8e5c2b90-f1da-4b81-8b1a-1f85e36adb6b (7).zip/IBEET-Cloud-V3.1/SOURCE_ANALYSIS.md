# V3.1 來源分析

本版從已審查 ZIP 的 110 個來源項目複製，起始雜湊全數吻合。開發與測試位於獨立 IBEET-Cloud-V3.1；附件 V3 基準與 ZIP 在交付前再次核對。現有套件只由快取唯讀複製，沒有在舊 V3 安裝相依套件。

F01 於來源修改前提出設計並取得使用者確認。完整輸入 SHA-256 前處理新增為 hashVersion 3；沒有替換原配對等式或靜默修改 1/2。公開固定向量與參數指紋可供獨立重跑；目前 WSL 被拒，不能宣稱 C 已編譯。

檔案服務從已驗證 Session 取得 owner，列表改為 FileSummary 投影分頁，上傳在 owner 悲觀鎖內計算配額；檔案與索引仍共用交易。關鍵字寫 GCM3／C 密文／HMAC；keyword 搜尋仍呼叫真實 C，不解密名稱或使用明文 SQL 偽裝。搜尋逐候選頁執行並受 SearchLimits 約束。

UploadBoundary 在 CSRF/multipart 前限制大小、來源角色與重型處理名額；MultipartConfigElement 固定合法請求低於落盤門檻。F03 同時採啟動拒絕及受控的最終 DataSource，避免只驗一般 URL 後又遭 Hikari 覆寫。F04 Java 檢查實際祖先，C 固定 dirfd；C 路徑只由本版根目錄與 crypto-directory 推導。

AdminController 仍回傳限定 DTO；檔案的密文片段由 SQL 投影取得，避免 findAll 載入完整 payload；檔案及索引可分別翻頁。USER/ADMIN 授權、CSRF、Session 及 BCrypt 邊界保留，沒有新增重設密碼／冒充／明文金鑰管理 API。

V31RegressionTests 的真實 H2/服務測試不開網路、用正常無關鍵字檔案執行原 AES-GCM 路徑；它不呼叫或模擬 IBEET。完整 HTTP、原功能及 C 測試來源保留，執行受限時各自記錄失敗／跳過。所有實測差異及限制以 TEST_REPORT.md 為準。
