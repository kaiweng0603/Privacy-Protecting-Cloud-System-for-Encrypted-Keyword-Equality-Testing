# IBEET Cloud Storage V3.1

這是從通過完整性核對的 V3 原始碼建立的獨立安全修正候選版。**尚未全面驗收通過，不可直接接入真實資料或金鑰。** 真實 C/PBC、完整 HTTP 與重新啟動驗收受到目前環境權限限制；實際結果與原始證據見 TEST_REPORT.md 及 evidence/。

V3 基準原始碼與原 ZIP 未修改；本版不讀取、不覆寫 V1/V2/V3 執行資料。根目錄必須命名 IBEET-Cloud-V3.1，並保留 .ibeet-v31 標記，不能放在舊專案內。

## 修正內容

- F01：2026-11-15 取得使用者確認後，新增 hashVersion 3；完整 UTF-8 輸入經用途標籤、長度編碼與 SHA-256，再交給既有 PBC 映射。舊 1/2 語意不變，舊長詞風險亦不會憑空消失。詳見 HASH_VERSION3_DESIGN.md。
- F02：20 MiB 檔案／22 MiB 請求上限；所有合法 multipart part 留在記憶體；上傳與下載共用兩個處理名額，拒絕未知長度／chunked 上傳。
- F03：固定 H2 driver 與初始化 SQL，建立不接受 Hikari 屬性繫結的受控 DataSource，每次取得連線前再驗證實際設定與路徑。
- F04：Java 檢查所有既有祖先的實際位置；C 逐層 O_NOFOLLOW 開目錄，再以目錄描述符執行開檔、原子寫入及 fsync。
- F05：每帳號一個搜尋、全域兩個 C 程序、最多 512 次比對／10 秒；登入每來源 10 次／60 秒；每帳號最多 100 檔／200 MiB；使用者列表、候選搜尋與後台均分頁，不載入整批檔案密文。

這仍是伺服器端加密及應用角色隔離，不是端對端／零知識系統，也不宣稱原研究用 Type A 參數已達現代 128-bit 整體安全。

## 獨立環境

| 項目 | V3.1 |
| --- | --- |
| 後端／前端 | 127.0.0.1:8083／localhost:5176 |
| Session Cookie | IBEET_V31_SESSION，HttpOnly，SameSite=Strict，20 分鐘 |
| 執行資料 | 本版根目錄/runtime-v31 |
| 測試資料 | 本版根目錄/.test-runs，每次新 UUID |
| WSL | Ubuntu-26.04；C 路徑從本版真實根目錄推導 |
| 相依套件快取 | 本版 .cache；不封裝 |

新連接埠與 Cookie 用來避免影響仍在執行的 V3 8082/5175。沒有改動其設定。

## 建置與驗證

需求：Windows 11、PowerShell 7、Java 26、Node.js 24、npm 11，以及已有 gcc/PBC/GMP/OpenSSL/Python 3 的 WSL Ubuntu-26.04。腳本不安裝系統套件。

```powershell
Set-Location C:\IBEET-Cloud-V3.1
# 沿用既有腳本檔名；內容與路徑防護已全部改為 V3.1。
.\scripts\Build-V3.ps1 -InstallFrontendDependencies
# 分別執行並保留每一項的輸出與退出碼；任一失敗會回報失敗。
.\scripts\Run-Validation.ps1
```

完整建置／驗收通過後，才在全新 runtime-v31 初始化。不得複製舊金鑰或資料庫，不得刪除金鑰後重試。

```powershell
.\scripts\Initialize-V3.ps1
.\scripts\Start-Backend.ps1
# 另一終端
.\scripts\Start-Frontend.ps1
```

初始化需本人遮蔽輸入 Alice、Bob、Admin 三組密碼，沒有預設密碼。啟動腳本使用本程序的 IBEET_V31_ROOT，沒有改全域設定。更多操作與限制見 WINDOWS_SETUP.md、SECURITY.md。

搜尋以每頁 10 個候選檔案為單位，candidateTotal 是自己的候選檔案總數，並非整個搜尋的命中數；空白結果頁仍可有下一頁。工作量超限或逾時會明確失敗，不返回偽裝成完整結果的部分清單。

## 交付文件

CHANGELOG.md：修正及修改檔案；TEST_REPORT.md：實測、失敗與未驗清單；SECURITY.md：安全邊界；HASH_VERSION3_DESIGN.md：已確認的映射方案；MIGRATION.md：僅限明確授權的日後遷移；DEMO_GUIDE.md：驗收通過後的展示。

V3_BASELINE_MANIFEST.json 保存 V3 基準雜湊，SOURCE_MANIFEST.json 為本次 V3.1 交付清單。evidence/ 僅包含去除秘密的文字證據，不含測試資料庫、root.key 或 C 金鑰密文。
