
#include <pbc/pbc.h>
#include <string.h>

#include "common.h"
#include "hash.h"
#include "decrypt.h"

int decrypt(
    SystemParams *param,
    UserPrivateKey *key,
    Ciphertext *cipher,
    char M[32]
) {
    // temp1 = e(X1, delta1)
    element_t temp1;
    element_init_GT(temp1, param->pairing);

    pairing_apply(
        temp1,
        key->X1,
        cipher->delta1,
        param->pairing
    );

    // g_pow_X2 = g ^ S
    element_t g_pow_X2;
    element_init_G1(g_pow_X2, param->pairing);

    element_pow_zn(
        g_pow_X2,
        param->g,
        key->S
    );

    // temp2 = delta3 / (g ^ S)
    element_t temp2;
    element_init_G1(temp2, param->pairing);

    element_div(
        temp2,
        cipher->delta3,
        g_pow_X2
    );

    // 計算 h3
    unsigned char h3[64];

    hash_h3(
        temp1,
        cipher->delta1,
        cipher->delta2,
        temp2,
        h3
    );

    // 還原 M || h0(M)
    unsigned char recovered[64];

    for (int i = 0; i < 64; i++) {
        recovered[i] = cipher->delta4[i] ^ h3[i];
    }

    // 取出原始訊息
    memcpy(M, recovered, 32);

    // 驗證 h0(M)
    unsigned char expected_hash[32];

    hash_h0(
        (const unsigned char *)M,
        expected_hash
    );

    // 比較還原的雜湊與重新計算的雜湊
    if (memcmp(recovered + 32, expected_hash, 32) != 0) {
        memset(M, 0, 32);

        element_clear(temp1);
        element_clear(g_pow_X2);
        element_clear(temp2);

        return -1;
    }

    // 釋放 PBC 元素
    element_clear(temp1);
    element_clear(g_pow_X2);
    element_clear(temp2);

    return 0;
}
