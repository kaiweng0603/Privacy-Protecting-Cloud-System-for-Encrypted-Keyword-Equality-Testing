#ifndef SECURE_STORE_H
#define SECURE_STORE_H
#include <stddef.h>
extern char v3_runtime[4096];
extern int v3_initialize;
extern int v3_provision;
int v3_start(const char *directory, const char *keyhex);
int v3_save(const char *name, const char *context, const unsigned char *data, size_t length);
int v3_load(const char *name, const char *context, unsigned char **data, size_t *length);
int v3_exists(const char *name);
#endif
