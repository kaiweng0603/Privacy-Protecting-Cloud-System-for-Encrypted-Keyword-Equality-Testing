#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pbc/pbc.h>
#include "hash.h"
static void require(int condition,const char *message){if(!condition){fprintf(stderr,"FAIL: %s\n",message);exit(1);}printf("PASS: %s\n",message);}
int main(void){
 FILE *f=fopen("param/a.param","rb");require(f!=NULL,"public parameter opened");char params[16384];size_t n=fread(params,1,sizeof(params),f);fclose(f);
 pairing_t pairing;require(pairing_init_set_buf(pairing,params,n)==0,"pairing initialized");
 element_t a,b,expected;element_init_G1(a,pairing);element_init_G1(b,pairing);element_init_G1(expected,pairing);
 const char *vector="6385bb9d71a9a6b0bc085a4106d2ba666fe2e7f5640621c82124d0b02375a5d1";unsigned char digest[32];
 for(int i=0;i<32;i++){unsigned int value=0;require(sscanf(vector+i*2,"%2x",&value)==1,"digest byte parsed");digest[i]=(unsigned char)value;}
 element_from_hash(expected,digest,32);require(hash_keyword_v3(a,"ocean2026")==0&&!element_cmp(a,expected),"HV3 exact full-input SHA256 frame vector");
 char first[501],second[501];memset(first,'A',80);memset(second,'A',80);strcpy(first+80,"-one");strcpy(second+80,"-two");
 require(!hash_keyword_v3(a,first)&&!hash_keyword_v3(b,second)&&element_cmp(a,b),"84-byte different suffixes differ under HV3");
 memset(first,'A',500);memset(second,'A',500);first[500]=second[500]=0;second[499]='B';
 require(!hash_keyword_v3(a,first)&&!hash_keyword_v3(b,second)&&element_cmp(a,b),"500-byte different suffixes differ under HV3");
 require(!hash_keyword_v3(a,"海洋測試")&&!hash_keyword_v3(b,"海洋測試")&&!element_cmp(a,b),"same UTF8 keyword deterministic");
 require(hash_keyword_v3(a,"")&&hash_keyword_v3(a,"bad\nword")&&hash_keyword_v3(a,"\xc0\xaf")&&hash_keyword_v3(a,"\xed\xa0\x80"),"invalid encoding and controls rejected");
 hash_h2(a,"ocean2026");element_from_hash(expected,"ocean2026",9);require(!element_cmp(a,expected),"HV1 mapping unchanged");
 unsigned char v2[]={2,'o','c','e','a','n','2','0','2','6'};hash_keyword_v2(a,"ocean2026");element_from_hash(expected,v2,sizeof(v2));require(!element_cmp(a,expected),"HV2 mapping unchanged");
 element_clear(a);element_clear(b);element_clear(expected);pairing_clear(pairing);return 0;
}
