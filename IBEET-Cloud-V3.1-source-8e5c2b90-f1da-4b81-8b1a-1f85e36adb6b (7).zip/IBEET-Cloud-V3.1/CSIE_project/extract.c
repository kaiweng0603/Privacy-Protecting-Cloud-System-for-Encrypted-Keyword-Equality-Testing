#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pbc/pbc.h>
#include <openssl/sha.h>
#include <openssl/crypto.h>
#include "common.h"
#include "hash.h"
#include "secure_store.h"
int extract(SystemParams *param,const char *id,UserPrivateKey *key) {
    if(!id||!id[0]||strlen(id)>200) return 1;
    unsigned char digest[32]; char name[80],context[200];
    SHA256((const unsigned char*)id,strlen(id),digest);
    for(int i=0;i<32;i++) sprintf(name+i*2,"%02x",digest[i]);
    strcat(name,".gcm");
    int wlen=element_length_in_bytes(param->W);
    unsigned char *wb=malloc(wlen);
    if(!wb) return 1;
    element_to_bytes(wb,param->W); SHA256(wb,wlen,digest); free(wb);
    strcpy(context,name); strcat(context,":");
    size_t off=strlen(context);
    for(int i=0;i<32;i++) sprintf(context+off+i*2,"%02x",digest[i]);
    element_init_G1(key->X1,param->pairing); element_init_Zr(key->S,param->pairing);
    int a=element_length_in_bytes(key->X1),b=element_length_in_bytes(key->S);
    if(v3_exists(name)!=0) {
        unsigned char *buf=NULL; size_t n=0;
        if(v3_load(name,context,&buf,&n)) return 1;
        int bad=n!=(size_t)(a+b);
        if(!bad) bad=element_from_bytes(key->X1,buf)!=a || element_from_bytes(key->S,buf+a)!=b;
        OPENSSL_clear_free(buf,n); return bad;
    }
    if(!v3_provision) return 1;
    element_t d, g_pow_d;
    element_t h1, D;
    element_t h2, temp;
    element_t X_prime, W_pow_d;

    element_init_Zr(d, param->pairing);
    element_init_G1(g_pow_d, param->pairing);

    element_init_G1(h1, param->pairing);
    element_init_G1(D, param->pairing);

    element_init_G1(h2, param->pairing);
    element_init_G1(temp, param->pairing);

    element_init_G1(X_prime, param->pairing);
    element_init_G1(W_pow_d, param->pairing);

    element_random(d);
    element_random(key->S);

    /* g^d */
    element_pow_zn(g_pow_d, param->g, d);

    /* h1(ID || S) */
    hash_h1(h1, id, key->S);

    /* D = g^d * h1(ID || S) */
    element_mul(D, g_pow_d, h1);

    /* h2(ID) */
    hash_h2(h2, id);

    /* temp = D * h2(ID) */
    element_mul(temp, D, h2);

    /* X_prime = temp^mu */
    element_pow_zn(X_prime, temp, param->mu);

    /* W^d */
    element_pow_zn(W_pow_d, param->W, d);

    /* X1 = X_prime / W^d */
    element_div(key->X1, X_prime, W_pow_d);

    /* 清除暫存元素 */
    element_clear(d);
    element_clear(g_pow_d);
    element_clear(h1);
    element_clear(D);
    element_clear(h2);
    element_clear(temp);
    element_clear(X_prime);
    element_clear(W_pow_d);

    unsigned char *buf=malloc(a+b);
    if(!buf) return 1;
    element_to_bytes(buf,key->X1); element_to_bytes(buf+a,key->S);
    int rc=v3_save(name,context,buf,(size_t)(a+b));
    OPENSSL_clear_free(buf,a+b);
    return rc;
}