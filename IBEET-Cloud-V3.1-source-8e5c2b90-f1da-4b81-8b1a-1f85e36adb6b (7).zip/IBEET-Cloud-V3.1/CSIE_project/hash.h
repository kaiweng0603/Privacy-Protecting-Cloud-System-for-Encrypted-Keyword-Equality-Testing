
#ifndef HASH_H
#define HASH_H

/* SHA-256：訊息雜湊 */
void hash_h0(const unsigned char *, unsigned char [32]);

/* H1：使用者 ID 與私鑰相關雜湊 */
void hash_h1(element_t, const char *, element_t);

/* H2 V1：舊版雜湊，保持相容 */
void hash_h2(element_t, const char *);

/* H2 V2：新版關鍵字專用雜湊 */
void hash_keyword_v2(element_t, const char *);
/* HV3: approved full-input SHA-256 preprocessing, then legacy PBC mapping. */
int hash_keyword_v3(element_t, const char *);

/* H3：密文遮罩雜湊 */
void hash_h3(
    element_t,
    element_t,
    element_t,
    element_t,
    unsigned char [64]
);

#endif
