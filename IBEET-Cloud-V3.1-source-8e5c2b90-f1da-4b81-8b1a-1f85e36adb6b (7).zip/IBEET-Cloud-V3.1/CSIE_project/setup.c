#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <openssl/crypto.h>
#include <openssl/sha.h>
#include <pbc/pbc.h>
#include "common.h"
#include "secure_store.h"
int init_pairing_from_file(pairing_t pairing,const char *filename) {
    FILE *f=fopen(filename,"rb"); char buf[16384];
    if(!f) return 1;
    size_t n=fread(buf,1,sizeof(buf),f); int extra=fgetc(f); fclose(f);
    if(!n||extra!=EOF) return 1;
    unsigned char digest[32];char hex[65];
    SHA256((const unsigned char*)buf,n,digest);
    for(int i=0;i<32;i++)sprintf(hex+i*2,"%02x",digest[i]);
    if(strcmp(hex,"b9efd49cd3e32bda1c9c31a789eb442aa427e40743cc919ee3804afe1f684e6b"))return 1;
    return pairing_init_set_buf(pairing,buf,n);
}
int setup(SystemParams *p) {
    if(!v3_runtime[0]) return 1;
    if(init_pairing_from_file(p->pairing,"param/a.param")) return 1;
    element_init_G1(p->g,p->pairing); element_init_G1(p->W,p->pairing); element_init_Zr(p->mu,p->pairing);
    int a=element_length_in_bytes(p->g),b=element_length_in_bytes(p->W),c=element_length_in_bytes(p->mu);
    size_t expected=(size_t)a+b+c;
    unsigned char *buf=NULL; size_t n=0;
    if(v3_exists("system.gcm")==0) {
        if(!v3_initialize) return 1;
        element_random(p->g); element_random(p->mu);
        if(element_is0(p->g)||element_is0(p->mu)) return 1;
        element_pow_zn(p->W,p->g,p->mu);
        buf=malloc(expected); if(!buf) return 1;
        element_to_bytes(buf,p->g); element_to_bytes(buf+a,p->W); element_to_bytes(buf+a+b,p->mu);
        int rc=v3_save("system.gcm","IBEET-V3/system/a.param",buf,expected);
        OPENSSL_clear_free(buf,expected); return rc;
    }
    if(v3_initialize || v3_load("system.gcm","IBEET-V3/system/a.param",&buf,&n)) return 1;
    int bad=n!=expected;
    if(!bad) bad=element_from_bytes(p->g,buf)!=a || element_from_bytes(p->W,buf+a)!=b ||
        element_from_bytes(p->mu,buf+a+b)!=c;
    OPENSSL_clear_free(buf,n);
    if(bad) return 1;
    element_t check; element_init_G1(check,p->pairing); element_pow_zn(check,p->g,p->mu);
    bad=element_cmp(check,p->W)!=0 || element_is0(p->g)||element_is0(p->mu);
    element_clear(check); return bad;
}
