
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pbc/pbc.h>
#include <openssl/sha.h>
#include <openssl/evp.h>
#include <openssl/crypto.h>
#include <stdint.h>

#include "hash.h"

/* h0: SHA-256 */
void hash_h0(const unsigned char *data, unsigned char digest[32])
{
    SHA256(data, 32, digest);
}

/* h1: H(ID || S) */
void hash_h1(element_t h, const char *id, element_t S)
{
    int id_len = strlen(id);
    int s_len = element_length_in_bytes(S);

    int total_len = id_len + s_len;

    unsigned char *buffer = malloc(total_len);

    if (buffer == NULL) {
        fprintf(stderr, "hash_h1: memory allocation failed\n");
        return;
    }

    memcpy(buffer, id, id_len);

    element_to_bytes(buffer + id_len, S);

    element_from_hash(h, buffer, total_len);

    free(buffer);
}

/* h2 V1: H(ID)，保留舊版相容性 */
void hash_h2(element_t h, const char *id)
{
    element_from_hash(h, id, strlen(id));
}

/* h2 V2: H(0x02 || keyword)，關鍵字專用雜湊 */
void hash_keyword_v2(element_t h, const char *keyword)
{
    if (keyword == NULL || keyword[0] == '\0') {
        fprintf(stderr, "hash_keyword_v2: invalid keyword\n");
        return;
    }

    size_t keyword_len = strlen(keyword);
    size_t total_len = keyword_len + 1;

    unsigned char *buffer = malloc(total_len);

    if (buffer == NULL) {
        fprintf(stderr, "hash_keyword_v2: memory allocation failed\n");
        return;
    }

    /* Domain separation prefix */
    buffer[0] = 0x02;

    /* Keyword content */
    memcpy(buffer + 1, keyword, keyword_len);

    /* Map to PBC group element */
    element_from_hash(h, buffer, total_len);

    free(buffer);
}

/* HV1/HV2 above intentionally retain their original byte-for-byte semantics. */
static int valid_utf8(const unsigned char *s,size_t n) {
    for(size_t i=0;i<n;) {
        uint32_t c=s[i++]; unsigned int more=0;uint32_t minimum=0;
        if(c<128) { if(c<32||c==127)return 0;continue; }
        if(c>=0xc2&&c<=0xdf){c&=31;more=1;minimum=0x80;}
        else if(c>=0xe0&&c<=0xef){c&=15;more=2;minimum=0x800;}
        else if(c>=0xf0&&c<=0xf4){c&=7;more=3;minimum=0x10000;}
        else return 0;
        if(i+more>n)return 0;
        while(more--){if((s[i]&0xc0)!=0x80)return 0;c=(c<<6)|(s[i++]&63);}
        if(c<minimum||c>0x10ffff||(c>=0xd800&&c<=0xdfff))return 0;
    }
    return 1;
}
int hash_keyword_v3(element_t h,const char *keyword) {
    if(!keyword)return 1;
    size_t n=strlen(keyword);
    if(!n||n>500||!valid_utf8((const unsigned char*)keyword,n))return 1;
    static const unsigned char dst[]="IBEET-CLOUD/KEYWORD/HV3/PBC-TYPE-A/SHA256";
    unsigned char length[4]={(unsigned char)(n>>24),(unsigned char)(n>>16),(unsigned char)(n>>8),(unsigned char)n};
    unsigned char digest[32];unsigned int out=0;
    EVP_MD_CTX *ctx=EVP_MD_CTX_new();
    int ok=ctx&&EVP_DigestInit_ex(ctx,EVP_sha256(),NULL)==1&&
        EVP_DigestUpdate(ctx,dst,sizeof(dst))==1&&EVP_DigestUpdate(ctx,length,4)==1&&
        EVP_DigestUpdate(ctx,keyword,n)==1&&EVP_DigestFinal_ex(ctx,digest,&out)==1&&out==32;
    EVP_MD_CTX_free(ctx);
    if(!ok){OPENSSL_cleanse(digest,sizeof(digest));return 1;}
    element_from_hash(h,digest,sizeof(digest));OPENSSL_cleanse(digest,sizeof(digest));
    return element_is0(h)?1:0;
}

/* h3: H(GT || G1 || G1 || G1) */
void hash_h3(
    element_t gt,
    element_t g1,
    element_t g2,
    element_t g3,
    unsigned char digest[64])
{
    int gt_len = element_length_in_bytes(gt);
    int g1_len = element_length_in_bytes(g1);
    int g2_len = element_length_in_bytes(g2);
    int g3_len = element_length_in_bytes(g3);

    int total = gt_len + g1_len + g2_len + g3_len;

    unsigned char *buffer = malloc(total + 1);

    if (buffer == NULL) {
        fprintf(stderr, "hash_h3: memory allocation failed\n");
        return;
    }

    int pos = 0;

    element_to_bytes(buffer + pos, gt);
    pos += gt_len;

    element_to_bytes(buffer + pos, g1);
    pos += g1_len;

    element_to_bytes(buffer + pos, g2);
    pos += g2_len;

    element_to_bytes(buffer + pos, g3);
    pos += g3_len;

    buffer[pos] = '0';
    SHA256(buffer, total + 1, digest);

    buffer[pos] = '1';
    SHA256(buffer, total + 1, digest + 32);

    free(buffer);
}
