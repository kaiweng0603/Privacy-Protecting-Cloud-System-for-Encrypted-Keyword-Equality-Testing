
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <pbc/pbc.h>

#include "common.h"
#include "hash.h"
#include "setup.h"
#include "extract.h"
#include "encrypt.h"
#include "decrypt.h"
#include "trapdoor.h"
#include "test.h"
#include "secure_store.h"

/* Keyword hash version function declaration */
static int hash_keyword_by_version(
    element_t Q,
    const char *keyword,
    int version
);
/* =====================================================
   HEX OUTPUT
   ===================================================== */

static void print_hex(
    const char *name,
    const unsigned char *data,
    size_t len
) {
    printf("%s=", name);

    for (size_t i = 0; i < len; i++) {
        printf("%02x", data[i]);
    }

    printf("\n");
}

static void print_element_hex(
    const char *name,
    element_t element
) {
    int len = element_length_in_bytes(element);

    if (len <= 0) {
        fprintf(stderr, "Invalid element length: %s\n", name);
        exit(1);
    }

    unsigned char *buffer = malloc((size_t)len);

    if (buffer == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(1);
    }

    element_to_bytes(buffer, element);
    print_hex(name, buffer, (size_t)len);

    free(buffer);
}

/* =====================================================
   HEX CONVERSION
   ===================================================== */

static int hex_to_bytes(
    const char *hex,
    unsigned char *output,
    size_t output_len
) {
    if (hex == NULL ||
        output == NULL ||
        strlen(hex) != output_len * 2) {
        return -1;
    }

    for (size_t i = 0; i < output_len; i++) {

        int high = isdigit((unsigned char)hex[i * 2])
            ? hex[i * 2] - '0'
            : tolower((unsigned char)hex[i * 2]) - 'a' + 10;

        int low = isdigit((unsigned char)hex[i * 2 + 1])
            ? hex[i * 2 + 1] - '0'
            : tolower((unsigned char)hex[i * 2 + 1]) - 'a' + 10;

        if (high < 0 || high > 15 ||
            low < 0 || low > 15) {
            return -1;
        }

        output[i] = (unsigned char)((high << 4) | low);
    }

    return 0;
}

/* =====================================================
   LOAD PBC ELEMENT FROM HEX
   ===================================================== */

static int load_element_hex(
    element_t element,
    const char *hex,
    const char *name
) {
    int len = element_length_in_bytes(element);

    if (len <= 0 || hex == NULL) {
        fprintf(stderr,
                "LOAD_ERROR[%s]: invalid element length\n",
                name);
        return -1;
    }

    size_t hex_len = strlen(hex);

    fprintf(stderr,
            "LOAD_INFO[%s]: expected_hex=%d, actual_hex=%zu\n",
            name,
            len * 2,
            hex_len);

    if (hex_len != (size_t)len * 2) {
        fprintf(stderr,
                "LOAD_ERROR[%s]: length mismatch\n",
                name);
        return -1;
    }

    unsigned char *buffer = malloc((size_t)len);

    if (buffer == NULL) {
        fprintf(stderr,
                "LOAD_ERROR[%s]: memory allocation failed\n",
                name);
        return -1;
    }

    if (hex_to_bytes(hex, buffer, (size_t)len) != 0) {
        fprintf(stderr,
                "LOAD_ERROR[%s]: invalid hexadecimal characters\n",
                name);

        free(buffer);
        return -1;
    }

    int result = element_from_bytes(element, buffer);

    fprintf(stderr,
            "LOAD_INFO[%s]: expected_bytes=%d, decoded_bytes=%d\n",
            name,
            len,
            result);

    free(buffer);

    if (result != len) {
        fprintf(stderr,
                "LOAD_ERROR[%s]: PBC element decoding failed\n",
                name);
        return -1;
    }

    return 0;
}

/* =====================================================
   KEYWORD HASH VERSION
   ===================================================== */

static int hash_keyword_by_version(
    element_t Q,
    const char *keyword,
    int version
) {
    if (version == 3) {
        return hash_keyword_v3(Q, keyword);
    } else if (version == 2) {
        hash_keyword_v2(Q, keyword);
    } else if (version == 1) {
        hash_h2(Q, keyword);
    } else return 1;
    return 0;
}

/* =====================================================
   ENCRYPT
   ===================================================== */

static int run_encrypt(
    const char *message,
    const char *keyword,
    const char *userId,
    int hashVersion
) {
    if (strlen(message) > 31) {
        fprintf(stderr, "Message too long: maximum 31 bytes\n");
        return 1;
    }

    SystemParams param;

    if (setup(&param) != 0) {
        fprintf(stderr, "setup failed\n");
        return 1;
    }

    UserPrivateKey key;

    if (extract(&param, userId, &key) != 0) {
        fprintf(stderr, "extract failed\n");
        return 1;
    }

    unsigned char M[32] = {0};
    memcpy(M, message, strlen(message));

    element_t Q;
    element_init_G1(Q, param.pairing);

    if(hash_keyword_by_version(Q, keyword, hashVersion)) return 1;

    Ciphertext cipher;

    if (encrypt(
            &param,
            M,
            Q,
            userId,
            &key,
            &cipher
        ) != 0) {

        fprintf(stderr, "encrypt failed\n");
        element_clear(Q);
        return 1;
    }

    print_element_hex("delta1", cipher.delta1);
    print_element_hex("delta2", cipher.delta2);
    print_element_hex("delta3", cipher.delta3);

    print_hex(
        "delta4",
        cipher.delta4,
        sizeof(cipher.delta4)
    );

    printf("IBEET_ENCRYPT_OK\n");

    element_clear(Q);

    element_clear(cipher.delta1);
    element_clear(cipher.delta2);
    element_clear(cipher.delta3);

    element_clear(key.X1);
    element_clear(key.S);

    return 0;
}

/* =====================================================
   COMPARE
   ===================================================== */

static int run_compare(
    const char *keyword1,
    const char *keyword2,
    const char *userId,
    int hashVersion
) {
    SystemParams param;

    if (setup(&param) != 0) {
        fprintf(stderr, "setup failed\n");
        return 1;
    }

    UserPrivateKey key;

    if (extract(&param, userId, &key) != 0) {
        fprintf(stderr, "extract failed\n");
        return 1;
    }

    unsigned char M1[32] = {0};
    unsigned char M2[32] = {0};

    memcpy(M1, "IBEET compare message one", 25);
    memcpy(M2, "IBEET compare message two", 25);

    element_t Q1, Q2;

    element_init_G1(Q1, param.pairing);
    element_init_G1(Q2, param.pairing);

    if(hash_keyword_by_version(Q1, keyword1, hashVersion)||hash_keyword_by_version(Q2, keyword2, hashVersion))return 1;


    Ciphertext cipher1, cipher2;

    if (encrypt(&param, M1, Q1, userId, &key, &cipher1) != 0 ||
        encrypt(&param, M2, Q2, userId, &key, &cipher2) != 0) {

        fprintf(stderr, "encrypt failed\n");
        return 1;
    }

    Trapdoor td1, td2;

    trapdoor(&param, &key, &td1);
    trapdoor(&param, &key, &td2);

    int matched = test(
        &param,
        &cipher1, &td1,
        &cipher2, &td2
    );

    printf(
        "COMPARE_RESULT=%s\n",
        matched ? "MATCH" : "NO_MATCH"
    );

    element_clear(Q1);
    element_clear(Q2);

    element_clear(cipher1.delta1);
    element_clear(cipher1.delta2);
    element_clear(cipher1.delta3);

    element_clear(cipher2.delta1);
    element_clear(cipher2.delta2);
    element_clear(cipher2.delta3);

    element_clear(td1.T);
    element_clear(td2.T);

    element_clear(key.X1);
    element_clear(key.S);

    return 0;
}

/* =====================================================
   MATCH
   ===================================================== */

static int run_match(
    const char *keyword,
    const char *userId,
    const char *delta2_hex,
    const char *delta3_hex,
    int hashVersion
) {
    if (keyword == NULL || strlen(keyword) == 0) {
        fprintf(stderr, "Keyword cannot be empty\n");
        return 1;
    }

    SystemParams param;

    if (setup(&param) != 0) {
        fprintf(stderr, "setup failed\n");
        return 1;
    }

    UserPrivateKey key;

    if (extract(&param, userId, &key) != 0) {
        fprintf(stderr, "extract failed\n");
        return 1;
    }

    /* 初始化資料庫密文元素 */

    Ciphertext stored_cipher;

    element_init_G1(
        stored_cipher.delta2,
        param.pairing
    );

    element_init_G1(
        stored_cipher.delta3,
        param.pairing
    );

    /* 還原 C2 */

    if (load_element_hex(
            stored_cipher.delta2,
            delta2_hex,
            "C2"
        ) != 0) {

        element_clear(stored_cipher.delta2);
        element_clear(stored_cipher.delta3);

        element_clear(key.X1);
        element_clear(key.S);

        return 1;
    }

    /* 還原 C3 */

    if (load_element_hex(
            stored_cipher.delta3,
            delta3_hex,
            "C3"
        ) != 0) {

        element_clear(stored_cipher.delta2);
        element_clear(stored_cipher.delta3);

        element_clear(key.X1);
        element_clear(key.S);

        return 1;
    }

    /* 建立搜尋關鍵字 Q */

    element_t Q;

    element_init_G1(Q, param.pairing);

    if(hash_keyword_by_version(Q, keyword, hashVersion))return 1;

    /* 建立臨時查詢密文 */

    unsigned char M[32] = {0};

    memcpy(
        M,
        "IBEET_SEARCH",
        strlen("IBEET_SEARCH")
    );

    Ciphertext query_cipher;

    if (encrypt(
            &param,
            M,
            Q,
            userId,
            &key,
            &query_cipher
        ) != 0) {

        fprintf(stderr, "Search encryption failed\n");

        element_clear(Q);

        element_clear(stored_cipher.delta2);
        element_clear(stored_cipher.delta3);

        element_clear(key.X1);
        element_clear(key.S);

        return 1;
    }

    /* 產生 Trapdoor */

    Trapdoor td;

    if (trapdoor(&param, &key, &td) != 0) {
        fprintf(stderr, "Trapdoor generation failed\n");
        return 1;
    }

    /* 執行公式 (9) */

    int matched = test(
        &param,
        &stored_cipher,
        &td,
        &query_cipher,
        &td
    );

    printf(
        "MATCH_RESULT=%s\n",
        matched ? "MATCH" : "NO_MATCH"
    );

    printf("IBEET_MATCH_OK\n");

    /* 清除暫存資料 */

    element_clear(Q);

    element_clear(stored_cipher.delta2);
    element_clear(stored_cipher.delta3);

    element_clear(query_cipher.delta1);
    element_clear(query_cipher.delta2);
    element_clear(query_cipher.delta3);

    element_clear(td.T);

    element_clear(key.X1);
    element_clear(key.S);

    return 0;
}

/* =====================================================
   DECRYPT
   ===================================================== */

static int run_decrypt(
    const char *delta1_hex,
    const char *delta2_hex,
    const char *delta3_hex,
    const char *delta4_hex,
    const char *userId
) {
    SystemParams param;

    if (setup(&param) != 0) {
        fprintf(stderr, "setup failed\n");
        return 1;
    }

    UserPrivateKey key;

    if (extract(&param, userId, &key) != 0) {
        fprintf(stderr, "extract failed\n");
        return 1;
    }

    Ciphertext cipher;

    element_init_G1(cipher.delta1, param.pairing);
    element_init_G1(cipher.delta2, param.pairing);
    element_init_G1(cipher.delta3, param.pairing);

    if (load_element_hex(
            cipher.delta1,
            delta1_hex,
            "delta1"
        ) != 0 ||
        load_element_hex(
            cipher.delta2,
            delta2_hex,
            "delta2"
        ) != 0 ||
        load_element_hex(
            cipher.delta3,
            delta3_hex,
            "delta3"
        ) != 0) {

        fprintf(stderr, "Invalid ciphertext element\n");

        element_clear(cipher.delta1);
        element_clear(cipher.delta2);
        element_clear(cipher.delta3);

        element_clear(key.X1);
        element_clear(key.S);

        return 1;
    }

    if (hex_to_bytes(
            delta4_hex,
            cipher.delta4,
            sizeof(cipher.delta4)
        ) != 0) {

        fprintf(stderr, "Invalid delta4\n");

        element_clear(cipher.delta1);
        element_clear(cipher.delta2);
        element_clear(cipher.delta3);

        element_clear(key.X1);
        element_clear(key.S);

        return 1;
    }

    char M[32] = {0};

    if (decrypt(&param, &key, &cipher, M) != 0) {
        fprintf(stderr, "IBEET_DECRYPT_FAILED\n");

        element_clear(cipher.delta1);
        element_clear(cipher.delta2);
        element_clear(cipher.delta3);

        element_clear(key.X1);
        element_clear(key.S);

        return 1;
    }

    print_hex(
        "PLAINTEXT_HEX",
        (const unsigned char *)M,
        sizeof(M)
    );

    printf("IBEET_DECRYPT_OK\n");

    element_clear(cipher.delta1);
    element_clear(cipher.delta2);
    element_clear(cipher.delta3);

    element_clear(key.X1);
    element_clear(key.S);

    return 0;
}


/* =====================================================
   MAIN
   ===================================================== */

/* V3 protocol: only operation and state directory in argv; all values use stdin.
   Each field is hex encoded to avoid line injection and preserve UTF-8. */
static char *field(void) {
    char *line=NULL; size_t cap=0; ssize_t n=getline(&line,&cap,stdin);
    if(n<=0 || n>131074) { free(line); return NULL; }
    if(line[n-1]=='\n') line[--n]=0;
    if(n && line[n-1]=='\r') line[--n]=0;
    if(n%2) { free(line); return NULL; }
    char *out=calloc((size_t)n/2+1,1);
    if(!out || hex_to_bytes(line,(unsigned char*)out,(size_t)n/2)) { free(out);free(line);return NULL; }
    free(line);
    if(memchr(out,0,(size_t)n/2)) { free(out);return NULL; }
    return out;
}
int main(int argc,char *argv[]) {
    if(argc!=3) { fprintf(stderr,"V3 stdin protocol required\n");return 1; }
    char keyhex[67];
    if(!fgets(keyhex,sizeof(keyhex),stdin)) return 1;
    keyhex[strcspn(keyhex,"\r\n")]=0;
    if(v3_start(argv[2],keyhex)) return 1;
    memset(keyhex,0,sizeof(keyhex));
    if(!strcmp(argv[1],"init")) {
        v3_initialize=1; SystemParams p;
        int rc=setup(&p); if(!rc) puts("IBEET_INIT_OK"); return rc;
    }
    if(!strcmp(argv[1],"provision") || !strcmp(argv[1],"check-user")) {
        char *id=field(); if(!id) return 1;
        SystemParams p; UserPrivateKey k; v3_provision=!strcmp(argv[1],"provision");
        int rc=setup(&p)||extract(&p,id,&k); free(id);
        if(!rc) puts(v3_provision?"IBEET_PROVISION_OK":"IBEET_CHECK_OK");
        return rc;
    }
    char *a=field(),*b=field(),*c=field();
    if(!a||!b||!c) { free(a);free(b);free(c);return 1; }
    int rc=1;
    if(!strcmp(argv[1],"encrypt")) rc=run_encrypt(a,b,c,1);
    else if(!strcmp(argv[1],"encrypt-v2")) rc=run_encrypt(a,b,c,2);
    else if(!strcmp(argv[1],"encrypt-v3")) rc=run_encrypt(a,b,c,3);
    else if(!strcmp(argv[1],"compare")) rc=run_compare(a,b,c,1);
    else if(!strcmp(argv[1],"compare-v2")) rc=run_compare(a,b,c,2);
    else if(!strcmp(argv[1],"compare-v3")) rc=run_compare(a,b,c,3);
    else {
        char *d=field();
        if(d) {
            if(!strcmp(argv[1],"match")) rc=run_match(a,b,c,d,1);
            else if(!strcmp(argv[1],"match-v2")) rc=run_match(a,b,c,d,2);
            else if(!strcmp(argv[1],"match-v3")) rc=run_match(a,b,c,d,3);
            else if(!strcmp(argv[1],"decrypt")) {
                char *e=field();
                if(e) { rc=run_decrypt(a,b,c,d,e);free(e); }
            }
            free(d);
        }
    }
    free(a);free(b);free(c);
    return rc;
}
