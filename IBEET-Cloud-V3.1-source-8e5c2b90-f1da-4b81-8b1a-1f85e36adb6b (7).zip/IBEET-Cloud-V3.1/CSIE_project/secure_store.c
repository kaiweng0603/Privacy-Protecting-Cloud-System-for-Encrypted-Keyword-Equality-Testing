#define _GNU_SOURCE
#include "secure_store.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <errno.h>
#include <openssl/evp.h>
#include <openssl/hmac.h>
#include <openssl/rand.h>
#include <pbc/pbc.h>
char v3_runtime[4096];
int v3_initialize=0,v3_provision=0;
static unsigned char root[32];
static int statefd=-1;
static int component(const char *name){return name&&name[0]&&!strchr(name,'/')&&!strchr(name,'\\')&&strcmp(name,".")&&strcmp(name,"..");}
static int walk_directory(int start,const char *relative){
 int fd=dup(start);if(fd<0)return -1;
 char *copy=strdup(relative),*save=NULL;if(!copy){close(fd);return -1;}
 for(char *s=strtok_r(copy,"/",&save);s;s=strtok_r(NULL,"/",&save)){
  if(!component(s)||!strcasecmp(s,"IBEET-Cloud-V1")||!strcasecmp(s,"IBEET-Cloud-V2")||!strcasecmp(s,"IBEET-Cloud-V3")){close(fd);free(copy);return -1;}
  int next=openat(fd,s,O_RDONLY|O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC);close(fd);fd=next;
  if(fd<0)break;
 }
 free(copy);return fd;
}
static void random_mpz(mpz_t out,mpz_t limit,void *unused){
 (void)unused;size_t n=(mpz_sizeinbase(limit,2)+7)/8;unsigned char *b=malloc(n);if(!b)exit(1);
 unsigned int bits=(unsigned int)(mpz_sizeinbase(limit,2)%8);
 do{if(RAND_bytes(b,(int)n)!=1)exit(1);if(bits)b[0]&=(1u<<bits)-1;mpz_import(out,n,1,1,0,0,b);}while(mpz_cmp(out,limit)>=0);
 OPENSSL_clear_free(b,n);
}
int v3_start(const char *directory,const char *keyhex){
 char executable[4096],project[4096];ssize_t n=readlink("/proc/self/exe",executable,sizeof(executable)-1);
 if(n<=0||n>=(ssize_t)sizeof(executable)-1||strlen(directory)>=sizeof(v3_runtime)||strlen(keyhex)!=64)return 1;
 executable[n]=0;char *last=strrchr(executable,'/');if(!last)return 1;*last=0;
 last=strrchr(executable,'/');if(!last||strcmp(last+1,"CSIE_project"))return 1;*last=0;strcpy(project,executable);
 last=strrchr(project,'/');if(!last||strcmp(last+1,"IBEET-Cloud-V3.1"))return 1;
 int slash=open("/",O_RDONLY|O_DIRECTORY|O_CLOEXEC);if(slash<0)return 1;
 int base=walk_directory(slash,project+1);close(slash);if(base<0)return 1;
 int marker=openat(base,".ibeet-v31",O_RDONLY|O_NOFOLLOW|O_CLOEXEC);char tag[32]={0};
 ssize_t got=marker<0?-1:read(marker,tag,sizeof(tag));if(marker>=0)close(marker);
 if(got!=(ssize_t)(sizeof("IBEET-CLOUD-V3.1\n")-1)||memcmp(tag,"IBEET-CLOUD-V3.1\n",sizeof("IBEET-CLOUD-V3.1\n")-1)){close(base);return 1;}
 int code=openat(base,"CSIE_project",O_RDONLY|O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC);
 if(code<0||fchdir(code)){if(code>=0)close(code);close(base);return 1;}close(code);
 size_t plen=strlen(project);
 if(strncmp(directory,project,plen)||directory[plen]!='/'){close(base);return 1;}
 const char *relative=directory+plen+1;
 if(strncmp(relative,"runtime-v31/",12)&&strncmp(relative,".test-runs/",11)){close(base);return 1;}
 /* Reject empty, dot, parent and repeated components before strtok collapses them. */
 if(strstr(relative,"//")||strstr(relative,"/./")||strstr(relative,"/../")||strchr(relative,'\\')){close(base);return 1;}
 statefd=walk_directory(base,relative);close(base);if(statefd<0)return 1;
 for(int i=0;i<32;i++){
  char a=keyhex[i*2],b=keyhex[i*2+1];
  if(!((a>='0'&&a<='9')||(a>='a'&&a<='f'))||!((b>='0'&&b<='9')||(b>='a'&&b<='f')))return 1;
  root[i]=(unsigned char)(((a<='9'?a-'0':a-'a'+10)<<4)|(b<='9'?b-'0':b-'a'+10));
 }
 int lock=openat(statefd,".lock",O_CREAT|O_RDWR|O_NOFOLLOW|O_CLOEXEC,0600);struct stat st;
 if(lock<0||fstat(lock,&st)||!S_ISREG(st.st_mode)||st.st_nlink!=1||flock(lock,LOCK_EX))return 1;
 strcpy(v3_runtime,directory);pbc_random_set_function(random_mpz,NULL);return 0;
}
int v3_exists(const char *name){
 if(statefd<0||!component(name))return -1;struct stat st;
 if(fstatat(statefd,name,&st,AT_SYMLINK_NOFOLLOW)==0)return S_ISREG(st.st_mode)&&st.st_nlink==1?1:-1;
 return errno==ENOENT?0:-1;
}
static void derive(const char *name,unsigned char key[32]){
 unsigned int n=0;const char *label=strcmp(name,"system.gcm")==0?"IBEET-V3/system-secret":"IBEET-V3/user-private-key";
 if(!HMAC(EVP_sha256(),root,32,(const unsigned char*)label,strlen(label),key,&n)||n!=32)exit(1);
}
static int write_all(int fd,const unsigned char *b,size_t n){
 while(n){ssize_t wrote=write(fd,b,n);if(wrote<0&&errno==EINTR)continue;if(wrote<=0)return 1;b+=wrote;n-=(size_t)wrote;}return 0;
}
int v3_save(const char *name,const char *context,const unsigned char *data,size_t length){
 if(length>65536||v3_exists(name)!=0)return 1;
 unsigned char *out=malloc(length+36),key[32],token[16];if(!out)return 1;
 memcpy(out,"IBEV3GCM",8);int n=0,total=0,ok=0,fd=-1;char temp[48]={0};
 EVP_CIPHER_CTX *c=EVP_CIPHER_CTX_new();derive(name,key);
 if(!c||RAND_bytes(out+8,12)!=1||EVP_EncryptInit_ex(c,EVP_aes_256_gcm(),NULL,key,out+8)!=1||EVP_EncryptUpdate(c,NULL,&n,(const unsigned char*)context,strlen(context))!=1||EVP_EncryptUpdate(c,out+36,&n,data,(int)length)!=1)goto done;
 total=n;
 if(EVP_EncryptFinal_ex(c,out+36+total,&n)!=1||EVP_CIPHER_CTX_ctrl(c,EVP_CTRL_GCM_GET_TAG,16,out+20)!=1)goto done;
 total+=n;if(RAND_bytes(token,sizeof(token))!=1)goto done;
 strcpy(temp,".new-");for(int i=0;i<16;i++)sprintf(temp+5+i*2,"%02x",token[i]);
 fd=openat(statefd,temp,O_CREAT|O_EXCL|O_WRONLY|O_NOFOLLOW|O_CLOEXEC,0600);
 if(fd<0||fchmod(fd,0600)||write_all(fd,out,(size_t)total+36)||fsync(fd))goto done;
 if(close(fd)){fd=-1;goto done;}fd=-1;
 if(linkat(statefd,temp,statefd,name,0)||unlinkat(statefd,temp,0)||fsync(statefd))goto done;
 temp[0]=0;ok=1;
 done:
 if(fd>=0)close(fd);if(temp[0])unlinkat(statefd,temp,0);
 EVP_CIPHER_CTX_free(c);OPENSSL_cleanse(key,32);OPENSSL_clear_free(out,length+36);return ok?0:1;
}
int v3_load(const char *name,const char *context,unsigned char **data,size_t *length){
 if(statefd<0||!component(name))return 1;
 int fd=openat(statefd,name,O_RDONLY|O_NOFOLLOW|O_CLOEXEC);struct stat st;
 if(fd<0)return 1;
 if(fstat(fd,&st)||!S_ISREG(st.st_mode)||st.st_nlink!=1||st.st_size<36||st.st_size>65572){close(fd);return 1;}
 size_t size=(size_t)st.st_size;unsigned char *in=malloc(size),*out=malloc(size),key[32];
 if(!in||!out){free(in);free(out);close(fd);return 1;}
 size_t offset=0;while(offset<size){ssize_t got=read(fd,in+offset,size-offset);if(got<0&&errno==EINTR)continue;if(got<=0)break;offset+=(size_t)got;}close(fd);
 int ok=0,n=0,total=0;EVP_CIPHER_CTX *c=EVP_CIPHER_CTX_new();derive(name,key);
 if(offset!=size||memcmp(in,"IBEV3GCM",8)||!c||EVP_DecryptInit_ex(c,EVP_aes_256_gcm(),NULL,key,in+8)!=1||EVP_DecryptUpdate(c,NULL,&n,(const unsigned char*)context,strlen(context))!=1||EVP_DecryptUpdate(c,out,&n,in+36,(int)size-36)!=1)goto done;
 total=n;if(EVP_CIPHER_CTX_ctrl(c,EVP_CTRL_GCM_SET_TAG,16,in+20)!=1||EVP_DecryptFinal_ex(c,out+total,&n)!=1)goto done;
 *length=(size_t)(total+n);*data=out;ok=1;
 done:
 EVP_CIPHER_CTX_free(c);OPENSSL_cleanse(key,32);OPENSSL_clear_free(in,size);if(!ok)OPENSSL_clear_free(out,size);return ok?0:1;
}
