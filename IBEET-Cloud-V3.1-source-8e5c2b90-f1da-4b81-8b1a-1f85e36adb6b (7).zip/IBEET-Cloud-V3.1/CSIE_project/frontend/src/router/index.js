import { createRouter, createWebHistory } from 'vue-router'
import LoginView from '../views/LoginView.vue'
import HomeView from '../views/HomeView.vue'
import AdminView from '../views/AdminView.vue'
import { refreshSession } from '../api/auth'
const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/', name: 'login', component: LoginView },
    { path: '/home', name: 'home', component: HomeView, meta: { role: 'USER' } },
    { path: '/admin', name: 'admin', component: AdminView, meta: { role: 'ADMIN' } },
    { path: '/:pathMatch(.*)*', redirect: '/' },
  ],
})
router.beforeEach(async (to) => {
  try {
    const user = await refreshSession()
    if (!user && to.meta.role) return '/'
    if (user && (!to.meta.role || user.role !== to.meta.role)) return user.role === 'ADMIN' ? '/admin' : '/home'
  } catch { if (to.path !== '/') return '/' }
})
export default router