export async function api(path, options = {}) {
  const headers = new Headers(options.headers)
  const method = (options.method || 'GET').toUpperCase()
  if (!['GET', 'HEAD', 'OPTIONS'].includes(method)) {
    const response = await fetch('/api/auth/csrf', { credentials: 'same-origin', cache: 'no-store' })
    if (!response.ok) throw new Error('無法取得安全驗證碼')
    const csrf = await response.json()
    headers.set(csrf.headerName, csrf.token)
  }
  const response = await fetch(path, { ...options, headers, credentials: 'same-origin', cache: 'no-store' })
  if (!response.ok) {
    const data = await response.json().catch(() => ({}))
    const error = new Error(data.message || (response.status === 401 ? '登入已逾時，請重新登入' : '操作失敗'))
    error.status = response.status
    if (response.status === 401 && window.location.pathname !== '/') window.location.assign('/?expired=1')
    throw error
  }
  if (options.blob) return response.blob()
  return response.json()
}
export function json(method, body) {
  return { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }
}