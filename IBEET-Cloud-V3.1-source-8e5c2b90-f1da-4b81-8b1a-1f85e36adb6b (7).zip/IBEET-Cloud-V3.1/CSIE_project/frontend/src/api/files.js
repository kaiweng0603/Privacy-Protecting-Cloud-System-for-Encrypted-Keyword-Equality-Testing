import { api, json } from './http'
export const getFiles = (page = 0) => api('/api/files/list?page=' + page + '&size=10')
export const searchFiles = (query, mode = 'all', page = 0) => api('/api/files/search?page=' + page + '&size=10', json('POST', { query, mode }))
export function uploadFile(file, keyword) {
  const body = new FormData()
  body.append('file', file)
  body.append('keyword', keyword || '')
  return api('/api/files/upload', { method: 'POST', body })
}
export const downloadFile = (id) => api('/api/files/download/' + encodeURIComponent(id), { blob: true })
export const renameFile = (id, fileName) => api('/api/files/' + id + '/rename', json('PATCH', { fileName }))
export const deleteFile = (id) => api('/api/files/' + id, { method: 'DELETE' })
