import { reactive } from 'vue'
import { api } from './http'
export const session = reactive({ user: null })
export async function refreshSession() {
  try { session.user = await api('/api/auth/me') }
  catch (error) { if (error.status !== 401) throw error; session.user = null }
  return session.user
}
export async function loginApi(username, password) {
  await api('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ username, password }),
  })
  return refreshSession()
}
export async function logoutApi() {
  await api('/api/auth/logout', { method: 'POST' })
  session.user = null
}