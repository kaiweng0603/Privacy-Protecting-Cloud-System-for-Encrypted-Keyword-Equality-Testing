<template>
  <div class="home-page">
    <header class="navbar">
      <div class="logo"><v-icon>mdi-cloud</v-icon> IBEET Cloud Storage</div>
      <div class="user-area"><span>使用者：{{ session.user?.username }}</span><v-btn variant="text" color="white" prepend-icon="mdi-logout" @click="logout">登出</v-btn></div>
    </header>
    <main class="content">
      <div class="title-row">
        <div><h1>我的檔案</h1><p>檔案以 AES-GCM 加密，關鍵字透過 IBEET 密文比對</p></div>
        <v-btn color="primary" prepend-icon="mdi-upload" :loading="uploading" :disabled="busy" @click="fileInput?.click()">上傳檔案</v-btn>
        <input ref="fileInput" type="file" hidden @change="upload" />
      </div>
      <div class="upload-panel"><v-text-field v-model="uploadKeyword" label="上傳索引關鍵字（選填）" placeholder="例如：ocean2026, 報告" variant="outlined" hide-details class="keyword-input" /><span class="hint">多個關鍵字以逗號分隔，每個檔案最多 32 個</span></div>
      <div class="search-panel">
        <v-select v-model="searchMode" :items="modes" label="搜尋方式" variant="outlined" hide-details class="mode-input" />
        <v-text-field v-model="searchQuery" label="搜尋檔案" placeholder="檔名或完整關鍵字" variant="outlined" hide-details clearable class="search-input" @keyup.enter="search" @click:clear="reset" />
        <v-btn color="primary" :loading="searching" :disabled="busy" @click="search">搜尋</v-btn>
        <v-btn variant="outlined" :disabled="busy" @click="reset">顯示全部</v-btn>
      </div>
      <p class="search-hint">新索引使用 hashVersion 3，區分大小寫。多詞採 OR；片語加雙引號。每頁檢查 10 個候選檔案，請用下一頁繼續搜尋；超過工作量或時間限制會明確提示。</p>
      <v-alert v-if="message" :type="messageType" variant="tonal" closable class="mb-5" @click:close="message = ''">{{ message }}</v-alert>
      <div class="breadcrumb"><v-icon size="20">mdi-home</v-icon> 我的檔案 · {{ files.length }} 筆</div>
      <div class="search-panel"><v-btn :disabled="busy || loading || searching || page === 0" @click="changePage(-1)">上一頁</v-btn><span>候選檔案第 {{ page + 1 }} 頁 · 共 {{ candidateTotal }} 個檔案</span><v-btn :disabled="busy || loading || searching || !hasNext" @click="changePage(1)">下一頁</v-btn></div>
      <div class="file-area">
        <div class="file-header"><span>檔名</span><span>大小</span><span>操作</span></div>
        <div v-if="loading || searching" class="empty"><v-progress-circular indeterminate color="primary" /><p>正在載入...</p></div>
        <template v-else>
          <div v-for="file in files" :key="file.fileId" class="file-item">
            <div class="file-name"><v-icon size="38" color="primary">mdi-file-document</v-icon><div><strong>{{ file.fileName }}</strong><p>{{ new Date(file.createdAt).toLocaleString('zh-TW') }} <span v-if="file.matchType === 'ibeet'" class="match-label">· IBEET 關鍵字符合</span><span v-if="file.matchType === 'filename'" class="match-label">· 檔名符合</span></p></div></div>
            <span>{{ formatSize(file.size) }}</span>
            <v-menu><template #activator="{ props }"><v-btn v-bind="props" icon="mdi-dots-vertical" variant="text" :disabled="busy" :aria-label="'操作 ' + file.fileName" /></template>
              <v-list>
                <v-list-item title="下載" prepend-icon="mdi-download" @click="download(file)" />
                <v-list-item title="重新命名" prepend-icon="mdi-pencil" @click="openRename(file)" />
                <v-list-item title="關鍵字管理" prepend-icon="mdi-tag" @click="openKeywords(file)" />
                <v-list-item title="刪除" prepend-icon="mdi-delete" @click="remove(file)" />
              </v-list>
            </v-menu>
          </div>
          <div v-if="!files.length" class="empty"><v-icon size="60">mdi-folder-open-outline</v-icon><p>沒有找到檔案</p></div>
        </template>
      </div>
      <v-dialog v-model="renameDialog" max-width="450"><v-card><v-card-title>重新命名檔案</v-card-title><v-card-text><v-text-field v-model="renameName" label="新檔名" variant="outlined" @keyup.enter="rename" /></v-card-text><v-card-actions><v-spacer /><v-btn :disabled="busy" @click="renameDialog = false">取消</v-btn><v-btn color="primary" :loading="busy" @click="rename">儲存</v-btn></v-card-actions></v-card></v-dialog>
      <v-dialog v-model="keywordDialog" max-width="550"><v-card><v-card-title>關鍵字管理</v-card-title><v-card-text><p class="mb-4">檔案：<strong>{{ selected?.fileName }}</strong></p>
        <v-text-field v-model="newKeywords" label="新增關鍵字" placeholder="例如：Java, 資料庫" variant="outlined" @keyup.enter="addKeywords" />
        <v-btn color="primary" block :loading="busy" :disabled="!newKeywords.trim()" @click="addKeywords">新增關鍵字</v-btn>
        <v-alert v-if="keywordError" type="error" class="mt-4">{{ keywordError }}</v-alert>
        <div v-if="keywordLoading" class="empty">載入中...</div>
        <v-list v-else><v-list-subheader>目前的關鍵字索引（{{ keywords.length }}）</v-list-subheader><v-list-item v-for="item in keywords" :key="item.indexId" :title="item.keyword" prepend-icon="mdi-tag"><template #append><v-btn icon="mdi-delete" variant="text" :disabled="busy" :aria-label="'刪除關鍵字 ' + item.keyword" @click="removeKeyword(item)" /></template></v-list-item></v-list>
      </v-card-text><v-card-actions><v-spacer /><v-btn :disabled="busy" @click="keywordDialog = false">關閉</v-btn></v-card-actions></v-card></v-dialog>
    </main>
  </div>
</template>
<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { session, logoutApi } from '@/api/auth'
import { api, json } from '@/api/http'
import { getFiles, searchFiles, uploadFile, downloadFile, renameFile, deleteFile } from '@/api/files'
const router = useRouter()
const files = ref([]), fileInput = ref(null), uploadKeyword = ref(''), searchQuery = ref(''), searchMode = ref('all')
const loading = ref(false), searching = ref(false), uploading = ref(false), busy = ref(false)
const page = ref(0), hasNext = ref(false), candidateTotal = ref(0)
const message = ref(''), messageType = ref('success')
const selected = ref(null), renameDialog = ref(false), renameName = ref('')
const keywordDialog = ref(false), keywordLoading = ref(false), keywordError = ref(''), keywords = ref([]), newKeywords = ref('')
const modes = [{ title: '檔名與關鍵字', value: 'all' }, { title: '僅 IBEET 關鍵字', value: 'keyword' }, { title: '僅檔名', value: 'filename' }]
function notice(text, type = 'success') { message.value = text; messageType.value = type }
async function load() {
  loading.value = true
  try { setPage(await getFiles(page.value)) } catch (e) { notice(e.message, 'error') } finally { loading.value = false }
}
function setPage(data) { files.value = data.items; hasNext.value = data.hasNext; candidateTotal.value = data.candidateTotal }
async function search(keepPage = false) {
  if (keepPage !== true) page.value = 0
  searching.value = true
  try { setPage(await searchFiles(searchQuery.value || '', searchMode.value, page.value)) }
  catch (e) { files.value = []; hasNext.value = false; notice(e.message, 'error') } finally { searching.value = false }
}
async function reset() { searchQuery.value = ''; page.value = 0; await load() }
async function refresh() { if (searchQuery.value?.trim()) await search(true); else await load() }
async function changePage(delta) { page.value += delta; await refresh() }
async function upload(event) {
  const file = event.target.files?.[0]
  if (!file) return
  if (file.size > 20 * 1024 * 1024) { notice('檔案不可超過 20 MB', 'error'); event.target.value = ''; return }
  uploading.value = true; busy.value = true
  try { await uploadFile(file, uploadKeyword.value); uploadKeyword.value = ''; await reset(); notice('檔案已加密上傳') }
  catch (e) { notice(e.message, 'error') }
  finally { uploading.value = false; busy.value = false; event.target.value = '' }
}
async function download(file) {
  busy.value = true
  try {
    const blob = await downloadFile(file.fileId)
    const url = URL.createObjectURL(blob), link = document.createElement('a')
    link.href = url; link.download = file.fileName; document.body.appendChild(link); link.click(); link.remove()
    setTimeout(() => URL.revokeObjectURL(url), 1000); notice('檔案下載成功')
  } catch (e) { notice(e.message, 'error') } finally { busy.value = false }
}
function openRename(file) { selected.value = file; renameName.value = file.fileName; renameDialog.value = true }
async function rename() {
  if (busy.value) return
  busy.value = true
  try { await renameFile(selected.value.fileId, renameName.value); renameDialog.value = false; await refresh(); notice('重新命名成功') }
  catch (e) { notice(e.message, 'error') } finally { busy.value = false }
}
async function remove(file) {
  if (!confirm('確定永久刪除「' + file.fileName + '」及其關鍵字索引？')) return
  busy.value = true
  try { await deleteFile(file.fileId); await refresh(); notice('檔案已刪除') }
  catch (e) { notice(e.message, 'error') } finally { busy.value = false }
}
async function openKeywords(file) { selected.value = file; keywords.value = []; newKeywords.value = ''; keywordDialog.value = true; await loadKeywords() }
async function loadKeywords() {
  keywordLoading.value = true; keywordError.value = ''
  try { keywords.value = (await api('/api/files/' + selected.value.fileId + '/keywords')).keywords }
  catch (e) { keywordError.value = e.message } finally { keywordLoading.value = false }
}
async function addKeywords() {
  if (busy.value) return
  busy.value = true; keywordError.value = ''
  try { await api('/api/files/' + selected.value.fileId + '/keywords', json('POST', { keyword: newKeywords.value })); newKeywords.value = ''; await loadKeywords(); await refresh() }
  catch (e) { keywordError.value = e.message } finally { busy.value = false }
}
async function removeKeyword(item) {
  if (!confirm('刪除關鍵字「' + item.keyword + '」？')) return
  busy.value = true; keywordError.value = ''
  try { await api('/api/files/' + selected.value.fileId + '/keywords/' + item.indexId, { method: 'DELETE' }); await loadKeywords(); await refresh() }
  catch (e) { keywordError.value = e.message } finally { busy.value = false }
}
async function logout() {
  try { await logoutApi(); await router.push('/') } catch (e) { notice(e.message, 'error') }
}
function formatSize(bytes) { return bytes < 1024 ? bytes + ' B' : (bytes / 1024).toFixed(1) + ' KB' }
onMounted(load)
</script>
<style scoped>
.home-page { min-height:100vh; background:#f5f7fa; }
.navbar { min-height:70px; background:#1976d2; color:white; display:flex; align-items:center; justify-content:space-between; padding:14px 40px; gap:20px; box-shadow:0 2px 8px #0002; }
.logo { display:flex; align-items:center; gap:10px; font-size:22px; font-weight:bold; }
.user-area { display:flex; align-items:center; gap:15px; }
.content { max-width:1100px; margin:auto; padding:40px; }
.title-row { display:flex; justify-content:space-between; align-items:center; gap:20px; margin-bottom:20px; }
.title-row h1 { margin:0; font-size:32px; color:#222; }.title-row p { margin-top:6px; color:#777; }
.upload-panel,.search-panel { display:flex; align-items:center; gap:12px; margin-bottom:14px; }
.keyword-input { max-width:380px; background:white; }.mode-input { min-width:180px; max-width:220px; background:white; }.search-input { flex:1; background:white; }
.hint,.search-hint { color:#777; font-size:13px; }.search-hint { margin-bottom:20px; }.breadcrumb { display:flex; align-items:center; gap:8px; margin-bottom:15px; color:#555; }
.file-area { background:white; border-radius:15px; overflow:hidden; box-shadow:0 3px 12px #0001; }
.file-header,.file-item { display:grid; grid-template-columns:minmax(0,1fr) 100px 60px; align-items:center; padding:20px 25px; border-bottom:1px solid #eee; }
.file-header { background:#fafafa; color:#777; font-weight:bold; }.file-item:hover { background:#f8faff; }
.file-name { display:flex; align-items:center; gap:18px; min-width:0; }.file-name strong { font-size:17px; color:#222; overflow-wrap:anywhere; }.file-name p { margin:4px 0 0; color:#999; font-size:13px; }.match-label { color:#1976d2; }
.empty { padding:60px 20px; text-align:center; color:#999; }
@media(max-width:700px) { .navbar { padding:14px 16px; flex-wrap:wrap; }.content { padding:20px 12px; }.title-row,.upload-panel,.search-panel { flex-direction:column; align-items:stretch; }.keyword-input,.mode-input { max-width:none; }.file-header,.file-item { grid-template-columns:minmax(0,1fr) 65px 45px; padding:14px 10px; }.file-name { gap:8px; } }
</style>
