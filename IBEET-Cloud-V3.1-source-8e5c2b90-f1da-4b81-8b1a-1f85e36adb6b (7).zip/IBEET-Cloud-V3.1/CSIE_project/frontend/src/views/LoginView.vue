
<template>
  <div class="login-page">
    <div class="login-card">
      <h1>IBEET Cloud Storage</h1>

      <p class="subtitle">登入個人加密雲端</p>

      <v-text-field
        v-model="email"
        label="帳號"
        prepend-inner-icon="mdi-email"
        variant="outlined"
        class="input"
      />

      <v-text-field
        v-model="password"
        label="密碼" autocomplete="current-password"
        prepend-inner-icon="mdi-lock"
        type="password"
        variant="outlined"
        class="input"
        @keyup.enter="login"
      />

      <v-btn
        color="primary"
        size="large"
        block
        :loading="loading"
        :disabled="loading"
        @click="login"
      >
        登入
      </v-btn>

      <p v-if="errorMessage" class="error-message">
        {{ errorMessage }}
      </p>

      <p class="register">帳號由本機安全初始化建立。<br>伺服器端加密 · Session 身分驗證</p>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { loginApi } from '@/api/auth'

const router = useRouter()

const email = ref('')
const password = ref('')
const loading = ref(false)
const errorMessage = ref('')

async function login() {
  if (loading.value) return

  errorMessage.value = ''

  if (!email.value.trim() || !password.value) {
    errorMessage.value = '請輸入帳號與密碼'
    return
  }

  loading.value = true

  try {
    const result = await loginApi(
      email.value.trim(),
      password.value
    )

    password.value = ''
    await router.push(result.role === 'ADMIN' ? '/admin' : '/home')
  } catch (error) {
    console.error('Login error:', error)

    errorMessage.value = error.message || '無法連線到後端'
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.login-page {
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  background: #1f1f1f;
}

.login-card {
  width: 360px;
  padding: 35px;
  background: white;
  border-radius: 20px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4);
}

h1 {
  text-align: center;
  font-size: 28px;
  margin-bottom: 8px;
  color: #111;
}

.subtitle {
  text-align: center;
  color: #888;
  margin-bottom: 30px;
}

.input {
  margin-bottom: 12px;
}

.register {
  text-align: center;
  margin-top: 25px;
  color: #333;
}

.register span {
  color: #1976d2;
  margin-left: 5px;
  cursor: pointer;
}

.error-message {
  color: #d32f2f;
  text-align: center;
  margin-top: 12px;
  font-size: 14px;
}
</style>

