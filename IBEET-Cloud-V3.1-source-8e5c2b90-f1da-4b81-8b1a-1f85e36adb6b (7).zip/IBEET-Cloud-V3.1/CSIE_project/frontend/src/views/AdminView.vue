<template>
  <div class="admin-page">
    <header><h1>IBEET 管理後台</h1><div>{{ session.user?.username }} · ADMIN <v-btn variant="text" color="white" @click="logout">登出</v-btn></div></header>
    <main>
      <v-alert type="info" variant="tonal" class="mb-5">本後台提供帳號狀態及真實密文資訊。系統採伺服器端加密；作業系統操作者仍位於信任邊界內。</v-alert>
      <v-alert v-if="error" type="error" class="mb-4">{{ error }}</v-alert>
      <v-btn :loading="loading" class="mb-5" @click="load">重新整理</v-btn>
      <template v-if="data">
        <div class="stats"><v-card v-for="item in stats" :key="item.title" class="pa-6"><div>{{ item.title }}</div><strong>{{ item.value }}</strong></v-card></div>
        <v-card class="pa-5 mb-5"><h2>帳號管理</h2><p>停用立即阻擋現有 Session，並禁止再次登入。帳號建立與密碼設定由本機操作者執行。</p>
          <v-table><thead><tr><th>帳號</th><th>角色</th><th>狀態</th><th>操作</th></tr></thead><tbody><tr v-for="u in users" :key="u.id"><td>{{ u.username }}</td><td>{{ u.role }}</td><td>{{ u.enabled ? '啟用' : '停用' }}</td><td><v-btn v-if="u.role === 'USER'" size="small" :disabled="loading" @click="toggle(u)">{{ u.enabled ? '停用' : '啟用' }}</v-btn></td></tr></tbody></v-table>
        </v-card>
        <v-card class="pa-5 mb-5"><h2>加密私鑰儲存狀態</h2><div v-for="key in data.privateKeys" :key="key.username" class="record"><h3>{{ key.username }} · {{ key.format }} · {{ key.bytes }} bytes</h3><code>{{ key.ciphertext }}</code></div></v-card>
        <v-card class="pa-5 mb-5"><h2>AES 加密檔案資訊</h2><p>展示實際資料庫密文前 192 字元，每頁最多 10 筆。</p><v-btn :disabled="loading || filePage === 0" @click="moveFiles(-1)">上一頁</v-btn><span> 第 {{ filePage + 1 }} 頁 </span><v-btn :disabled="loading || !data.pagination.filesHasNext" @click="moveFiles(1)">下一頁</v-btn><div v-for="file in data.encryptedFiles" :key="file.fileId" class="record"><p>檔案 #{{ file.fileId }} · {{ file.algorithm }} · 原始大小 {{ file.size }} bytes · 金鑰封裝 {{ file.protectedFileKeyFormat }}</p><p>Nonce：<code>{{ file.nonce }}</code></p><code>{{ file.ciphertextPreview }}</code></div></v-card>
        <v-card class="pa-5 mb-5"><h2>IBEET 密文索引</h2><v-btn :disabled="loading || indexPage === 0" @click="moveIndexes(-1)">上一頁</v-btn><span> 第 {{ indexPage + 1 }} 頁 </span><v-btn :disabled="loading || !data.pagination.indexesHasNext" @click="moveIndexes(1)">下一頁</v-btn><v-expansion-panels><v-expansion-panel v-for="index in data.encryptedIndexes" :key="index.indexId" :title="'索引 #' + index.indexId + ' · 檔案 #' + index.fileId + ' · hashVersion ' + index.hashVersion"><v-expansion-panel-text><div v-for="field in ['c1','c2','c3','c4']" :key="field"><p>{{ field }}</p><code>{{ index[field] }}</code></div></v-expansion-panel-text></v-expansion-panel></v-expansion-panels></v-card>
        <v-card class="pa-5"><h2>系統運作狀態</h2><p>資料庫：{{ data.system.database }} · 系統秘密密文：{{ data.system.systemCipherPresent ? '存在' : '遺失' }} · Session：{{ data.system.sessionTimeoutMinutes }} 分鐘</p></v-card>
      </template>
    </main>
  </div>
</template>
<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { session, logoutApi } from '@/api/auth'
import { api, json } from '@/api/http'
const router = useRouter()
const data = ref(null), users = ref([]), loading = ref(false), error = ref('')
const filePage = ref(0), indexPage = ref(0)
const stats = computed(() => [{ title: '使用者數量', value: data.value?.userCount }, { title: '檔案數量', value: data.value?.fileCount }, { title: '密文索引數量', value: data.value?.indexCount }])
async function load() {
  loading.value = true; error.value = ''
  try { [data.value, users.value] = await Promise.all([api('/api/admin/dashboard?filePage=' + filePage.value + '&indexPage=' + indexPage.value), api('/api/admin/users')]) }
  catch (e) { error.value = e.message }
  finally { loading.value = false }
}
async function toggle(u) {
  try { await api('/api/admin/users/' + u.id, json('PATCH', { enabled: !u.enabled })); await load() }
  catch (e) { error.value = e.message }
}
async function moveFiles(delta) { filePage.value += delta; await load() }
async function moveIndexes(delta) { indexPage.value += delta; await load() }
async function logout() {
  try { await logoutApi(); await router.push('/') } catch (e) { error.value = e.message }
}
onMounted(load)
</script>
<style scoped>
.admin-page { min-height: 100vh; background: #f5f7fa; }
header { background: #1976d2; color: white; padding: 20px 40px; display: flex; align-items: center; justify-content: space-between; gap: 20px; }
header h1 { font-size: 24px; } main { max-width: 1200px; margin: auto; padding: 32px; }
.stats { display: grid; grid-template-columns: repeat(3,1fr); gap: 20px; margin-bottom: 24px; }.stats strong { font-size: 36px; }
h2 { font-size: 21px; margin-bottom: 14px; } p { margin: 10px 0; } code { display: inline-block; max-width: 100%; overflow-wrap: anywhere; font-size: 12px; padding: 8px; background: #eef2f6; }
.record { padding: 18px 0; border-bottom: 1px solid #ddd; }
@media(max-width:700px) { .stats { grid-template-columns: 1fr; } header { padding:16px; flex-wrap:wrap; } main { padding:16px; } }
</style>

