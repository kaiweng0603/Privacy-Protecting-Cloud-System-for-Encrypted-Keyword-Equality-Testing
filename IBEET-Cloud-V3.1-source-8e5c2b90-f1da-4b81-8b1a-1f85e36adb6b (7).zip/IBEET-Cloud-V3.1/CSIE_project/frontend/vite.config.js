
import { fileURLToPath, URL } from 'node:url'
import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import vuetify from 'vite-plugin-vuetify'

export default defineConfig({
  plugins: [
    vue(),
    vuetify(),
  ],

  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url)),
    },
  },

  server: {
    port: 5176,
    strictPort: true,
    host: 'localhost',
    proxy: {
      '/api': { target: 'http://127.0.0.1:8083' },
    },

    fs: {
      allow: [
        fileURLToPath(new URL('.', import.meta.url)),
      ],
    },
  },
})
