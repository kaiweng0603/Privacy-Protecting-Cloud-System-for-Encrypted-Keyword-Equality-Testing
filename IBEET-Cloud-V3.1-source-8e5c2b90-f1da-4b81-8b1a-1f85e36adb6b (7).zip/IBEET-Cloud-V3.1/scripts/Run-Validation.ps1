param([switch]$Offline,[string]$MavenExecutable)
. "$PSScriptRoot/Common.ps1"
$run = Assert-V3Path (Join-Path $script:V3Root ('.test-runs/validation-'+[guid]::NewGuid()))
[IO.Directory]::CreateDirectory($run)|Out-Null
$results=[Collections.Generic.List[object]]::new()
function Invoke-Recorded([string]$Name,[string]$Directory,[scriptblock]$Action) {
    $log=Assert-V3Path (Join-Path $run ($Name+'.txt'))
    $start=[DateTimeOffset]::Now
    Push-Location $Directory
    try { & $Action 2>&1 | Tee-Object -FilePath $log; $code=$LASTEXITCODE }
    catch { $_.Exception.Message | Add-Content -LiteralPath $log; $code=1 }
    finally { Pop-Location }
    $results.Add(@{name=$Name;exitCode=$code;startedAt=$start.ToString('o');finishedAt=[DateTimeOffset]::Now.ToString('o')})
    $report=Join-Path $script:V3Root 'backend/target/surefire-reports'
    if ($Name -like 'java-*' -and (Test-Path -LiteralPath $report)) {
        $copy=Assert-V3Path (Join-Path $run $Name);[IO.Directory]::CreateDirectory($copy)|Out-Null
        foreach($file in Get-ChildItem -LiteralPath $report -File){if($file.Extension -in @('.xml','.txt')){Copy-Item -LiteralPath $file.FullName -Destination (Join-Path $copy $file.Name)}}
    }
}
$source=@()
foreach($folder in @('backend/src','CSIE_project','scripts')){
    foreach($f in Get-ChildItem -LiteralPath (Join-Path $script:V3Root $folder) -Recurse -File){
        $relative=$f.FullName.Substring($script:V3Root.Length+1).Replace('\','/')
        if($relative -notmatch '(^|/)(node_modules|dist|target|__pycache__)/' -and ($f.Name -eq 'Makefile' -or $f.Extension -in @('.java','.c','.h','.js','.vue','.properties','.ps1','.py','.xml','.json','.param'))){
            $source+=@{path=$relative;sha256=(Get-FileHash -LiteralPath (Assert-V3Path $f.FullName) -Algorithm SHA256).Hash.ToLowerInvariant()}
        }
    }
}
$source|ConvertTo-Json -Depth 4|Set-Content -LiteralPath (Join-Path $run 'tested-source.json') -Encoding utf8
if (-not $MavenExecutable) { $MavenExecutable=Join-Path $script:V3Root 'backend/mvnw.cmd' }
$cPath=Get-V31WslPath (Join-Path $script:V3Root 'CSIE_project')
Invoke-Recorded 'c-real-compile-and-regression' $script:V3Root { & wsl.exe -d Ubuntu-26.04 --cd $cPath --exec make -B test-v31 }
$mavenOptions=@('-B','-ntp',"-Dmaven.repo.local=$script:V3Root/.cache/m2")
if($Offline){$mavenOptions+='-o'}
Invoke-Recorded 'java-security-components' (Join-Path $script:V3Root 'backend') { & $MavenExecutable @mavenOptions '-Dtest=V31RegressionTests' test }
Invoke-Recorded 'java-full-package' (Join-Path $script:V3Root 'backend') { & $MavenExecutable @mavenOptions package }
Invoke-Recorded 'frontend-build' (Join-Path $script:V3Root 'CSIE_project/frontend') { & npm.cmd run build }
Invoke-Recorded 'frontend-lint' (Join-Path $script:V3Root 'CSIE_project/frontend') { & node.exe node_modules/eslint/bin/eslint.js src/api src/router src/views/HomeView.vue src/views/LoginView.vue src/views/AdminView.vue }
$results|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $run 'exit-codes.json') -Encoding utf8
Write-Host "驗證記錄：$run（僅限測試資料；原始 XML 含系統屬性，交付前需去除秘密）"
if(@($results|Where-Object{$_.exitCode -ne 0}).Count){throw '有驗證失敗；不得標示全面通過'}
