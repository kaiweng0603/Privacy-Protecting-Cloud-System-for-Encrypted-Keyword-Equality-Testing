$ErrorActionPreference = 'Stop'
$script:V3Root = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
if ((Split-Path $script:V3Root -Leaf) -cne 'IBEET-Cloud-V3.1') { throw '只允許獨立 IBEET-Cloud-V3.1 目錄。' }
if (($script:V3Root -split '[\\/]') | Where-Object { $_ -in @('IBEET-Cloud-V1','IBEET-Cloud-V2','IBEET-Cloud-V3') }) { throw '不可放在舊專案內。' }
function Assert-V3Path([string]$Path) {
    if ($Path -match '(^|[\\/])\.\.?([\\/]|$)') { throw '路徑不可含 dot 跳脫片段' }
    $resolved = [IO.Path]::GetFullPath($Path)
    if (-not $resolved.StartsWith($script:V3Root + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw '路徑超出獨立 V3.1' }
    $candidate = $resolved
    while ($candidate) {
        if (Test-Path -LiteralPath $candidate) {
            $item = Get-Item -LiteralPath $candidate -Force
            if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw '拒絕祖先重新解析點或符號連結' }
        }
        $candidate = [IO.Path]::GetDirectoryName($candidate)
    }
    return $resolved
}
$marker = Assert-V3Path (Join-Path $script:V3Root '.ibeet-v31')
if (-not (Test-Path -LiteralPath $marker) -or [IO.File]::ReadAllText($marker) -cne "IBEET-CLOUD-V3.1`n") { throw 'V3.1 標記不符' }
$env:IBEET_V31_ROOT = $script:V3Root.Replace('\','/')
function Get-V31WslPath([string]$Path) {
    $p = (Assert-V3Path $Path).Replace('\','/')
    if ($p -notmatch '^([A-Za-z]):/(.*)$') { throw '只支援本機磁碟 WSL 對應' }
    return '/mnt/' + $Matches[1].ToLowerInvariant() + '/' + $Matches[2]
}
function Protect-V3Directory([string]$Path) {
    $safePath = Assert-V3Path $Path
    $sid = [Security.Principal.WindowsIdentity]::GetCurrent().User
    $acl = New-Object Security.AccessControl.DirectorySecurity
    $acl.SetOwner($sid); $acl.SetAccessRuleProtection($true, $false)
    $rule = New-Object Security.AccessControl.FileSystemAccessRule($sid,'FullControl','ContainerInherit,ObjectInherit','None','Allow')
    $acl.AddAccessRule($rule); Set-Acl -LiteralPath $safePath -AclObject $acl
    $verifiedAcl = Get-Acl -LiteralPath $safePath
    if (-not $verifiedAcl.AreAccessRulesProtected) { throw 'ACL 未生效，拒絕寫入金鑰' }
    foreach ($entry in $verifiedAcl.Access) {
        if ($entry.AccessControlType -eq 'Allow' -and $entry.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value -ne $sid.Value) { throw 'ACL 包含其他身分，拒絕寫入金鑰' }
    }
}
function Assert-V3Runtime {
    $secret = Assert-V3Path (Join-Path $script:V3Root 'runtime-v31/secrets/root.key')
    if (-not (Test-Path -LiteralPath $secret) -or (Get-Item -LiteralPath $secret).Length -ne 32) { throw '尚未初始化或根金鑰格式錯誤；不會重新產生' }
    $sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    foreach ($entry in (Get-Acl -LiteralPath $secret).Access) {
        if ($entry.AccessControlType -eq 'Allow' -and $entry.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value -notin @($sid,'S-1-5-18','S-1-5-32-544')) { throw '根金鑰 ACL 過寬' }
    }
}
