. "$PSScriptRoot/Common.ps1"
Assert-V3Runtime
Push-Location (Join-Path $script:V3Root 'CSIE_project/frontend')
try {
    & npm.cmd run dev
    if ($LASTEXITCODE -ne 0) { throw '前端啟動失敗。' }
} finally { Pop-Location }

