. "$PSScriptRoot/Common.ps1"
Add-Type -AssemblyName System.IO.Compression.FileSystem
$destination = Assert-V3Path (Join-Path $script:V3Root 'artifacts')
[IO.Directory]::CreateDirectory($destination) | Out-Null
$sources = [Collections.Generic.List[string]]::new()
foreach ($name in @('.ibeet-v31','.gitignore','README.md','WINDOWS_SETUP.md','SECURITY.md','MIGRATION.md','TEST_REPORT.md','CHANGELOG.md','SOURCE_ANALYSIS.md','DEMO_GUIDE.md','TASKS.md','HASH_VERSION3_DESIGN.md','V3_BASELINE_MANIFEST.json','backend/pom.xml','backend/mvnw','backend/mvnw.cmd','backend/.gitignore','backend/.gitattributes','backend/.mvn/wrapper/maven-wrapper.properties','CSIE_project/Makefile','CSIE_project/frontend/package.json','CSIE_project/frontend/package-lock.json','CSIE_project/frontend/vite.config.js','CSIE_project/frontend/index.html','CSIE_project/frontend/jsconfig.json','CSIE_project/frontend/eslint.config.js')) {
    $sources.Add((Assert-V3Path (Join-Path $script:V3Root $name)))
}
foreach ($folder in @('backend/src','CSIE_project/frontend/src','CSIE_project/frontend/public','CSIE_project/tests','scripts')) {
    $path = Assert-V3Path (Join-Path $script:V3Root $folder)
    foreach ($file in Get-ChildItem -LiteralPath $path -Recurse -File) { $sources.Add((Assert-V3Path $file.FullName)) }
}
foreach ($file in Get-ChildItem -LiteralPath (Join-Path $script:V3Root 'CSIE_project') -File) { if ($file.Extension -in @('.c','.h')) { $sources.Add((Assert-V3Path $file.FullName)) } }
foreach ($file in Get-ChildItem -LiteralPath (Join-Path $script:V3Root 'CSIE_project/param') -Filter '*.param' -File) { $sources.Add((Assert-V3Path $file.FullName)) }
$evidence = Join-Path $script:V3Root 'evidence'
if (Test-Path -LiteralPath $evidence) {
    foreach ($file in Get-ChildItem -LiteralPath $evidence -File) { if ($file.Extension -notin @('.json','.txt','.xml','.md')) { throw '證據僅接受已去除秘密的文字檔' }; $sources.Add((Assert-V3Path $file.FullName)) }
}
$manifest = [Collections.Generic.List[object]]::new()
$archivePath = Assert-V3Path (Join-Path $destination ('IBEET-Cloud-V3.1-source-'+[guid]::NewGuid()+'.zip'))
$archive = [IO.Compression.ZipFile]::Open($archivePath,[IO.Compression.ZipArchiveMode]::Create)
try {
    foreach ($source in ($sources | Sort-Object -Unique)) {
        $relative = $source.Substring($script:V3Root.Length+1).Replace('\','/')
        if ($relative -match '(^|/)(target|node_modules|runtime-v3|runtime-v31|data|user_keys|migration|\.cache|\.test-runs|__pycache__)(/|$)' -or $relative -match '\.(key|pem|gcm|db|log|pyc)$' -or $relative -match 'ibeet_system') { throw '拒絕封裝執行資料或敏感檔案' }
        $manifest.Add(@{path=$relative;sha256=(Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant()})
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$source,('IBEET-Cloud-V3.1/'+$relative),[IO.Compression.CompressionLevel]::Optimal) | Out-Null
    }
    $entry = $archive.CreateEntry('IBEET-Cloud-V3.1/SOURCE_MANIFEST.json')
    $writer = [IO.StreamWriter]::new($entry.Open(),[Text.UTF8Encoding]::new($false))
    try { $writer.Write(($manifest | ConvertTo-Json -Depth 4)) } finally { $writer.Dispose() }
} finally { $archive.Dispose() }
Get-FileHash -LiteralPath $archivePath -Algorithm SHA256 | Select-Object Path,Hash
