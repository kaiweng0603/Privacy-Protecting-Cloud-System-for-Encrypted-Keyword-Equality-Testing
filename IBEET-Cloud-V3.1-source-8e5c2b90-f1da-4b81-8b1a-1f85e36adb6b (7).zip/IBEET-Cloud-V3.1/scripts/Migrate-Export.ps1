param(
    [Parameter(Mandatory=$true)][string]$Manifest,
    [switch]$Execute
)
# PowerShell 7+: inspect a user's deliberate plaintext export in V3, then
# re-encrypt through the authenticated V3 API. Never opens legacy DB/key files.
. "$PSScriptRoot/Common.ps1"
if ($PSVersionTable.PSVersion.Major -lt 7) { throw '請使用 PowerShell 7' }
$inbox = Assert-V3Path (Join-Path $script:V3Root 'migration/inbox')
$manifestPath = Assert-V3Path $Manifest
if (-not $manifestPath.StartsWith($inbox+'\',[StringComparison]::OrdinalIgnoreCase) -or -not $manifestPath.EndsWith('.json')) { throw '清單必須位於 V3 migration/inbox' }
$inputData = Get-Content -LiteralPath $manifestPath -Raw -Encoding utf8 | ConvertFrom-Json
if (-not $inputData.files -or $inputData.files.Count -gt 1000) { throw '匯出清單必須有 1–1000 個檔案' }
$verified = [Collections.Generic.List[object]]::new()
foreach ($entry in $inputData.files) {
    $source = Assert-V3Path (Join-Path $inbox $entry.path)
    if (-not $source.StartsWith($inbox+'\',[StringComparison]::OrdinalIgnoreCase)) { throw '匯入路徑不在隔離副本內' }
    if ($source -match '\.(db|key|pem|gcm|params)$' -or $source -match '(?i)(ibeet_system|user_keys)') { throw '此工具不接受舊資料庫或金鑰' }
    $item = Get-Item -LiteralPath $source
    if ($item.PSIsContainer -or $item.Length -gt 20MB -or $item.Length -eq 0) { throw '檔案大小不符合上傳限制' }
    $hash = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($hash -cne ([string]$entry.sha256).ToLowerInvariant()) { throw '來源 SHA-256 驗證失敗' }
    if ($entry.hashVersion -notin @(1,2,3)) { throw '來源 hashVersion 必須明確標示 1、2 或 3' }
    if ($entry.keywords.Count -gt 32 -or @($entry.keywords | Where-Object { $_ -match '[,，;；\r\n]' }).Count) { throw '關鍵字格式不支援；請分別匯出' }
    $verified.Add(@{ Path=$source; Hash=$hash; Keywords=($entry.keywords -join ',') })
}
Write-Host ("已驗證 {0} 個隔離匯出檔案；匯入後使用新的 V3 金鑰與 hashVersion 3。" -f $verified.Count)
if (-not $Execute) { Write-Host '目前為唯讀驗證。明確加入 -Execute 才會登入 V3 並匯入。'; return }
Assert-V3Runtime
Protect-V3Directory (Split-Path $inbox)
$api = 'http://127.0.0.1:8083/api'
$web = New-Object Microsoft.PowerShell.Commands.WebRequestSession
$credential = Get-Credential -Message '輸入檔案擁有者的 V3 帳密（僅允許 USER）'
function Get-MigrationCsrf { return (Invoke-RestMethod "$api/auth/csrf" -WebSession $web).token }
$receipt = [Collections.Generic.List[object]]::new()
try {
    $headers = @{ 'X-CSRF-TOKEN'=(Get-MigrationCsrf) }
    $password = $credential.GetNetworkCredential().Password
    try { Invoke-RestMethod "$api/auth/login" -Method Post -WebSession $web -Headers $headers -Body @{username=$credential.UserName;password=$password} | Out-Null }
    finally { $password=$null }
    $me = Invoke-RestMethod "$api/auth/me" -WebSession $web
    if ($me.role -ne 'USER') { throw '管理員不得代替使用者匯入' }
    foreach ($entry in $verified) {
        $saved = $null
        try {
            $saved = Invoke-RestMethod "$api/files/upload" -Method Post -WebSession $web -Headers @{'X-CSRF-TOKEN'=(Get-MigrationCsrf)} -Form @{file=(Get-Item -LiteralPath $entry.Path);keyword=$entry.Keywords}
            $download = Invoke-WebRequest "$api/files/download/$($saved.fileId)" -WebSession $web
            $bytes = $download.RawContentStream.ToArray()
            $hash = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes)).ToLowerInvariant()
            [Array]::Clear($bytes,0,$bytes.Length)
            if ($hash -cne $entry.Hash) { throw '下載 SHA-256 不一致' }
            $receipt.Add(@{fileId=$saved.fileId;sha256=$hash;hashVersion=3;verified=$true})
        } catch {
            if ($saved) {
                Invoke-RestMethod "$api/files/$($saved.fileId)" -Method Delete -WebSession $web -Headers @{'X-CSRF-TOKEN'=(Get-MigrationCsrf)} | Out-Null
            }
            throw
        }
    }
    Write-Host '匯入完成，所有下載 SHA-256 已比對。'
} finally {
    if ($receipt.Count) {
        $receiptPath = Assert-V3Path (Join-Path $script:V3Root ('migration/receipt-'+[guid]::NewGuid()+'.json'))
        $receipt | ConvertTo-Json | Set-Content -LiteralPath $receiptPath -Encoding utf8
    }
    try { Invoke-RestMethod "$api/auth/logout" -Method Post -WebSession $web -Headers @{'X-CSRF-TOKEN'=(Get-MigrationCsrf)} | Out-Null } catch {}
    $credential=$null
}


