param([switch]$InstallFrontendDependencies)
. "$PSScriptRoot/Common.ps1"
Push-Location $script:V3Root
try {
    $cPath = Get-V31WslPath (Join-Path $script:V3Root 'CSIE_project')
    & wsl.exe -d Ubuntu-26.04 --cd $cPath --exec make -B ibeet_cli hash_v3_vectors
    if ($LASTEXITCODE -ne 0) { throw '真實 C 編譯失敗或 WSL 不可用；未安裝系統套件' }
    & wsl.exe -d Ubuntu-26.04 --cd $cPath --exec make test-v31
    if ($LASTEXITCODE -ne 0) { throw '真實 C 回歸未通過' }
    Push-Location backend
    try {
        & .\mvnw.cmd -B -ntp "-Dmaven.repo.local=$script:V3Root/.cache/m2" package
        if ($LASTEXITCODE -ne 0) { throw '後端 package／完整驗收未通過' }
    } finally { Pop-Location }
    Push-Location CSIE_project/frontend
    try {
        if ($InstallFrontendDependencies) {
            & npm.cmd ci --ignore-scripts --cache "$script:V3Root/.cache/npm"
            if ($LASTEXITCODE -ne 0) { throw '前端相依套件安裝失敗' }
        }
        & npm.cmd run build
        if ($LASTEXITCODE -ne 0) { throw '前端建置失敗' }
        & node.exe node_modules/eslint/bin/eslint.js src/api src/router src/views/HomeView.vue src/views/LoginView.vue src/views/AdminView.vue
        if ($LASTEXITCODE -ne 0) { throw '前端 ESLint 未通過' }
    } finally { Pop-Location }
} finally { Pop-Location }
