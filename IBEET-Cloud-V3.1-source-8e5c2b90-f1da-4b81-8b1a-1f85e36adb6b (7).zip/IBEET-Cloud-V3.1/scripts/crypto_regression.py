"""Real PBC/OpenSSL regression. Run only from the independent V3 checkout."""
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import subprocess
import uuid

ROOT = Path(__file__).absolute().parent.parent
assert ROOT.name == "IBEET-Cloud-V3.1" and (ROOT / ".ibeet-v31").read_text() == "IBEET-CLOUD-V3.1\n"
assert all(not p.is_symlink() for p in [ROOT, *ROOT.parents])
RUN = ROOT / ".test-runs" / ("c-" + str(uuid.uuid4()))
RUN.mkdir(parents=True, mode=0o700)
KEY = os.urandom(32).hex()
CLI = ROOT / "CSIE_project" / "ibeet_cli"
passed = []

def run(operation, *fields, key=KEY, success=True):
    data = key + "\n" + "".join(v.encode("utf-8").hex() + "\n" for v in fields)
    result = subprocess.run([str(CLI), operation, str(RUN)], input=data.encode(),
                            cwd=CLI.parent, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
    assert (result.returncode == 0) == success, operation + " exit status"
    return result.stdout.decode()

def ok(label):
    passed.append(label)
    print("PASS:", label)

run("encrypt-v2", "sample", "ocean2026", "test-alice", success=False)
assert not (RUN / "system.gcm").exists()
run("init")
run("init", success=False)
ok("明確初始化且拒絕覆寫既有系統")
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    list(pool.map(lambda _: run("provision", "test-alice"), range(8)))
run("provision", "test-bob")
ok("跨程序並行私鑰佈建穩定")
for suffix in ("", "-v2", "-v3"):
    cipher = dict(line.split("=", 1) for line in run("encrypt" + suffix, "sample", "ocean2026", "test-alice").splitlines() if "=" in line)
    assert "MATCH_RESULT=MATCH" in run("match" + suffix, "ocean2026", "test-alice", cipher["delta2"], cipher["delta3"])
    assert "MATCH_RESULT=NO_MATCH" in run("match" + suffix, "unrelated", "test-alice", cipher["delta2"], cipher["delta3"])
    result = run("decrypt", cipher["delta1"], cipher["delta2"], cipher["delta3"], cipher["delta4"], "test-alice")
    message = next(line.split("=", 1)[1] for line in result.splitlines() if line.startswith("PLAINTEXT_HEX="))
    assert bytes.fromhex(message).rstrip(b"\x00") == b"sample"
    run("decrypt", cipher["delta1"], cipher["delta2"], cipher["delta3"], cipher["delta4"], "test-bob", success=False)
    bad = bytearray.fromhex(cipher["delta4"])
    bad[0] ^= 1
    run("decrypt", cipher["delta1"], cipher["delta2"], cipher["delta3"], bad.hex(), "test-alice", success=False)
    ok("hashVersion " + (suffix[-1] if suffix else "1") + " 真實加密、相同/不同詞比對、解密與竄改拒絕")
snapshot = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in RUN.glob("*.gcm")}
run("compare-v2", "ocean2026", "ocean2026", "test-alice", key=os.urandom(32).hex(), success=False)
assert snapshot == {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in RUN.glob("*.gcm")}
ok("錯誤主金鑰拒絕且不重建")
for path in [RUN / "system.gcm", RUN / (hashlib.sha256(b"test-alice").hexdigest() + ".gcm")]:
    original = path.read_bytes()
    assert original[:8] == b"IBEV3GCM"
    corrupted = bytearray(original)
    corrupted[-1] ^= 1
    path.write_bytes(corrupted)
    run("compare-v2", "ocean2026", "ocean2026", "test-alice", success=False)
    assert path.read_bytes() == corrupted
    path.write_bytes(original)
ok("系統秘密及私鑰 GCM 竄改拒絕且不覆寫")
private_path = RUN / (hashlib.sha256(b"test-alice").hexdigest() + ".gcm")
saved = private_path.read_bytes()
private_path.unlink()
run("encrypt-v2", "sample", "ocean2026", "test-alice", success=False)
assert not private_path.exists()
private_path.write_bytes(saved)
ok("遺失私鑰時拒絕自動重生")
assert "COMPARE_RESULT=MATCH" in run("compare-v2", "海洋測試", "海洋測試", "test-alice")
assert "COMPARE_RESULT=NO_MATCH" in run("compare-v2", "海洋測試", "另一個詞", "test-alice")
ok("UTF-8 關鍵字及跨程序重載")
for a, b in [("A" * 80 + "-one", "A" * 80 + "-two"), ("A" * 499 + "x", "A" * 499 + "y"), ("海" * 100 + "甲", "海" * 100 + "乙")]:
    cipher = dict(line.split("=", 1) for line in run("encrypt-v3", "sample", a, "test-alice").splitlines() if "=" in line)
    assert "MATCH_RESULT=MATCH" in run("match-v3", a, "test-alice", cipher["delta2"], cipher["delta3"])
    assert "MATCH_RESULT=NO_MATCH" in run("match-v3", b, "test-alice", cipher["delta2"], cipher["delta3"])
run("encrypt-v3", "sample", "A" * 501, "test-alice", success=False)
ok("F01 HV3 長共同前綴、UTF8、500-byte 上限真實配對")
assert "COMPARE_RESULT=MATCH" in run("compare-v2", "A" * 80 + "-one", "A" * 80 + "-two", "test-alice")
ok("HV2 歷史語意未變；已知長詞風險仍重現，非安全通過")
outside = RUN / "synthetic-target"
(outside / "crypto").mkdir(parents=True)
alias = RUN / "ancestor-alias"
alias.symlink_to(outside, target_is_directory=True)
def reject_path(directory):
    result = subprocess.run([str(CLI), "init", str(directory)], input=(KEY + "\n").encode(), cwd=CLI.parent, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=10)
    assert result.returncode != 0
reject_path(alias / "crypto")
reject_path(RUN / ".." / "dot-traversal")
assert not (outside / "crypto" / ".lock").exists()
assert not (outside / "crypto" / "system.gcm").exists()
ok("F04 C 祖先連結及 dot 跳脫拒絕且目標零寫入")
(RUN / "results.json").write_text(json.dumps({"passed": passed, "legacyRiskRetained": True}, ensure_ascii=False, indent=2), encoding="utf-8")
print("CRYPTO_GROUPS=" + str(len(passed)))
