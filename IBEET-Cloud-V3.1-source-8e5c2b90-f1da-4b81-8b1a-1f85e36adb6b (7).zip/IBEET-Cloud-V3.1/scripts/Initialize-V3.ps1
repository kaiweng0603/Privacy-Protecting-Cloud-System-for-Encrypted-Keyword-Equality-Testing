. "$PSScriptRoot/Common.ps1"
$runtime = Assert-V3Path (Join-Path $script:V3Root 'runtime-v31')
if (Test-Path -LiteralPath $runtime) { throw 'runtime-v31 已存在。為避免破壞密文，拒絕重新初始化；請先人工檢查。' }
$jar = Assert-V3Path (Join-Path $script:V3Root 'backend/target/ibeet-3.1.0.jar')
if (-not (Test-Path -LiteralPath $jar)) { throw '請先執行 Build-V3.ps1。' }
$encodedPasswords = [Collections.Generic.List[string]]::new()
foreach ($name in @('alice','bob','admin')) {
    $secure = Read-Host "設定 $name 密碼（12–72 UTF-8 bytes）" -AsSecureString
    $confirm = Read-Host "再次輸入 $name 密碼" -AsSecureString
    $firstPtr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
    $secondPtr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($confirm)
    try {
        $plain = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($firstPtr)
        $verify = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($secondPtr)
        if ($plain -cne $verify) { throw '兩次密碼不同' }
        $bytes = [Text.Encoding]::UTF8.GetBytes($plain)
        if ($bytes.Length -lt 12 -or $bytes.Length -gt 72) { throw '密碼長度必須為 12–72 UTF-8 bytes' }
        $encodedPasswords.Add(([BitConverter]::ToString($bytes)).Replace('-','').ToLowerInvariant())
        [Array]::Clear($bytes,0,$bytes.Length)
    } finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($firstPtr)
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($secondPtr)
        $plain = $null; $verify = $null; $secure.Dispose(); $confirm.Dispose()
    }
}
[IO.Directory]::CreateDirectory($runtime) | Out-Null
Protect-V3Directory $runtime
foreach ($folder in @('secrets','crypto','db')) { [IO.Directory]::CreateDirectory((Join-Path $runtime $folder)) | Out-Null }
$rootBytes = New-Object byte[] 32
$rng = [Security.Cryptography.RandomNumberGenerator]::Create()
try { $rng.GetBytes($rootBytes); [IO.File]::WriteAllBytes((Join-Path $runtime 'secrets/root.key'),$rootBytes) }
finally { $rng.Dispose(); [Array]::Clear($rootBytes,0,$rootBytes.Length) }
Push-Location $script:V3Root
try {
    # Anonymous stdin pipe. No password in argv, environment, transcript or disk.
    $encodedPasswords | & java.exe -Xmx768m -jar $jar --ibeet.initialize=true
    if ($LASTEXITCODE -ne 0) { throw '初始化失敗。保留現況供檢查；不得刪除金鑰後重試。' }
    Write-Host 'V3.1 初始化完成。請使用 Start-Backend.ps1 與 Start-Frontend.ps1。'
} finally { $encodedPasswords.Clear(); Pop-Location }


