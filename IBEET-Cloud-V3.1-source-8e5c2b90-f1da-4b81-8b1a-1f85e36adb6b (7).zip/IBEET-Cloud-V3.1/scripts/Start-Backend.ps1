. "$PSScriptRoot/Common.ps1"
Assert-V3Runtime
Push-Location $script:V3Root
try {
    & java.exe -Xmx768m -jar backend/target/ibeet-3.1.0.jar
    if ($LASTEXITCODE -ne 0) { throw 'V3.1 啟動失敗；不會重建金鑰' }
} finally { Pop-Location }

