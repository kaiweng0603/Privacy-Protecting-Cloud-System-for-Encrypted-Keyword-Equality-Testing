package com.example.ibeet;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;
import java.util.*;
import java.util.function.LongSupplier;
public final class LoginThrottle extends OncePerRequestFilter {
    private final Map<String,ArrayDeque<Long>> attempts=new HashMap<>();
    private final LongSupplier now;
    public LoginThrottle(){this(System::nanoTime);}
    LoginThrottle(LongSupplier now){this.now=now;}
    synchronized boolean accept(String address){
        long current=now.getAsLong(),window=60_000_000_000L;
        attempts.values().forEach(q->{while(!q.isEmpty()&&current-q.peekFirst()>=window)q.removeFirst();});
        attempts.entrySet().removeIf(e->e.getValue().isEmpty());
        if(!attempts.containsKey(address)&&attempts.size()>=1024)return false;
        var queue=attempts.computeIfAbsent(address,k->new ArrayDeque<>());
        if(queue.size()>=10)return false;queue.addLast(current);return true;
    }
    @Override protected void doFilterInternal(HttpServletRequest q,HttpServletResponse r,FilterChain chain)throws ServletException,IOException {
        if(q.getMethod().equals("POST")&&RequestPaths.route(q).equals("/api/auth/login")){
            if(q.getContentLengthLong()<0||q.getContentLengthLong()>8192){SecurityConfig.json(r,413,"登入請求大小不符");return;}
            // Never trust X-Forwarded-For. Bound successful and failed attempts alike before BCrypt work.
            if(!accept(q.getRemoteAddr())){r.setHeader("Retry-After","60");SecurityConfig.json(r,429,"登入嘗試過於頻繁，請稍後再試");return;}
        }
        chain.doFilter(q,r);
    }
}
