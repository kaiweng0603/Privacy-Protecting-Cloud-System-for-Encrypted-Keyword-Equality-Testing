package com.example.ibeet;
import org.springframework.context.annotation.*;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.jdbc.datasource.AbstractDataSource;
import com.zaxxer.hikari.*;
import java.nio.file.Path;
import java.sql.*;
import javax.sql.DataSource;
@Configuration
public class SafeDataSourceConfig {
 @Bean(destroyMethod="close") DataSource dataSource(ConfigurableEnvironment env){
  V3EnvironmentGuard.rejectOverrides(env);Path root=V3Paths.root(env.getRequiredProperty("ibeet.project-root"));
  String url=env.getRequiredProperty("spring.datasource.url");V3EnvironmentGuard.jdbc(root,url);
  HikariConfig config=new HikariConfig();config.setJdbcUrl(url);config.setUsername("sa");config.setPassword(env.getProperty("spring.datasource.password",""));
  config.setDriverClassName("org.h2.Driver");config.setConnectionInitSql("SET WRITE_DELAY 0");config.setMaximumPoolSize(4);config.setMinimumIdle(0);config.setConnectionTimeout(5000);config.setInitializationFailTimeout(-1);config.setPoolName("IBEET-V31");
  return new GuardedDataSource(root,url,config);
 }
 public static final class GuardedDataSource extends AbstractDataSource implements AutoCloseable {
  private final Path root;private final String expected;private final HikariDataSource pool;
  GuardedDataSource(Path root,String expected,HikariConfig config){this.root=root;this.expected=expected;check(config);pool=new HikariDataSource(config);}
  private void check(HikariConfig c){
   V3Paths.noLinks(root);V3EnvironmentGuard.jdbc(root,c.getJdbcUrl());
   if(!expected.equals(c.getJdbcUrl())||!"org.h2.Driver".equals(c.getDriverClassName())||c.getDataSourceClassName()!=null||c.getDataSource()!=null||c.getDataSourceJNDI()!=null||!c.getDataSourceProperties().isEmpty()||!"SET WRITE_DELAY 0".equals(c.getConnectionInitSql()))throw new IllegalStateException("最終 DataSource 與核准設定不符，拒絕連線");
  }
  @Override public Connection getConnection()throws SQLException{check(pool);return pool.getConnection();}
  @Override public Connection getConnection(String user,String password)throws SQLException{throw new SQLException("拒絕替代連線認證");}
  @Override public void close(){pool.close();}
 }
}
