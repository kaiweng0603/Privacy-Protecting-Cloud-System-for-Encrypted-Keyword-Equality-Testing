package com.example.ibeet;
import jakarta.persistence.*;
import java.time.Instant;
@Entity
@Table(name="APP_USERS")
public class AppUser {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
    @Column(nullable=false,unique=true,length=64) public String username;
    @Column(nullable=false) public String passwordHash;
    @Column(nullable=false,length=10) public String role;
    @Column(unique=true) public String ibeetId;
    @Column(nullable=false) public boolean enabled=true;
    @Column(nullable=false) public Instant createdAt=Instant.now();
    @Column(nullable=false) public Instant updatedAt=Instant.now();
    @Version public long version;
    @PreUpdate void updateTime() { updatedAt=Instant.now(); }
}
