package com.example.ibeet;
import java.time.Instant;
public record FileSummary(Long id,String fileName,String ownerId,long size,Instant createdAt) {}
