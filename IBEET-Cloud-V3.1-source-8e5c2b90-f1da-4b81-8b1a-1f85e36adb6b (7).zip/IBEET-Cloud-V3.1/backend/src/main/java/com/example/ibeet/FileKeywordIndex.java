
package com.example.ibeet;

import jakarta.persistence.*;

@Entity
@Table(name = "FILE_KEYWORD_INDEX")
public class FileKeywordIndex {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "FILE_ID", nullable = false)
    private Long fileId;

    @Column(name = "OWNER_ID", nullable = false)
    private String ownerId;

    @Column(name = "KEYWORD_PROTECTED", length = 3000, nullable=false)
    private String keywordProtected;
    @Column(nullable=false,length=64)
    private String integrityMac;
    public String getIntegrityMac() { return integrityMac; }
    public void setIntegrityMac(String value) { integrityMac=value; }
    @Column(nullable=false,unique=true)
    private String cryptoContext=java.util.UUID.randomUUID().toString();
    @ManyToOne(fetch=FetchType.LAZY,optional=false)
    @JoinColumn(name="FILE_ID",insertable=false,updatable=false,
        foreignKey=@ForeignKey(name="FK_KEYWORD_FILE"))
    private EncryptedFile file;
    public String getCryptoContext() { return cryptoContext; }
    public String getKeywordProtected() { return keywordProtected; }
    public void setKeywordProtected(String value) { keywordProtected=value; }

    @Column(name = "C1", columnDefinition = "LONGTEXT")
    private String c1;

    @Column(name = "C2", columnDefinition = "LONGTEXT")
    private String c2;

    @Column(name = "C3", columnDefinition = "LONGTEXT")
    private String c3;

    @Column(name = "C4", columnDefinition = "LONGTEXT")
    private String c4;

    // NULL 或 1 = V1；2 = V2
    @Column(name = "HASH_VERSION", nullable = true)
    private Integer hashVersion = 1;

    public FileKeywordIndex() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getFileId() {
        return fileId;
    }

    public void setFileId(Long fileId) {
        this.fileId = fileId;
    }

    public String getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }


    public String getC1() {
        return c1;
    }

    public void setC1(String c1) {
        this.c1 = c1;
    }

    public String getC2() {
        return c2;
    }

    public void setC2(String c2) {
        this.c2 = c2;
    }

    public String getC3() {
        return c3;
    }

    public void setC3(String c3) {
        this.c3 = c3;
    }

    public String getC4() {
        return c4;
    }

    public void setC4(String c4) {
        this.c4 = c4;
    }

    public Integer getHashVersion() {
        return hashVersion;
    }

    public void setHashVersion(Integer hashVersion) {
        this.hashVersion = hashVersion;
    }
}
