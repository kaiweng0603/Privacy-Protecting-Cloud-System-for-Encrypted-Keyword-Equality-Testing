package com.example.ibeet;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.http.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
@RestController
@RequestMapping("/api/files")
public class FileController {
    private final CloudService cloud;
    public FileController(CloudService cloud) { this.cloud=cloud; }
    @GetMapping("/list") public Object list(@RequestParam(defaultValue="0") int page,@RequestParam(defaultValue="10") int size) { return cloud.list(page,size); }
    @PostMapping(value="/upload",consumes=MediaType.MULTIPART_FORM_DATA_VALUE)
    public Object upload(@RequestParam("file") MultipartFile file,@RequestParam(defaultValue="") String keyword) throws Exception {
        return cloud.upload(file,keyword);
    }
    @PostMapping("/search") public Object search(@RequestBody Map<String,String> body,@RequestParam(defaultValue="0") int page,@RequestParam(defaultValue="10") int size) throws Exception {
        return cloud.search(body.getOrDefault("query",""),body.getOrDefault("mode","all"),page,size);
    }
    @GetMapping("/download/{id}") public ResponseEntity<byte[]> download(@PathVariable Long id) throws Exception {
        var d=cloud.download(id);
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_OCTET_STREAM)
            .header(HttpHeaders.CONTENT_DISPOSITION,ContentDisposition.attachment().filename(d.name(),StandardCharsets.UTF_8).build().toString())
            .body(d.bytes());
    }
    @PatchMapping("/{id}/rename") public Object rename(@PathVariable Long id,@RequestBody Map<String,String> body) {
        cloud.rename(id,body.get("fileName")); return Map.of("message","重新命名成功");
    }
    @DeleteMapping("/{id}") public Object delete(@PathVariable Long id) {
        cloud.delete(id);return Map.of("message","檔案已刪除");
    }
    @GetMapping("/{id}/keywords") public Object keywords(@PathVariable Long id) throws Exception { return cloud.keywords(id); }
    @PostMapping("/{id}/keywords") public Object add(@PathVariable Long id,@RequestBody Map<String,String> body) throws Exception {
        return cloud.addKeywords(id,body.getOrDefault("keyword",""));
    }
    @DeleteMapping("/{id}/keywords/{index}") public Object remove(@PathVariable Long id,@PathVariable Long index) {
        cloud.deleteKeyword(id,index);return Map.of("message","關鍵字已刪除");
    }
}
