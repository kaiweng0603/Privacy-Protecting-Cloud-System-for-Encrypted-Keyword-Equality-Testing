
package com.example.ibeet;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FileKeywordIndexRepository
        extends JpaRepository<FileKeywordIndex, Long> {

    List<FileKeywordIndex> findByFileId(Long fileId);

    List<FileKeywordIndex> findByOwnerId(String ownerId);
    boolean existsByFileId(Long fileId);

    void deleteByFileId(Long fileId);
}
