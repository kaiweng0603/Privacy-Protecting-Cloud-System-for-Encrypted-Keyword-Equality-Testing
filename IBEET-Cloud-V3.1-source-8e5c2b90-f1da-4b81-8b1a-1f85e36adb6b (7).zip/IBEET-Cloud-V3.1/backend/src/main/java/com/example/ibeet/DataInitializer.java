package com.example.ibeet;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.transaction.annotation.Transactional;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
@Component
public class DataInitializer implements CommandLineRunner {
    private final UserRepository users;
    private final FileRepository files;
    private final AlgorithmService algorithm;
    private final PasswordEncoder passwords;
    private final boolean initialize;
    public DataInitializer(UserRepository users,FileRepository files,AlgorithmService algorithm,
        PasswordEncoder passwords,@Value("${ibeet.initialize:false}") boolean initialize) {
        this.users=users;this.files=files;this.algorithm=algorithm;this.passwords=passwords;this.initialize=initialize;
    }
    @Override @Transactional(rollbackFor=Exception.class)
    public void run(String... args) throws Exception {
        if(!initialize) {
            for(var u:users.findAll()) if(u.ibeetId!=null) algorithm.check(u.ibeetId);
            return;
        }
        if(users.count()!=0||files.count()!=0) throw new IllegalStateException("初始化僅適用全新 V3，拒絕覆寫");
        BufferedReader input=new BufferedReader(new InputStreamReader(System.in,StandardCharsets.UTF_8));
        List<String> hashes=new ArrayList<>();
        for(int i=0;i<3;i++) {
            String encoded=input.readLine();
            if(encoded==null||encoded.length()>1024) throw new IllegalStateException("需要三組本機密碼");
            byte[] raw=HexFormat.of().parseHex(encoded);
            if(raw.length<12||raw.length>72) throw new IllegalStateException("密碼必須為 12–72 UTF-8 bytes");
            hashes.add(passwords.encode(new String(raw,StandardCharsets.UTF_8))); Arrays.fill(raw,(byte)0);
        }
        algorithm.initialize();
        for(int i=0;i<3;i++) {
            AppUser u=new AppUser(); u.username=List.of("alice","bob","admin").get(i);
            u.role=i==2?"ADMIN":"USER"; u.passwordHash=hashes.get(i);
            if(i!=2) { u.ibeetId="v31-"+UUID.randomUUID(); algorithm.provision(u.ibeetId); }
            users.save(u);
        }
        System.out.println("V3_LOCAL_INITIALIZATION_OK");
    }
}
