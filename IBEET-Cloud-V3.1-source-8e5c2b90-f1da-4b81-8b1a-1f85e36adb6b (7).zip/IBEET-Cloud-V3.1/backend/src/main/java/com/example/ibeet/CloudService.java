package com.example.ibeet;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;
import java.util.*;
import java.util.regex.*;
@Service
@Transactional(rollbackFor=Exception.class)
public class CloudService {
    private final CurrentUser current;
    private final FileRepository files;
    private final FileKeywordIndexRepository indexes;
    private final FileEncryptionService aes;
    private final KeyProtectionService keys;
    private final AlgorithmService algorithm;
    private final UserRepository users;
    private final SearchLimits limits;
    private final int maxFiles;
    private final long maxBytes;
    public CloudService(CurrentUser current,FileRepository files,FileKeywordIndexRepository indexes,
        FileEncryptionService aes,KeyProtectionService keys,AlgorithmService algorithm,UserRepository users,SearchLimits limits,
        @org.springframework.beans.factory.annotation.Value("${ibeet.quota.max-files:100}") int maxFiles,
        @org.springframework.beans.factory.annotation.Value("${ibeet.quota.max-bytes:209715200}") long maxBytes) {
        this.current=current;this.files=files;this.indexes=indexes;this.aes=aes;this.keys=keys;this.algorithm=algorithm;
        if(maxFiles<1||maxFiles>100||maxBytes<1||maxBytes>209715200L)throw new IllegalStateException("配額必須在安全上限內");
        this.users=users;this.limits=limits;this.maxFiles=maxFiles;this.maxBytes=maxBytes;
    }
    private EncryptedFile owned(Long id,boolean lock) {
        String owner=current.owner();
        return (lock?files.lockOwned(id,owner):files.findByIdAndOwnerId(id,owner))
            .orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"檔案不存在或無存取權限"));
    }
    private String context(EncryptedFile f) { return f.getOwnerId()+":"+f.getCryptoContext(); }
    private String context(FileKeywordIndex i) { return i.getOwnerId()+":"+i.getFileId()+":"+i.getCryptoContext(); }
    private String indexData(FileKeywordIndex i) {
        return context(i)+":"+i.getHashVersion()+":"+i.getC1()+":"+i.getC2()+":"+i.getC3()+":"+i.getC4()+":"+i.getKeywordProtected();
    }
    private void verify(FileKeywordIndex i) throws Exception {
        if(i.getIntegrityMac()==null || !java.security.MessageDigest.isEqual(
            keys.authenticate(indexData(i)).getBytes(java.nio.charset.StandardCharsets.US_ASCII),
            i.getIntegrityMac().getBytes(java.nio.charset.StandardCharsets.US_ASCII)))
            throw new java.security.GeneralSecurityException("索引完整性驗證失敗");
    }
    private String fileName(String value) {
        if(value==null||value.isBlank()||value.length()>200||value.contains("/")||value.contains("\\")||
            value.chars().anyMatch(c->c<32||c==127)) throw new IllegalArgumentException();
        return value.trim();
    }
    private Set<String> words(String value) {
        if(value==null||value.length()>8000) throw new IllegalArgumentException();
        Set<String> result=new LinkedHashSet<>();
        for(String word:value.split("[,，;；\\r\\n]+")) if(!word.isBlank()) {
            if(word.chars().anyMatch(c->c<32||c==127))throw new IllegalArgumentException();
            String w=word.trim();
            validateWord(w);
            result.add(w);
        }
        if(result.size()>32) throw new IllegalArgumentException();
        return result;
    }
    static void validateWord(String word) {
        if(word.isEmpty()||!java.nio.charset.StandardCharsets.UTF_8.newEncoder().canEncode(word)||
           word.getBytes(java.nio.charset.StandardCharsets.UTF_8).length>500||word.chars().anyMatch(c->c<32||c==127))throw new IllegalArgumentException();
    }
    static org.springframework.data.domain.PageRequest page(int page,int size) {
        if(page<0||page>10000||size<1||size>25)throw new IllegalArgumentException();
        return org.springframework.data.domain.PageRequest.of(page,size);
    }
    private Map<String,Object> info(EncryptedFile f) {
        return Map.of("fileId",f.getId(),"fileName",f.getFileName(),"size",f.getSize(),
            "createdAt",f.getCreatedAt(),"hasKeywordIndex",!indexes.findByFileId(f.getId()).isEmpty());
    }
    private Map<String,Object> info(FileSummary f) {
        return Map.of("fileId",f.id(),"fileName",f.fileName(),"size",f.size(),"createdAt",f.createdAt(),"hasKeywordIndex",indexes.existsByFileId(f.id()));
    }
    private Map<String,Object> pageResult(org.springframework.data.domain.Page<FileSummary> slice,List<Map<String,Object>> items) {
        return Map.of("items",items,"page",slice.getNumber(),"size",slice.getSize(),"candidateTotal",slice.getTotalElements(),"hasNext",slice.hasNext());
    }
    public Map<String,Object> list(int page,int size) {
        var slice=files.summaries(current.owner(),page(page,size));
        return pageResult(slice,slice.stream().map(this::info).toList());
    }
    public Map<String,Object> upload(MultipartFile upload,String keyword) throws Exception {
        if(upload.isEmpty()||upload.getSize()>20*1024*1024) throw new IllegalArgumentException();
        String owner=current.owner();
        users.lockOwner(owner).orElseThrow(()->new ResponseStatusException(HttpStatus.FORBIDDEN));
        if(files.countByOwnerId(owner)>=maxFiles||files.bytesByOwner(owner)>maxBytes-upload.getSize())
            throw new ResponseStatusException(HttpStatus.INSUFFICIENT_STORAGE,"已達帳號檔案數或儲存配額");
        EncryptedFile f=new EncryptedFile(); f.setOwnerId(current.owner());
        f.setFileName(fileName(upload.getOriginalFilename())); f.setSize(upload.getSize());
        var encrypted=aes.encrypt(upload.getBytes(),context(f));
        f.setFilePayload(encrypted.getCiphertext()); f.setAesNonce(encrypted.getNonce());
        f.setAesKeyProtected(keys.seal(encrypted.getKey(),"file-key",context(f)));
        files.saveAndFlush(f);
        add(f,words(keyword));
        return info(f);
    }
    private void add(EncryptedFile f,Set<String> words) throws Exception {
        var existing=indexes.findByFileId(f.getId());
        Set<String> known=new HashSet<>();
        for(var i:existing) { verify(i);known.add(keys.open(i.getKeywordProtected(),"keyword",context(i))); }
        words.removeAll(known);
        if(existing.size()+words.size()>32) throw new IllegalArgumentException();
        for(String word:words) {
            var cipher=algorithm.encryptV3("IBEET_FILE_INDEX",word,f.getOwnerId());
            FileKeywordIndex i=new FileKeywordIndex();
            i.setFileId(f.getId());i.setOwnerId(f.getOwnerId());i.setHashVersion(3);
            i.setC1(cipher.get("delta1"));i.setC2(cipher.get("delta2"));
            i.setC3(cipher.get("delta3"));i.setC4(cipher.get("delta4"));
            i.setKeywordProtected(keys.seal(word,"keyword",context(i)));
            i.setIntegrityMac(keys.authenticate(indexData(i))); indexes.save(i);
        }
    }
    public Map<String,Object> addKeywords(Long id,String words) throws Exception {
        add(owned(id,true),words(words)); return Map.of("message","關鍵字已新增");
    }
    public Map<String,Object> keywords(Long id) throws Exception {
        EncryptedFile f=owned(id,false); List<Map<String,Object>> result=new ArrayList<>();
        for(var i:indexes.findByFileId(f.getId())) {
            verify(i);
            result.add(Map.of("indexId",i.getId(),"keyword",keys.open(i.getKeywordProtected(),"keyword",context(i)),
                "hashVersion",i.getHashVersion()==null?1:i.getHashVersion()));
        }
        return Map.of("keywords",result);
    }
    public void deleteKeyword(Long id,Long indexId) {
        EncryptedFile f=owned(id,true);
        var i=indexes.findById(indexId).filter(x->x.getFileId().equals(f.getId())&&x.getOwnerId().equals(f.getOwnerId()))
            .orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"索引不存在或無存取權限"));
        indexes.delete(i);
    }
    public void rename(Long id,String name) { owned(id,true).setFileName(fileName(name)); }
    public void delete(Long id) {
        var f=owned(id,true); indexes.deleteByFileId(id); indexes.flush(); files.delete(f);
    }
    public record Download(String name,byte[] bytes) {}
    public Download download(Long id) throws Exception {
        var f=owned(id,false);
        return new Download(f.getFileName(),aes.decrypt(keys.open(f.getAesKeyProtected(),"file-key",context(f)),
            f.getAesNonce(),f.getFilePayload(),context(f)));
    }
    public Map<String,Object> search(String query,String mode,int page,int size) throws Exception {
        if(query==null||query.length()>2000||!Set.of("all","keyword","filename").contains(mode)) throw new IllegalArgumentException();
        List<String> terms=new ArrayList<>();
        var matcher=Pattern.compile("\"([^\"]+)\"|([^\\s,，;；]+)").matcher(query);
        while(matcher.find()) {String raw=matcher.group(1)!=null?matcher.group(1):matcher.group(2);if(raw.chars().anyMatch(c->c<32||c==127))throw new IllegalArgumentException();String term=raw.trim();if(!term.isEmpty()){validateWord(term);terms.add(term);}}
        if(terms.size()>10) throw new IllegalArgumentException();
        String owner=current.owner();
        var all=files.summaries(owner,page(page,size)); List<Map<String,Object>> result=new ArrayList<>();
        try(var budget=limits.begin(owner)) {
        for(var f:all) {
            budget.remainingMillis();
            String type=terms.isEmpty()?"all":null;
            if(!mode.equals("keyword") && terms.stream().anyMatch(t->f.fileName().toLowerCase(Locale.ROOT).contains(t.toLowerCase(Locale.ROOT)))) type="filename";
            if(type==null && !mode.equals("filename")) {
                var candidates=indexes.findByFileId(f.id());
                if(candidates.size()>32)throw new IllegalStateException("索引數量超過限制");
                outer: for(var i:candidates) {
                    verify(i);
                    if(!owner.equals(i.getOwnerId())) throw new IllegalStateException("索引所有權錯誤");
                    for(String term:terms)
                        if(algorithm.matchVersion(term,owner,i.getC2(),i.getC3(),i.getHashVersion(),budget)) { type="ibeet";break outer; }
                }
            }
            if(type!=null) { var row=new LinkedHashMap<>(info(f));row.put("matchType",type);result.add(row); }
        }
        budget.remainingMillis();
        }
        return pageResult(all,result);
    }
}
