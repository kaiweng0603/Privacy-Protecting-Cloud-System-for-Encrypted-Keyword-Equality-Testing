package com.example.ibeet;
import java.util.Map;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.web.csrf.CsrfToken;
@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final CurrentUser current;
    public AuthController(CurrentUser current) { this.current = current; }
    @GetMapping("/csrf")
    public Map<String,String> csrf(CsrfToken token) {
        return Map.of("token", token.getToken(), "headerName", token.getHeaderName());
    }
    @GetMapping("/me")
    public Map<String,Object> me() {
        AppUser u = current.get();
        return Map.of("username", u.username, "role", u.role, "userId", u.username);
    }
}
