package com.example.ibeet;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import java.util.List;
public class SessionUser extends User {
    public final long accountVersion;
    public SessionUser(AppUser user) {
        super(user.username,user.passwordHash,user.enabled,true,true,true,
            List.of(new SimpleGrantedAuthority("ROLE_"+user.role)));
        accountVersion=user.version;
    }
}
