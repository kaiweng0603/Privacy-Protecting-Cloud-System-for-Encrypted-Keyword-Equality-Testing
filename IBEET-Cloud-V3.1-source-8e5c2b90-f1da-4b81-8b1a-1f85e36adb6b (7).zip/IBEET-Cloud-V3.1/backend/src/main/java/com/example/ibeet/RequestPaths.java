package com.example.ibeet;
import jakarta.servlet.http.HttpServletRequest;
final class RequestPaths {
    private RequestPaths(){}
    static String route(HttpServletRequest request){
        // The container's servlet path is decoded and relative to the context, like MVC/security matching.
        String servlet=request.getServletPath();
        if(servlet!=null&&!servlet.isEmpty())return servlet+(request.getPathInfo()==null?"":request.getPathInfo());
        return request.getRequestURI().substring(request.getContextPath().length());
    }
}
