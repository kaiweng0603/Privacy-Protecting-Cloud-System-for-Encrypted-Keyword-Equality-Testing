package com.example.ibeet;
import org.springframework.stereotype.Service;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;
@Service
public class CurrentUser {
    private final UserRepository users;
    public CurrentUser(UserRepository users) { this.users=users; }
    public AppUser get() {
        var auth=SecurityContextHolder.getContext().getAuthentication();
        if(auth==null) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED);
        return users.findByUsername(auth.getName()).filter(u->u.enabled)
            .orElseThrow(()->new ResponseStatusException(HttpStatus.UNAUTHORIZED));
    }
    public String owner() {
        AppUser u=get();
        if(!"USER".equals(u.role)||u.ibeetId==null)
            throw new ResponseStatusException(HttpStatus.FORBIDDEN);
        return u.ibeetId;
    }
}
