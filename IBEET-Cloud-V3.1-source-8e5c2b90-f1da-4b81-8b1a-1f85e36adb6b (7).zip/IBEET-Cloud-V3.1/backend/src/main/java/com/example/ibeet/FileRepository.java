
package com.example.ibeet;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FileRepository extends JpaRepository<EncryptedFile, Long> {

    // 依照使用者 ID 查詢檔案
    List<EncryptedFile> findByOwnerId(String ownerId);
    @org.springframework.data.jpa.repository.Query("select new com.example.ibeet.FileSummary(f.id,f.fileName,f.ownerId,f.size,f.createdAt) from EncryptedFile f where f.ownerId=:owner order by f.id")
    org.springframework.data.domain.Page<FileSummary> summaries(@org.springframework.data.repository.query.Param("owner") String owner,org.springframework.data.domain.Pageable page);
    long countByOwnerId(String ownerId);
    @org.springframework.data.jpa.repository.Query("select coalesce(sum(f.size),0) from EncryptedFile f where f.ownerId=:owner")
    long bytesByOwner(@org.springframework.data.repository.query.Param("owner") String owner);
    interface CipherPreview {Long getId();String getOwnerId();long getSize();String getNonce();String getPreview();int getCharacters();String getKeyFormat();}
    @org.springframework.data.jpa.repository.Query(value="select id,owner_id as ownerId,size,aes_nonce as nonce,cast(substring(file_payload,1,192) as varchar(192)) as preview,length(file_payload) as characters,cast(substring(aes_key_protected,1,5) as varchar(5)) as keyFormat from encrypted_files order by id",countQuery="select count(*) from encrypted_files",nativeQuery=true)
    org.springframework.data.domain.Page<CipherPreview> cipherPreviews(org.springframework.data.domain.Pageable page);
    java.util.Optional<EncryptedFile> findByIdAndOwnerId(Long id,String ownerId);
    @org.springframework.data.jpa.repository.Lock(jakarta.persistence.LockModeType.PESSIMISTIC_WRITE)
    @org.springframework.data.jpa.repository.Query("select f from EncryptedFile f where f.id=:id and f.ownerId=:owner")
    java.util.Optional<EncryptedFile> lockOwned(@org.springframework.data.repository.query.Param("id") Long id,
        @org.springframework.data.repository.query.Param("owner") String owner);

}
