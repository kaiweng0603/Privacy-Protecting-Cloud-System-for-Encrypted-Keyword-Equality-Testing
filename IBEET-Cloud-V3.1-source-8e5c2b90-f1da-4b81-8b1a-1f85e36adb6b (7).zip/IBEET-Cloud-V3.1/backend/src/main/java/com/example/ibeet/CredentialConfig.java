package com.example.ibeet;
import org.springframework.context.annotation.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
@Configuration
public class CredentialConfig {
    @Bean PasswordEncoder passwords(){return new BCryptPasswordEncoder(12);}
}
