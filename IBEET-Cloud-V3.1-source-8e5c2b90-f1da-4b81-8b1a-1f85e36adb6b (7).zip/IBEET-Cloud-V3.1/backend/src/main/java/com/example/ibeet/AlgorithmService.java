package com.example.ibeet;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import java.io.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;
@Service
public class AlgorithmService {
 private final KeyProtectionService keys;private final String distro,project,runtime;private final Path code,crypto;
 private final Semaphore processes=new Semaphore(2,true);
 public AlgorithmService(KeyProtectionService keys,@Value("${ibeet.project-root}")String projectRoot,@Value("${ibeet.wsl}")String distro,@Value("${ibeet.crypto-directory}")String crypto)throws Exception{
  this.keys=keys;this.distro=distro;Path root=V3Paths.root(projectRoot);this.crypto=V3Paths.check(root,crypto);
  code=root.resolve("CSIE_project");V3Paths.noLinks(code);
  V3Paths.noLinks(code.resolve("param/a.param"));
  String fingerprint=HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(code.resolve("param/a.param"))));
  if(!fingerprint.equals("b9efd49cd3e32bda1c9c31a789eb442aa427e40743cc919ee3804afe1f684e6b"))throw new IllegalStateException("公開配對參數指紋不符");
  project=V3Paths.linux(code);runtime=V3Paths.linux(this.crypto);
 }
 private String run(String operation,SearchLimits.Budget budget,String...values)throws Exception{
  long max=budget==null?30000:budget.remainingMillis();
  long deadline=System.nanoTime()+TimeUnit.MILLISECONDS.toNanos(max);
  if(!processes.tryAcquire(Math.min(max,1000),TimeUnit.MILLISECONDS))throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,"加密處理繁忙，請稍後再試");
  Process p=null;
  try{
   V3Paths.noLinks(code);V3Paths.noLinks(crypto);V3Paths.noLinks(code.resolve("ibeet_cli"));
   if(!Files.isRegularFile(code.resolve("ibeet_cli"),LinkOption.NOFOLLOW_LINKS))throw new IOException("尚未編譯 V3.1 真實 C CLI");
   String seconds=Long.toString(Math.max(1,(max+999)/1000))+"s";
   List<String> command=System.getProperty("os.name").startsWith("Windows")?
    List.of("wsl.exe","-d",distro,"--cd",project,"--exec","timeout","--signal=KILL",seconds,"./ibeet_cli",operation,runtime):
    List.of("timeout","--signal=KILL",seconds,"./ibeet_cli",operation,crypto.toString());
   p=new ProcessBuilder(command).directory(code.toFile()).redirectError(ProcessBuilder.Redirect.DISCARD).start();
   final Process process=p;
   var output=new CompletableFuture<byte[]>();
   Thread.startVirtualThread(()->{try{output.complete(process.getInputStream().readNBytes(65537));}catch(Exception e){output.completeExceptionally(e);}});
   var input=new CompletableFuture<Void>();
   Thread.startVirtualThread(()->{
    try(var writer=new BufferedWriter(new OutputStreamWriter(process.getOutputStream(),StandardCharsets.US_ASCII))){
     writer.write(HexFormat.of().formatHex(keys.derive("c-storage")));writer.newLine();
     for(String v:values){if(v==null||v.length()>8192)throw new IllegalArgumentException();writer.write(HexFormat.of().formatHex(v.getBytes(StandardCharsets.UTF_8)));writer.newLine();}
     input.complete(null);
    }catch(Exception e){input.completeExceptionally(e);}
   });
   long remaining=Math.max(1,deadline-System.nanoTime());
   if(!p.waitFor(remaining,TimeUnit.NANOSECONDS))throw timeout(budget);
   input.get(1,TimeUnit.SECONDS);byte[] bytes=output.get(1,TimeUnit.SECONDS);
   if(budget!=null)budget.remainingMillis();
   if(p.exitValue()!=0||bytes.length>65536)throw new IOException("IBEET 操作或金鑰完整性驗證失敗");
   return new String(bytes,StandardCharsets.US_ASCII);
  }finally{
   if(p!=null){if(p.isAlive()){p.descendants().forEach(ProcessHandle::destroyForcibly);p.destroyForcibly();}try{p.getOutputStream().close();p.getInputStream().close();}catch(IOException ignored){}}
   processes.release();
  }
 }
 private Exception timeout(SearchLimits.Budget budget){return budget==null?new IOException("IBEET 執行逾時"):new ResponseStatusException(HttpStatus.GATEWAY_TIMEOUT,"搜尋已超過時間上限");}
 public void initialize()throws Exception{if(!run("init",null).contains("IBEET_INIT_OK"))throw new IOException("初始化失敗");}
 public void provision(String owner)throws Exception{if(!run("provision",null,owner).contains("IBEET_PROVISION_OK"))throw new IOException("私鑰建立失敗");}
 public void check(String owner)throws Exception{if(!run("check-user",null,owner).contains("IBEET_CHECK_OK"))throw new IOException("既有金鑰驗證失敗");}
 public Map<String,String> encryptV3(String message,String keyword,String owner)throws Exception{
  String out=run("encrypt-v3",null,message,keyword,owner);Map<String,String> result=new LinkedHashMap<>();
  var m=Pattern.compile("(?m)^(delta[1-4])=([0-9a-f]+)\\r?$").matcher(out);while(m.find())result.put(m.group(1),m.group(2));
  if(result.size()!=4||!out.contains("IBEET_ENCRYPT_OK"))throw new IOException("IBEET 密文不完整");return result;
 }
 public boolean matchVersion(String word,String owner,String c2,String c3,Integer version,SearchLimits.Budget budget)throws Exception{
  if(version!=null&&version!=1&&version!=2&&version!=3)throw new IOException("不支援的 hashVersion");
  budget.comparison();String operation=Objects.equals(version,3)?"match-v3":Objects.equals(version,2)?"match-v2":"match";
  String out=run(operation,budget,word,owner,c2,c3);
  if(!out.contains("IBEET_MATCH_OK"))throw new IOException("IBEET 比對失敗");
  if(out.contains("MATCH_RESULT=NO_MATCH"))return false;if(out.contains("MATCH_RESULT=MATCH"))return true;throw new IOException("IBEET 比對回應錯誤");
 }
}
