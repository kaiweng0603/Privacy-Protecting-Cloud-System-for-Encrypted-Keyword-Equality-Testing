package com.example.ibeet;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;
import java.nio.file.*;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;
import java.util.*;
@RestController
@RequestMapping("/api/admin")
public class AdminController {
    private final UserRepository users;
    private final FileRepository files;
    private final FileKeywordIndexRepository indexes;
    private final CurrentUser current;
    private final Path crypto;
    public AdminController(UserRepository users,FileRepository files,FileKeywordIndexRepository indexes,
        CurrentUser current,@Value("${ibeet.project-root}") String projectRoot,@Value("${ibeet.crypto-directory}") String crypto) {
        this.users=users;this.files=files;this.indexes=indexes;this.current=current;
        this.crypto=V3Paths.check(V3Paths.root(projectRoot),crypto);
    }
    private Map<String,Object> account(AppUser u) {
        Map<String,Object> row=new LinkedHashMap<>();
        row.put("id",u.id);row.put("username",u.username);row.put("role",u.role);
        row.put("enabled",u.enabled);row.put("createdAt",u.createdAt);row.put("updatedAt",u.updatedAt);
        row.put("ibeetId",u.ibeetId);return row;
    }
    @GetMapping("/users") public Object users() { return users.findAll().stream().map(this::account).toList(); }
    @PatchMapping("/users/{id}") @Transactional
    public Object enabled(@PathVariable Long id,@RequestBody Map<String,Boolean> body) {
        AppUser u=users.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND));
        if("ADMIN".equals(u.role)||u.id.equals(current.get().id))
            throw new ResponseStatusException(HttpStatus.FORBIDDEN,"管理員帳號只能由本機操作者管理");
        if(body.size()!=1||!body.containsKey("enabled")||body.get("enabled")==null) throw new IllegalArgumentException();
        u.enabled=body.get("enabled");return account(u);
    }
    @GetMapping("/dashboard")
    public Object dashboard(@RequestParam(defaultValue="0") int filePage,@RequestParam(defaultValue="0") int indexPage,@RequestParam(defaultValue="10") int size) throws Exception {
        V3Paths.noLinks(crypto);
        var fileSlice=files.cipherPreviews(CloudService.page(filePage,size));
        var indexSlice=indexes.findAll(CloudService.page(indexPage,size));
        List<Map<String,Object>> privateKeys=new ArrayList<>();
        for(AppUser u:users.findAll()) {
            if(u.ibeetId==null) continue;
            String name=HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(u.ibeetId.getBytes(StandardCharsets.UTF_8)))+".gcm";
            Path path=crypto.resolve(name);
            Map<String,Object> row=new LinkedHashMap<>();row.put("username",u.username);
            if(Files.isRegularFile(path,LinkOption.NOFOLLOW_LINKS)) {
                V3Paths.noLinks(path);
                if(Files.size(path)>65572) throw new IllegalStateException();
                byte[] bytes=Files.readAllBytes(path);
                if(bytes.length>65572) throw new IllegalStateException();
                row.put("format","IBEV3GCM / AES-256-GCM");row.put("bytes",bytes.length);
                row.put("ciphertext",Base64.getEncoder().encodeToString(bytes));
            } else { row.put("format","尚未建立或遺失");row.put("ciphertext",""); }
            privateKeys.add(row);
        }
        List<Map<String,Object>> encryptedFiles=fileSlice.stream().map(f->{
            Map<String,Object> row=new LinkedHashMap<>();
            row.put("fileId",f.getId());row.put("ownerId",f.getOwnerId());row.put("size",f.getSize());
            row.put("algorithm","AES-256-GCM");row.put("nonce",f.getNonce());
            row.put("ciphertextPreview",f.getPreview());
            row.put("ciphertextCharacters",f.getCharacters());
            row.put("protectedFileKeyFormat",f.getKeyFormat().equals("GCM3:")?"GCM3":"UNKNOWN");
            return row;
        }).toList();
        List<Map<String,Object>> encryptedIndexes=indexSlice.stream().map(i->{
            Map<String,Object> row=new LinkedHashMap<>();row.put("indexId",i.getId());row.put("fileId",i.getFileId());
            row.put("hashVersion",i.getHashVersion()==null?1:i.getHashVersion());
            row.put("c1",i.getC1());row.put("c2",i.getC2());row.put("c3",i.getC3());row.put("c4",i.getC4());
            return row;
        }).toList();
        return Map.of("userCount",users.count(),"fileCount",files.count(),"indexCount",indexes.count(),
            "privateKeys",privateKeys,"encryptedFiles",encryptedFiles,"encryptedIndexes",encryptedIndexes,
            "pagination",Map.of("filePage",filePage,"indexPage",indexPage,"size",size,"filesHasNext",fileSlice.hasNext(),"indexesHasNext",indexSlice.hasNext()),
            "system",Map.of("database","UP","systemCipherPresent",Files.isRegularFile(crypto.resolve("system.gcm"),LinkOption.NOFOLLOW_LINKS),
            "encryption","伺服器端加密與應用程式權限隔離","sessionTimeoutMinutes",20));
    }
}
