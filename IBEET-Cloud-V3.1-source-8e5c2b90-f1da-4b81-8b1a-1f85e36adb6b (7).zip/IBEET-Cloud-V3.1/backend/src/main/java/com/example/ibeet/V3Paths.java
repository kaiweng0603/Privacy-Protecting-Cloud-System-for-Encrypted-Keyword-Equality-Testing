package com.example.ibeet;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.io.IOException;
import java.util.Set;
public final class V3Paths {
 private V3Paths() {}
 public static Path root(String value) {
  if(value==null||value.isBlank())throw new IllegalStateException("必須指定獨立 V3.1 根目錄");
  Path root=Path.of(value).toAbsolutePath().normalize();
  if(!root.getFileName().toString().equals("IBEET-Cloud-V3.1"))throw new IllegalStateException("拒絕非 V3.1 根目錄");
  for(Path p:root)if(Set.of("ibeet-cloud-v1","ibeet-cloud-v2","ibeet-cloud-v3").contains(p.toString().toLowerCase(java.util.Locale.ROOT)))throw new IllegalStateException("V3.1 不可位於舊專案內");
  noLinks(root);
  try {
   noLinks(root.resolve(".ibeet-v31"));
   if(!Files.readString(root.resolve(".ibeet-v31"),StandardCharsets.US_ASCII).equals("IBEET-CLOUD-V3.1\n"))throw new IllegalStateException("V3.1 標記不符");
   return root.toRealPath();
  }catch(IOException e){throw new IllegalStateException("無法驗證 V3.1 根目錄");}
 }
 public static void noLinks(Path path){
  try {
   Path current=path.toAbsolutePath().normalize().getRoot();
   for(Path part:path.toAbsolutePath().normalize()){
    current=current.resolve(part);
    if(Files.exists(current,LinkOption.NOFOLLOW_LINKS)&&(Files.isSymbolicLink(current)||!current.toRealPath().equals(current.toAbsolutePath().normalize())))throw new IllegalStateException("拒絕符號連結、重新解析點或祖先目錄逃逸");
   }
  }catch(IOException e){throw new IllegalStateException("無法驗證實際路徑");}
 }
 public static Path check(Path root,String value){
  Path raw=Path.of(value);
  for(Path part:raw)if(part.toString().equals("..")||part.toString().equals("."))throw new IllegalStateException("路徑不可含跳脫片段");
  Path p=raw.toAbsolutePath().normalize();
  if(!p.startsWith(root.resolve("runtime-v31"))&&!p.startsWith(root.resolve(".test-runs")))throw new IllegalStateException("資料只能位於獨立 V3.1 執行／測試目錄");
  noLinks(p);return p;
 }
 public static String linux(Path path){
  String p=path.toAbsolutePath().normalize().toString().replace('\\','/');
  if(p.matches("^[A-Za-z]:/.*"))return "/mnt/"+Character.toLowerCase(p.charAt(0))+p.substring(2);
  if(p.startsWith("/"))return p;
  throw new IllegalStateException("不支援的 WSL 路徑");
 }
}
