
package com.example.ibeet;

import jakarta.persistence.*;

@Entity
@Table(name = "encrypted_files")
public class EncryptedFile {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String fileName;
    private String ownerId;
    @Column(nullable=false,unique=true)
    private String cryptoContext = java.util.UUID.randomUUID().toString();
    private long size;
    private java.time.Instant createdAt = java.time.Instant.now();
    @Version private long version;
    public String getCryptoContext() { return cryptoContext; }
    public long getSize() { return size; }
    public void setSize(long size) { this.size=size; }
    public java.time.Instant getCreatedAt() { return createdAt; }

    // IBEET 密文 delta1
    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String c1;

    // IBEET 密文 delta2
    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String c2;

    // IBEET 密文 delta3：搜尋比對使用
    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String c3;

    // IBEET 密文 delta4
    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String c4;

    // AES-GCM 加密後的檔案內容
    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String filePayload;

    // AES-GCM nonce
    @Column(length = 100)
    private String aesNonce;

    // 受保護的 AES 金鑰
    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String aesKeyProtected;

    // Getters / Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }

    public String getC1() {
        return c1;
    }

    public void setC1(String c1) {
        this.c1 = c1;
    }

    public String getC2() {
        return c2;
    }

    public void setC2(String c2) {
        this.c2 = c2;
    }

    public String getC3() {
        return c3;
    }

    public void setC3(String c3) {
        this.c3 = c3;
    }

    public String getC4() {
        return c4;
    }

    public void setC4(String c4) {
        this.c4 = c4;
    }

    public String getFilePayload() {
        return filePayload;
    }

    public void setFilePayload(String filePayload) {
        this.filePayload = filePayload;
    }

    public String getAesNonce() {
        return aesNonce;
    }

    public void setAesNonce(String aesNonce) {
        this.aesNonce = aesNonce;
    }

    public String getAesKeyProtected() {
        return aesKeyProtected;
    }

    public void setAesKeyProtected(String aesKeyProtected) {
        this.aesKeyProtected = aesKeyProtected;
    }
}
