package com.example.ibeet;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import org.springframework.context.annotation.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.security.core.context.SecurityContextHolder;
import java.io.IOException;
import java.nio.file.*;
import java.util.concurrent.Semaphore;
public class UploadBoundary extends OncePerRequestFilter {
    public static final long FILE_LIMIT=20L*1024*1024,REQUEST_LIMIT=22L*1024*1024;
    private final Semaphore memorySlots=new Semaphore(2,true);
    int available(){return memorySlots.availablePermits();}
    @Override protected void doFilterInternal(HttpServletRequest q,HttpServletResponse r,FilterChain chain)throws ServletException,IOException {
        String uri=RequestPaths.route(q);boolean upload=uri.equals("/api/files/upload")&&q.getMethod().equals("POST");
        boolean download=uri.startsWith("/api/files/download/")&&(q.getMethod().equals("GET")||q.getMethod().equals("HEAD"));
        boolean multipart=q.getContentType()!=null&&q.getContentType().toLowerCase(java.util.Locale.ROOT).startsWith("multipart/");
        if(multipart&&!upload){SecurityConfig.json(r,415,"不接受此上傳格式");return;}
        if(upload||download){
            var auth=SecurityContextHolder.getContext().getAuthentication();
            if(auth==null||auth.getAuthorities().stream().noneMatch(a->a.getAuthority().equals("ROLE_USER"))){SecurityConfig.json(r,auth==null?401:403,"需要 USER 身分");return;}
            if(upload&&(!multipart||q.getContentLengthLong()<1||q.getHeader("Transfer-Encoding")!=null)){SecurityConfig.json(r,411,"上傳必須提供已知長度的 multipart 請求");return;}
            if(upload&&q.getContentLengthLong()>REQUEST_LIMIT){SecurityConfig.json(r,413,"上傳請求超過 22 MiB");return;}
            if(!memorySlots.tryAcquire()){r.setHeader("Retry-After","2");SecurityConfig.json(r,503,"檔案處理已達記憶體並行上限，請稍後再試");return;}
            try{chain.doFilter(q,r);}finally{memorySlots.release();}
        }else{
            if(!q.getMethod().equals("GET")&&q.getHeader("Transfer-Encoding")!=null){SecurityConfig.json(r,411,"必須提供已知的請求長度");return;}
            if(!q.getMethod().equals("GET")&&q.getContentLengthLong()>16384){SecurityConfig.json(r,413,"請求內容過大");return;}
            chain.doFilter(q,r);
        }
    }
    @Configuration static class MultipartMemoryConfig {
        @Bean MultipartConfigElement multipartConfigElement(@Value("${ibeet.project-root}") String project,
                @Value("${ibeet.crypto-directory}") String crypto)throws IOException {
            Path root=V3Paths.root(project),dir=V3Paths.check(root,crypto).getParent().resolve("multipart-unused");
            V3Paths.check(root,dir.toString());Files.createDirectories(dir);V3Paths.noLinks(dir);
            // Every permitted request fits in memory; a threshold cannot be reached before maxRequestSize rejects it.
            return new MultipartConfigElement(dir.toString(),FILE_LIMIT,REQUEST_LIMIT,(int)REQUEST_LIMIT);
        }
    }
}
