package com.example.ibeet;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
public interface UserRepository extends JpaRepository<AppUser,Long> {
    @org.springframework.data.jpa.repository.Lock(jakarta.persistence.LockModeType.PESSIMISTIC_WRITE)
    @org.springframework.data.jpa.repository.Query("select u from AppUser u where u.ibeetId=:owner and u.role='USER' and u.enabled=true")
    Optional<AppUser> lockOwner(@org.springframework.data.repository.query.Param("owner") String owner);
    Optional<AppUser> findByUsername(String username);
}
