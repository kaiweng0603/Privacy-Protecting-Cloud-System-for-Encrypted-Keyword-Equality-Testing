package com.example.ibeet;
import org.springframework.core.env.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.EnvironmentPostProcessor;
import java.nio.file.*;
import java.util.*;
public class V3EnvironmentGuard implements EnvironmentPostProcessor {
 static void rejectOverrides(ConfigurableEnvironment env){
  for(var source:env.getPropertySources())if(source instanceof EnumerablePropertySource<?> enumerable)
   for(String name:enumerable.getPropertyNames()){
    String key=name.toLowerCase(Locale.ROOT).replaceAll("[-_.]","");
    if((key.startsWith("springdatasourcehikari")&&!key.equals("springdatasourcehikariconnectioninitsql"))||key.startsWith("springdatasourcetomcat")||key.startsWith("springdatasourcedbcp")||key.equals("springdatasourcetype")||key.equals("springdatasourcejndiname")||key.equals("springdatasourcedriverclassname")||key.startsWith("springjpaproperties")||key.startsWith("springflyway")||key.startsWith("springliquibase"))throw new IllegalStateException("拒絕替代資料來源或資料庫初始化設定");
   }
 }
 public static Path jdbc(Path root,String url){
  String prefix="jdbc:h2:file:",suffix=";DB_CLOSE_ON_EXIT=FALSE";
  if(url==null||!url.startsWith(prefix)||!url.endsWith(suffix))throw new IllegalStateException("資料庫必須為獨立 V3.1 H2 檔案");
  String name=url.substring(prefix.length(),url.length()-suffix.length());
  if(name.contains(";")||name.contains("\\")||name.contains("\n"))throw new IllegalStateException("拒絕資料庫額外選項");
  return V3Paths.check(root,name);
 }
 @Override public void postProcessEnvironment(ConfigurableEnvironment env,SpringApplication app){
  rejectOverrides(env);Path root=V3Paths.root(env.getRequiredProperty("ibeet.project-root"));
  jdbc(root,env.getRequiredProperty("spring.datasource.url"));
  V3Paths.check(root,env.getRequiredProperty("ibeet.root-key-file"));V3Paths.check(root,env.getRequiredProperty("ibeet.crypto-directory"));
  if(env.getProperty("spring.h2.console.enabled",Boolean.class,false)||!env.getProperty("spring.sql.init.mode","never").equals("never")||!env.getProperty("spring.datasource.hikari.connection-init-sql","").equals("SET WRITE_DELAY 0"))throw new IllegalStateException("拒絕 Console／非預期資料庫初始化");
  if(!env.getProperty("spring.servlet.multipart.enabled",Boolean.class,true)||!env.getProperty("spring.servlet.multipart.file-size-threshold","22MB").equals("22MB")||!env.getProperty("spring.servlet.multipart.max-file-size","20MB").equals("20MB")||!env.getProperty("spring.servlet.multipart.max-request-size","22MB").equals("22MB"))throw new IllegalStateException("不可覆寫上傳記憶體安全限制");
 }
}
