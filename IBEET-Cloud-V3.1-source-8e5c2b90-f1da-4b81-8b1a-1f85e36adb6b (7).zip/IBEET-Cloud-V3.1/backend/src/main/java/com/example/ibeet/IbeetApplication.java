package com.example.ibeet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IbeetApplication {

	public static void main(String[] args) {
		var context=SpringApplication.run(IbeetApplication.class, args);
		if(context.getEnvironment().getProperty("ibeet.initialize",Boolean.class,false))
			context.close();
	}

}
