
package com.example.ibeet;

import org.springframework.stereotype.Service;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;

@Service
public class FileEncryptionService {

    private static final int AES_KEY_SIZE = 256;
    private static final int GCM_NONCE_SIZE = 12;
    private static final int GCM_TAG_SIZE_BITS = 128;

    private final SecureRandom secureRandom = new SecureRandom();

    public EncryptedPayload encrypt(byte[] plaintext, String context)
            throws GeneralSecurityException {

        // 每個檔案產生獨立的 AES 金鑰
        KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
        keyGenerator.init(AES_KEY_SIZE, secureRandom);
        SecretKey key = keyGenerator.generateKey();

        // GCM 使用 12-byte nonce；同一把金鑰不可重複使用 nonce
        byte[] nonce = new byte[GCM_NONCE_SIZE];
        secureRandom.nextBytes(nonce);

        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(
            Cipher.ENCRYPT_MODE,
            key,
            new GCMParameterSpec(GCM_TAG_SIZE_BITS, nonce)
        );

        cipher.updateAAD(context.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        byte[] ciphertext = cipher.doFinal(plaintext);

        return new EncryptedPayload(
            Base64.getEncoder().encodeToString(key.getEncoded()),
            Base64.getEncoder().encodeToString(nonce),
            Base64.getEncoder().encodeToString(ciphertext)
        );
    }

    public byte[] decrypt(
            String encodedKey,
            String encodedNonce,
            String encodedCiphertext, String context)
            throws GeneralSecurityException {

        byte[] keyBytes = Base64.getDecoder().decode(encodedKey);
        byte[] nonce = Base64.getDecoder().decode(encodedNonce);
        byte[] ciphertext = Base64.getDecoder().decode(encodedCiphertext);

        if (keyBytes.length != 32 || nonce.length != GCM_NONCE_SIZE) {
            throw new GeneralSecurityException("無效的金鑰或 nonce 長度");
        }

        SecretKey key = new javax.crypto.spec.SecretKeySpec(keyBytes, "AES");

        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(
            Cipher.DECRYPT_MODE,
            key,
            new GCMParameterSpec(GCM_TAG_SIZE_BITS, nonce)
        );

        // 若密文遭到竄改，GCM 驗證會失敗
        cipher.updateAAD(context.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        return cipher.doFinal(ciphertext);
    }

    public static class EncryptedPayload {
        private final String key;
        private final String nonce;
        private final String ciphertext;

        public EncryptedPayload(
                String key, String nonce, String ciphertext) {
            this.key = key;
            this.nonce = nonce;
            this.ciphertext = ciphertext;
        }

        public String getKey() {
            return key;
        }

        public String getNonce() {
            return nonce;
        }

        public String getCiphertext() {
            return ciphertext;
        }
    }
}
