package com.example.ibeet;
import java.util.Map;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.*;
import org.springframework.web.server.ResponseStatusException;
@RestControllerAdvice
public class ApiErrors {
    @ExceptionHandler(ResponseStatusException.class)
    ResponseEntity<?> status(ResponseStatusException e) {
        return ResponseEntity.status(e.getStatusCode()).body(Map.of("message", e.getReason()==null?"請求遭拒":e.getReason()));
    }
    @ExceptionHandler(IllegalArgumentException.class)
    ResponseEntity<?> invalid(IllegalArgumentException e) {
        return ResponseEntity.badRequest().body(Map.of("message","輸入格式不正確"));
    }
    @ExceptionHandler(org.springframework.web.multipart.MaxUploadSizeExceededException.class)
    ResponseEntity<?> uploadTooLarge(Exception e) {
        return ResponseEntity.status(HttpStatus.PAYLOAD_TOO_LARGE).body(Map.of("message","檔案或上傳請求超過大小限制"));
    }
    @ExceptionHandler(Exception.class)
    ResponseEntity<?> failure(Exception e) {
        if(e instanceof InterruptedException) Thread.currentThread().interrupt();
        return ResponseEntity.internalServerError().body(Map.of("message","操作失敗，請檢查本機服務與加密資料完整性；未重新產生任何金鑰"));
    }
}
