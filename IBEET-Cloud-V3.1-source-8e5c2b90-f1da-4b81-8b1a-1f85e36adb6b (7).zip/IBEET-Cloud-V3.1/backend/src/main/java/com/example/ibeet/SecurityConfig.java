package com.example.ibeet;
import org.springframework.context.annotation.*;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.core.userdetails.*;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
@Configuration
@org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication(type=org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication.Type.SERVLET)
public class SecurityConfig {
    @Bean UserDetailsService users(UserRepository users) {
        return name -> users.findByUsername(name)
            .map(u->new SessionUser(u))
            .orElseThrow(()->new UsernameNotFoundException("帳號或密碼錯誤"));
    }
    static void json(HttpServletResponse r,int code,String message) throws IOException {
        r.setStatus(code); r.setContentType("application/json;charset=UTF-8");
        r.getWriter().write("{\"message\":\""+message+"\"}");
    }
    @Bean SecurityFilterChain security(HttpSecurity http,UserRepository users) throws Exception {
        http.authorizeHttpRequests(a->a
            .requestMatchers("/api/auth/csrf","/api/auth/login").permitAll()
            .requestMatchers("/api/admin/**").hasRole("ADMIN")
            .requestMatchers("/api/files/**").hasRole("USER")
            .requestMatchers("/api/auth/me","/api/auth/logout").authenticated()
            .anyRequest().denyAll())
            .formLogin(f->f.loginProcessingUrl("/api/auth/login")
                .successHandler((q,r,a)->json(r,200,"登入成功"))
                .failureHandler((q,r,e)->json(r,401,"帳號或密碼錯誤")))
            .logout(l->l.logoutUrl("/api/auth/logout").invalidateHttpSession(true)
                .deleteCookies("IBEET_V31_SESSION")
                .logoutSuccessHandler((q,r,a)->json(r,200,"已登出")))
            .sessionManagement(s->s.sessionFixation(f->f.changeSessionId()))
            .exceptionHandling(e->e
                .authenticationEntryPoint((q,r,x)->json(r,401,"請先登入"))
                .accessDeniedHandler((q,r,x)->json(r,403,"權限不足或 CSRF 驗證失敗")))
            .headers(h->h.contentSecurityPolicy(c->c.policyDirectives("default-src 'none'; frame-ancestors 'none'")));
        http.addFilterBefore(new UploadBoundary(),org.springframework.security.web.csrf.CsrfFilter.class);
        http.addFilterBefore(new LoginThrottle(),org.springframework.security.web.csrf.CsrfFilter.class);
        http.addFilterBefore(new org.springframework.web.filter.OncePerRequestFilter() {
            @Override protected void doFilterInternal(HttpServletRequest q,HttpServletResponse r,FilterChain chain)
                    throws ServletException,IOException {
                r.setHeader("Cache-Control","no-store");
                var auth=org.springframework.security.core.context.SecurityContextHolder.getContext().getAuthentication();
                if(auth!=null && !"anonymousUser".equals(auth.getName()) &&
                    users.findByUsername(auth.getName()).filter(u->u.enabled &&
                        auth.getPrincipal() instanceof SessionUser principal && principal.accountVersion==u.version &&
                        auth.getAuthorities().stream()
                        .anyMatch(a->a.getAuthority().equals("ROLE_"+u.role))).isEmpty()) {
                    if(q.getSession(false)!=null) q.getSession(false).invalidate();
                    org.springframework.security.core.context.SecurityContextHolder.clearContext();
                    if(!RequestPaths.route(q).equals("/api/auth/csrf")&&!RequestPaths.route(q).equals("/api/auth/login")) {
                        json(r,401,"帳號狀態已變更，請重新登入"); return;
                    }
                }
                chain.doFilter(q,r);
            }
        },UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }
}
