package com.example.ibeet;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import java.util.concurrent.*;
@Component
public class SearchLimits {
 private final ConcurrentHashMap<String,Semaphore> owners=new ConcurrentHashMap<>();
 private final int comparisons;private final long timeout;
 public SearchLimits(@Value("${ibeet.search.max-comparisons:512}")int comparisons,@Value("${ibeet.search.timeout-ms:10000}")long timeout){
  if(comparisons<1||comparisons>512||timeout<1||timeout>10000)throw new IllegalStateException("搜尋限制必須在安全上限內");this.comparisons=comparisons;this.timeout=timeout;
 }
 public synchronized Budget begin(String owner){
  if(owners.size()>=256&&!owners.containsKey(owner))throw new ResponseStatusException(HttpStatus.TOO_MANY_REQUESTS,"搜尋工作已滿");
  Semaphore gate=owners.computeIfAbsent(owner,k->new Semaphore(1,true));
  if(!gate.tryAcquire())throw new ResponseStatusException(HttpStatus.TOO_MANY_REQUESTS,"此帳號已有搜尋工作");
  return new Budget(gate,System.nanoTime()+TimeUnit.MILLISECONDS.toNanos(timeout),comparisons);
 }
 public static final class Budget implements AutoCloseable {
  private final Semaphore gate;private final long deadline;private int remaining;private boolean closed;
  Budget(Semaphore gate,long deadline,int remaining){this.gate=gate;this.deadline=deadline;this.remaining=remaining;}
  public long remainingMillis(){long n=deadline-System.nanoTime();if(n<=0)throw new ResponseStatusException(HttpStatus.GATEWAY_TIMEOUT,"搜尋已超過時間上限，未回傳部分結果");return Math.max(1,TimeUnit.NANOSECONDS.toMillis(n));}
  public void comparison(){remainingMillis();if(remaining--<=0)throw new ResponseStatusException(HttpStatus.UNPROCESSABLE_ENTITY,"搜尋比對工作量超限，請縮小頁面或查詢詞");}
  @Override public void close(){if(!closed){closed=true;gate.release();}}
 }
}
