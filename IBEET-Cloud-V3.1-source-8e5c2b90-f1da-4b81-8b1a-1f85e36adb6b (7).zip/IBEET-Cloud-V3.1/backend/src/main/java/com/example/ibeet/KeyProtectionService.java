package com.example.ibeet;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Value;
import javax.crypto.*;
import javax.crypto.spec.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;
@Service
public class KeyProtectionService {
    private final byte[] root;
    private final SecureRandom random=new SecureRandom();
    public KeyProtectionService(@Value("${ibeet.project-root}") String projectRoot,@Value("${ibeet.root-key-file}") String path) throws Exception {
        Path p=V3Paths.check(V3Paths.root(projectRoot),path);
        root=Files.readAllBytes(p);
        if(root.length!=32) throw new IllegalStateException("V3 根金鑰長度錯誤；拒絕自動重建");
    }
    public byte[] derive(String purpose) throws GeneralSecurityException {
        Mac mac=Mac.getInstance("HmacSHA256"); mac.init(new SecretKeySpec(root,"HmacSHA256"));
        return mac.doFinal(("IBEET-V3/"+purpose).getBytes(StandardCharsets.UTF_8));
    }
    public String seal(String text,String purpose,String context) throws GeneralSecurityException {
        byte[] nonce=new byte[12]; random.nextBytes(nonce);
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(derive(purpose),"AES"),new GCMParameterSpec(128,nonce));
        c.updateAAD(context.getBytes(StandardCharsets.UTF_8));
        byte[] encrypted=c.doFinal(text.getBytes(StandardCharsets.UTF_8));
        return "GCM3:"+Base64.getEncoder().encodeToString(nonce)+":"+Base64.getEncoder().encodeToString(encrypted);
    }
    public String authenticate(String text) throws GeneralSecurityException {
        Mac mac=Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(derive("index-integrity"),"HmacSHA256"));
        return HexFormat.of().formatHex(mac.doFinal(text.getBytes(StandardCharsets.UTF_8)));
    }
    public String open(String value,String purpose,String context) throws GeneralSecurityException {
        try {
            String[] v=value.split(":",-1);
            if(v.length!=3 || !v[0].equals("GCM3")) throw new GeneralSecurityException("格式錯誤");
            byte[] nonce=Base64.getDecoder().decode(v[1]);
            if(nonce.length!=12) throw new GeneralSecurityException("格式錯誤");
            Cipher c=Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE,new SecretKeySpec(derive(purpose),"AES"),new GCMParameterSpec(128,nonce));
            c.updateAAD(context.getBytes(StandardCharsets.UTF_8));
            return new String(c.doFinal(Base64.getDecoder().decode(v[2])),StandardCharsets.UTF_8);
        } catch(IllegalArgumentException|NullPointerException e) { throw new GeneralSecurityException("驗證失敗"); }
    }
}
