package com.example.ibeet;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.springframework.mock.web.*;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.core.env.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.apache.tomcat.util.http.fileupload.*;
import org.apache.tomcat.util.http.fileupload.disk.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import com.zaxxer.hikari.HikariConfig;

class V31HttpAcceptanceTests {
 static final Path ROOT=V31RegressionTests.ROOT;
 static Path fresh(String prefix)throws Exception{return V31RegressionTests.fresh(prefix);}
 @Test void realHttpSessionAesQuotaAndProjectionPagination()throws Exception {
  Path dir=fresh("http");Files.createDirectory(dir.resolve("crypto"));byte[] root=new byte[32];new SecureRandom().nextBytes(root);Files.write(dir.resolve("root.key"),root);Arrays.fill(root,(byte)0);
  String win=dir.toString().replace('\\','/');
  try(var context=new SpringApplicationBuilder(IbeetApplication.class).run("--ibeet.project-root="+ROOT.toString().replace('\\','/'),"--server.port=0","--spring.main.banner-mode=off","--spring.datasource.password=","--logging.level.root=WARN","--spring.datasource.url=jdbc:h2:file:"+win+"/cloud;DB_CLOSE_ON_EXIT=FALSE","--ibeet.root-key-file="+win+"/root.key","--ibeet.crypto-directory="+win+"/crypto","--ibeet.quota.max-files=2","--ibeet.quota.max-bytes=1024")){
   var users=context.getBean(UserRepository.class);var passwords=context.getBean(org.springframework.security.crypto.password.PasswordEncoder.class);
   for(String name:List.of("alice","bob","admin")){var u=new AppUser();u.username=name;u.role=name.equals("admin")?"ADMIN":"USER";u.ibeetId=name.equals("admin")?null:"test-"+UUID.randomUUID();u.passwordHash=passwords.encode(IbeetApplicationTests.PASSWORD);users.saveAndFlush(u);}
   IbeetApplicationTests.base="http://127.0.0.1:"+context.getEnvironment().getProperty("local.server.port");
   try(var alice=new IbeetApplicationTests.Client();var bob=new IbeetApplicationTests.Client();var admin=new IbeetApplicationTests.Client();var guest=new IbeetApplicationTests.Client()){
    IbeetApplicationTests.status(401,guest.get("/api/files/list"));
    for(var pair:List.of(Map.entry(alice,"alice"),Map.entry(bob,"bob"),Map.entry(admin,"admin")))IbeetApplicationTests.status(200,pair.getKey().login(pair.getValue(),IbeetApplicationTests.PASSWORD));
    long a=alice.upload("a.txt","","forged-bob"),a2=alice.upload("a2.txt","","forged-bob"),b=bob.upload("b.txt","","forged-alice");
    var page=IbeetApplicationTests.JSON.readTree(alice.get("/api/files/list?page=0&size=1").body());assertEquals(1,page.get("items").size());assertTrue(page.get("hasNext").asBoolean());assertEquals(2,page.get("candidateTotal").asInt());assertFalse(page.toString().contains("filePayload"));
    var second=IbeetApplicationTests.JSON.readTree(alice.get("/api/files/list?page=1&size=1").body());assertEquals(a2,second.get("items").get(0).get("fileId").asLong());
    var downloaded=alice.get("/api/files/download/"+a);IbeetApplicationTests.status(200,downloaded);assertArrayEquals(IbeetApplicationTests.digest("V3 real payload a.txt".getBytes(StandardCharsets.UTF_8)),IbeetApplicationTests.digest(downloaded.body()));
    IbeetApplicationTests.status(404,alice.get("/api/files/download/"+b));IbeetApplicationTests.status(404,alice.json("PATCH","/api/files/"+b+"/rename",Map.of("fileName","bad.txt")));
    IbeetApplicationTests.status(403,admin.get("/api/files/list"));IbeetApplicationTests.status(403,admin.get("/api/files/download/"+a));
    String boundary="quota-test";String body="--"+boundary+"\r\nContent-Disposition: form-data; name=\"file\"; filename=\"over.txt\"\r\n\r\nextra\r\n--"+boundary+"--\r\n";
    IbeetApplicationTests.status(507,alice.send("POST","/api/files/upload","multipart/form-data; boundary="+boundary,body.getBytes(StandardCharsets.UTF_8),true));
    var dash=admin.get("/api/admin/dashboard?size=1");IbeetApplicationTests.status(200,dash);var data=IbeetApplicationTests.JSON.readTree(dash.body());assertEquals(1,data.get("encryptedFiles").size());assertTrue(data.get("pagination").get("filesHasNext").asBoolean());
    var stored=context.getBean(FileRepository.class).findById(a).orElseThrow();assertEquals(stored.getFilePayload().substring(0,Math.min(192,stored.getFilePayload().length())),data.get("encryptedFiles").get(0).get("ciphertextPreview").asText());
    IbeetApplicationTests.status(200,alice.json("DELETE","/api/files/"+a,Map.of()));alice.upload("replacement.txt","","bob");
    IbeetApplicationTests.status(200,alice.send("POST","/api/auth/logout",null,null,true));IbeetApplicationTests.status(401,alice.get("/api/files/list"));
   }
   try(var tmp=Files.list(dir.resolve("multipart-unused"))){assertEquals(0,tmp.count());}
  }
 }
}

