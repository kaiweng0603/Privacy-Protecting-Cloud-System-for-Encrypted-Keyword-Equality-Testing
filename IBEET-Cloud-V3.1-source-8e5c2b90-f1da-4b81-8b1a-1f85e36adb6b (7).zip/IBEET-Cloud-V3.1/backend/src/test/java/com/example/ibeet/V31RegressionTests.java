package com.example.ibeet;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.springframework.mock.web.*;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.core.env.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.apache.tomcat.util.http.fileupload.*;
import org.apache.tomcat.util.http.fileupload.disk.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import com.zaxxer.hikari.HikariConfig;

class V31RegressionTests {
 static final Path ROOT=V3Paths.root(Path.of("").toAbsolutePath().getParent().toString());
 static Path fresh(String prefix)throws Exception {
  Path dir=V3Paths.check(ROOT,ROOT.resolve(".test-runs/"+prefix+"-"+UUID.randomUUID()).toString());Files.createDirectories(dir);return dir;
 }
 static void user(){SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken("review-user",null,List.of(new SimpleGrantedAuthority("ROLE_USER"))));}
 static MockHttpServletRequest upload(long length){var q=new MockHttpServletRequest("POST","/api/files/upload"){@Override public long getContentLengthLong(){return length;}};q.setContentType("multipart/form-data; boundary=test");return q;}
 @Test void multipartNeverSpoolsPermittedParts()throws Exception {
  Path dir=fresh("multipart");var config=new UploadBoundary.MultipartMemoryConfig().multipartConfigElement(ROOT.toString(),dir.resolve("crypto").toString());
  assertEquals(22*1024*1024,config.getFileSizeThreshold());assertEquals(UploadBoundary.REQUEST_LIMIT,config.getMaxRequestSize());
  var factory=new DiskFileItemFactory(config.getFileSizeThreshold(),dir.toFile());var parser=new FileUpload();parser.setFileItemFactory(factory);parser.setFileSizeMax(config.getMaxFileSize());parser.setSizeMax(config.getMaxRequestSize());
  byte[] body=("--test\r\nContent-Disposition: form-data; name=\"keyword\"\r\n\r\nsynthetic-private-marker\r\n--test\r\nContent-Disposition: form-data; name=\"file\"; filename=\"sample.txt\"\r\n\r\nsynthetic-file-marker\r\n--test--\r\n").getBytes(StandardCharsets.US_ASCII);
  UploadContext context=new UploadContext(){public String getCharacterEncoding(){return "UTF-8";}public String getContentType(){return "multipart/form-data; boundary=test";}public InputStream getInputStream(){return new ByteArrayInputStream(body);}public long contentLength(){return body.length;}};
  var items=parser.parseRequest(context);assertEquals(2,items.size());
  for(var item:items){assertTrue(item.isInMemory());assertFalse(((DiskFileItem)item).getStoreLocation()!=null&&((DiskFileItem)item).getStoreLocation().exists());item.delete();}
  var file=(DiskFileItem)factory.createItem("file","application/octet-stream",false,"max.bin");
  try(var out=file.getOutputStream()){out.write(new byte[(int)UploadBoundary.FILE_LIMIT]);}
  assertTrue(file.isInMemory());file.delete();
  try(var paths=Files.list(dir)){assertTrue(paths.noneMatch(p->p.getFileName().toString().startsWith("upload_")));}
 }
 @Test void multipartOversizeRejectedBeforeReading()throws Exception {
  var parser=new FileUpload();parser.setFileItemFactory(new DiskFileItemFactory());parser.setSizeMax(UploadBoundary.REQUEST_LIMIT);var read=new AtomicBoolean();
  UploadContext context=new UploadContext(){public String getCharacterEncoding(){return "UTF-8";}public String getContentType(){return "multipart/form-data; boundary=test";}public InputStream getInputStream(){read.set(true);return InputStream.nullInputStream();}public long contentLength(){return UploadBoundary.REQUEST_LIMIT+1;}};
  assertThrows(FileUploadException.class,()->parser.parseRequest(context));assertFalse(read.get());
 }
 @Test void uploadAdmissionRejectsSizeAndLengthWithoutParsing()throws Exception {
  var filter=new UploadBoundary();user();try{
   var denied=new MockHttpServletResponse();filter.doFilter(upload(UploadBoundary.REQUEST_LIMIT+1),denied,(q,r)->fail("oversize reached parser"));assertEquals(413,denied.getStatus());
   var unknown=new MockHttpServletResponse();filter.doFilter(upload(-1),unknown,(q,r)->fail("unknown length reached parser"));assertEquals(411,unknown.getStatus());
   var error=new MockHttpServletResponse();assertThrows(jakarta.servlet.ServletException.class,()->filter.doFilter(upload(100),error,(q,r)->{throw new jakarta.servlet.ServletException("synthetic");}));assertEquals(2,filter.available());
  }finally{SecurityContextHolder.clearContext();}
 }
 @Test void uploadConcurrencyBoundAndRelease()throws Exception {
  var filter=new UploadBoundary();var entered=new CountDownLatch(2);var release=new CountDownLatch(1);var failure=new AtomicReference<Throwable>();
  Runnable task=()->{user();try{filter.doFilter(upload(100),new MockHttpServletResponse(),(q,r)->{entered.countDown();try{if(!release.await(5,TimeUnit.SECONDS))throw new jakarta.servlet.ServletException("test timeout");}catch(InterruptedException e){throw new jakarta.servlet.ServletException(e);}});}catch(Throwable e){failure.set(e);}finally{SecurityContextHolder.clearContext();}};
  Thread a=Thread.startVirtualThread(task),b=Thread.startVirtualThread(task);
  try{assertTrue(entered.await(3,TimeUnit.SECONDS));user();var third=new MockHttpServletResponse();filter.doFilter(upload(100),third,(q,r)->fail("third heavy request admitted"));assertEquals(503,third.getStatus());assertEquals(0,filter.available());}
  finally{release.countDown();a.join(3000);b.join(3000);SecurityContextHolder.clearContext();}
  assertNull(failure.get());assertEquals(2,filter.available());
 }
 @Test void datasourceAlternativeSettingsFailBeforeAnyConnection()throws Exception {
  Path dir=fresh("datasource");String normal="jdbc:h2:file:"+dir.resolve("cloud").toString().replace('\\','/')+";DB_CLOSE_ON_EXIT=FALSE";
  for(String name:List.of("spring.datasource.hikari.jdbc-url","SPRING_DATASOURCE_HIKARI_JDBC_URL","spring.datasource.hikari.data-source-class-name","spring.datasource.jndi-name","spring.jpa.properties.jakarta.persistence.jdbc.url")){
   var env=new StandardEnvironment();env.getPropertySources().addFirst(new MapPropertySource("synthetic",Map.of(name,"jdbc:h2:mem:must-not-open")));
   assertThrows(IllegalStateException.class,()->V3EnvironmentGuard.rejectOverrides(env));
  }
  var bad=new HikariConfig();bad.setJdbcUrl("jdbc:h2:mem:must-not-open");bad.setDriverClassName("org.h2.Driver");bad.setConnectionInitSql("SET WRITE_DELAY 0");
  assertThrows(IllegalStateException.class,()->new SafeDataSourceConfig.GuardedDataSource(ROOT,normal,bad));
  assertThrows(IllegalStateException.class,()->V3EnvironmentGuard.jdbc(ROOT,normal+";INIT=SELECT 1"));
  try(var files=Files.list(dir)){assertEquals(0,files.count());}
 }
 @Test void decodedLoginPathSharesTheSameThrottle()throws Exception {
  var limiter=new LoginThrottle();var invoked=new AtomicInteger();
  for(int i=0;i<11;i++){
   var request=new MockHttpServletRequest("POST","/api/auth/%6cogin");request.setServletPath("/api/auth/login");request.setContent(new byte[0]);
   var response=new MockHttpServletResponse();limiter.doFilter(request,response,(q,r)->invoked.incrementAndGet());
   assertEquals(i<10?200:429,response.getStatus());
  }
  assertEquals(10,invoked.get());
 }
 @Test void encodedAndHeadDownloadsUseMemoryAdmission()throws Exception {
  var filter=new UploadBoundary();var visited=new AtomicBoolean();user();
  try{
   var request=new MockHttpServletRequest("HEAD","/api/files/%64ownload/1");request.setServletPath("/api/files/download/1");
   filter.doFilter(request,new MockHttpServletResponse(),(q,r)->{visited.set(true);assertEquals(1,filter.available());});
   assertTrue(visited.get());assertEquals(2,filter.available());
  }finally{SecurityContextHolder.clearContext();}
 }
 @Test void pathsRejectOutsideAndDotTraversal()throws Exception {
  Path dir=fresh("path");assertEquals(dir,V3Paths.check(ROOT,dir.toString()));
  assertThrows(IllegalStateException.class,()->V3Paths.check(ROOT,ROOT.resolve("backend/outside").toString()));
  assertThrows(IllegalStateException.class,()->V3Paths.check(ROOT,dir.resolve("../other").toString()));
  assertThrows(IllegalStateException.class,()->V3Paths.root(ROOT.getParent().resolve("review-source").toString()));
 }
 @Test void ancestorLinkRejected()throws Exception {
  Path dir=fresh("link"),target=dir.resolve("target"),alias=dir.resolve("alias");Files.createDirectory(target);
  if(System.getProperty("os.name").startsWith("Windows")){
   Process p=new ProcessBuilder("cmd.exe","/c","mklink","/J",alias.toString(),target.toString()).redirectErrorStream(true).start();
   byte[] diagnostic=p.getInputStream().readAllBytes();assertTrue(p.waitFor(5,TimeUnit.SECONDS));
   org.junit.jupiter.api.Assumptions.assumeTrue(p.exitValue()==0,"環境無法建立 NTFS junction；本項未驗證，非通過。exit="+p.exitValue()+" diagnostic="+new String(diagnostic,java.nio.charset.Charset.defaultCharset()));
  }else Files.createSymbolicLink(alias,target);
  assertThrows(IllegalStateException.class,()->V3Paths.check(ROOT,alias.resolve("nested/new.key").toString()));
  assertFalse(Files.exists(target.resolve("nested")));
 }
 @Test void searchWorkLimitDeadlineAndOwnerIsolation()throws Exception {
  var limits=new SearchLimits(2,10000);
  try(var one=limits.begin("alice")){assertThrows(ResponseStatusException.class,()->limits.begin("alice"));try(var two=limits.begin("bob")){two.comparison();}one.comparison();one.comparison();assertEquals(422,assertThrows(ResponseStatusException.class,one::comparison).getStatusCode().value());}
  try(var again=limits.begin("alice")){again.comparison();}
  try(var expired=new SearchLimits(2,5).begin("alice")){Thread.sleep(15);assertEquals(504,assertThrows(ResponseStatusException.class,expired::remainingMillis).getStatusCode().value());}
 }
 @Test void loginRateWindowAndStorageBound(){
  var clock=new AtomicLong();var limiter=new LoginThrottle(clock::get);
  for(int i=0;i<10;i++)assertTrue(limiter.accept("synthetic-client"));assertFalse(limiter.accept("synthetic-client"));
  clock.set(60_000_000_001L);assertTrue(limiter.accept("synthetic-client"));
  for(int i=0;i<1023;i++)assertTrue(limiter.accept("synthetic-"+i));assertFalse(limiter.accept("over-capacity"));
 }
 @Test void realDatabaseQuotaAesAndProjectionWithoutNetwork()throws Exception {
  Path dir=fresh("service");Files.createDirectory(dir.resolve("crypto"));byte[] key=new byte[32];new SecureRandom().nextBytes(key);Files.write(dir.resolve("root.key"),key);Arrays.fill(key,(byte)0);
  String base=dir.toString().replace('\\','/');
  try(var context=new SpringApplicationBuilder(IbeetApplication.class).run("--spring.main.web-application-type=none","--ibeet.project-root="+ROOT.toString().replace('\\','/'),"--spring.main.banner-mode=off","--spring.datasource.password=","--logging.level.root=WARN","--spring.datasource.url=jdbc:h2:file:"+base+"/cloud;DB_CLOSE_ON_EXIT=FALSE","--ibeet.root-key-file="+base+"/root.key","--ibeet.crypto-directory="+base+"/crypto","--ibeet.quota.max-files=2","--ibeet.quota.max-bytes=100")){
   var users=context.getBean(UserRepository.class);var passwords=context.getBean(org.springframework.security.crypto.password.PasswordEncoder.class);var alice=new AppUser();alice.username="alice";alice.role="USER";alice.ibeetId="test-"+UUID.randomUUID();alice.passwordHash=passwords.encode(UUID.randomUUID().toString());users.saveAndFlush(alice);
   var bob=new AppUser();bob.username="bob";bob.role="USER";bob.ibeetId="test-"+UUID.randomUUID();bob.passwordHash=passwords.encode(UUID.randomUUID().toString());users.saveAndFlush(bob);
   var cloud=context.getBean(CloudService.class);var files=context.getBean(FileRepository.class);
   SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken(new SessionUser(alice),null,List.of(new SimpleGrantedAuthority("ROLE_USER"))));
   byte[] payload="real-service-synthetic-payload".getBytes(StandardCharsets.UTF_8);
   var upload=new MockMultipartFile("file","first.txt","application/octet-stream",payload);
   long first=(Long)cloud.upload(upload,"").get("fileId");long second=(Long)cloud.upload(new MockMultipartFile("file","second.txt","application/octet-stream",payload),"").get("fileId");
   assertArrayEquals(payload,cloud.download(first).bytes());assertFalse(files.findById(first).orElseThrow().getFilePayload().contains("synthetic-payload"));
   assertEquals(507,assertThrows(ResponseStatusException.class,()->cloud.upload(upload,"")).getStatusCode().value());assertEquals(2,files.countByOwnerId(alice.ibeetId));
   var page=cloud.list(0,1);assertTrue((boolean)page.get("hasNext"));assertEquals(2L,page.get("candidateTotal"));
   assertEquals(second,((List<Map<String,Object>>)cloud.list(1,1).get("items")).get(0).get("fileId"));
   var preview=files.cipherPreviews(CloudService.page(0,1)).getContent().get(0);assertEquals(files.findById(first).orElseThrow().getFilePayload().substring(0,Math.min(192,files.findById(first).orElseThrow().getFilePayload().length())),preview.getPreview());assertEquals("GCM3:",preview.getKeyFormat());
   cloud.delete(first);cloud.upload(upload,"");
   SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken(new SessionUser(bob),null,List.of(new SimpleGrantedAuthority("ROLE_USER"))));
   assertEquals(404,assertThrows(ResponseStatusException.class,()->cloud.download(second)).getStatusCode().value());
   assertEquals(0L,cloud.list(0,10).get("candidateTotal"));
   assertThrows(IllegalArgumentException.class,()->cloud.upload(upload,"\u0000keyword"));assertEquals(0,files.countByOwnerId(bob.ibeetId));
   assertEquals(507,assertThrows(ResponseStatusException.class,()->cloud.upload(new MockMultipartFile("file","oversize-quota.txt","application/octet-stream",new byte[101]),"")).getStatusCode().value());
   assertEquals(0,files.countByOwnerId(bob.ibeetId));cloud.upload(upload,"");
  }finally{SecurityContextHolder.clearContext();}
 }
 @Test void keywordInputAndPaginationBoundaries(){
  CloudService.validateWord("海".repeat(166)+"AA");CloudService.validateWord("A".repeat(500));
  assertThrows(IllegalArgumentException.class,()->CloudService.validateWord("A".repeat(501)));
  assertThrows(IllegalArgumentException.class,()->CloudService.validateWord("bad\u0000word"));assertThrows(IllegalArgumentException.class,()->CloudService.validateWord("\ud800"));
  assertThrows(IllegalArgumentException.class,()->CloudService.page(0,26));assertThrows(IllegalArgumentException.class,()->CloudService.page(-1,10));
 }
}

