package com.example.ibeet;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.json.JsonMapper;
import java.net.*;
import java.net.http.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.io.*;
import java.util.*;

class IbeetApplicationTests {
    static final JsonMapper JSON=JsonMapper.builder().build();
    static final Path ROOT=V3Paths.root(Path.of("").toAbsolutePath().getParent().toString());
    static final Path RUN=ROOT.resolve(".test-runs/java-"+UUID.randomUUID());
    static final String PASSWORD=UUID.randomUUID()+"-Aa9";
    static String base;
    static final List<String> passed=new ArrayList<>();
    static void pass(String text) { passed.add(text); }
    static class Client implements AutoCloseable {
        final CookieManager cookies=new CookieManager(null,CookiePolicy.ACCEPT_ALL);
        final HttpClient http=HttpClient.newBuilder().cookieHandler(cookies).build();
        String token;
        HttpResponse<byte[]> send(String method,String path,String type,byte[] body,boolean csrf) throws Exception {
            if(csrf) token=tree(send("GET","/api/auth/csrf",null,null,false)).get("token").asText();
            var builder=HttpRequest.newBuilder(URI.create(base+path)).timeout(java.time.Duration.ofSeconds(90));
            if(type!=null) builder.header("Content-Type",type);
            if(csrf) builder.header("X-CSRF-TOKEN",token);
            return http.send(builder.method(method,body==null?HttpRequest.BodyPublishers.noBody():HttpRequest.BodyPublishers.ofByteArray(body)).build(),HttpResponse.BodyHandlers.ofByteArray());
        }
        HttpResponse<byte[]> get(String path) throws Exception { return send("GET",path,null,null,false); }
        HttpResponse<byte[]> json(String method,String path,Object data) throws Exception {
            return send(method,path,"application/json",JSON.writeValueAsBytes(data),true);
        }
        HttpResponse<byte[]> login(String user,String password) throws Exception {
            return send("POST","/api/auth/login","application/x-www-form-urlencoded",
                ("username="+user+"&password="+URLEncoder.encode(password,StandardCharsets.UTF_8)).getBytes(StandardCharsets.UTF_8),true);
        }
        long upload(String name,String word,String forgedOwner) throws Exception {
            String boundary="v3boundary"+UUID.randomUUID();
            String data="--"+boundary+"\r\nContent-Disposition: form-data; name=\"keyword\"\r\n\r\n"+word+
                "\r\n--"+boundary+"\r\nContent-Disposition: form-data; name=\"ownerId\"\r\n\r\n"+forgedOwner+
                "\r\n--"+boundary+"\r\nContent-Disposition: form-data; name=\"file\"; filename=\""+name+"\"\r\nContent-Type: application/octet-stream\r\n\r\n"+
                "V3 real payload "+name+"\r\n--"+boundary+"--\r\n";
            var r=send("POST","/api/files/upload","multipart/form-data; boundary="+boundary,data.getBytes(StandardCharsets.UTF_8),true);
            status(200,r);return tree(r).get("fileId").asLong();
        }
        public void close() { http.close(); }
    }
    static JsonNode tree(HttpResponse<byte[]> r) { var node=JSON.readTree(r.body());return node.has("items")?node.get("items"):node; }
    static void status(int n,HttpResponse<byte[]> r) { assertEquals(n,r.statusCode(),"HTTP "+r.uri().getPath()); }
    static byte[] digest(byte[] b) throws Exception { return MessageDigest.getInstance("SHA-256").digest(b); }
    ConfigurableApplicationContext start(boolean init) throws Exception {
        String win=RUN.toString().replace('\\','/');
        String linux="/mnt/c/"+win.substring(3);
        InputStream old=System.in;
        if(init) {
            String line=HexFormat.of().formatHex(PASSWORD.getBytes(StandardCharsets.UTF_8))+"\n";
            System.setIn(new ByteArrayInputStream(line.repeat(3).getBytes(StandardCharsets.US_ASCII)));
        }
        try {
            var context=new SpringApplicationBuilder(IbeetApplication.class).run(
                "--server.port=0","--spring.main.banner-mode=off","--spring.datasource.password=","--logging.level.root=WARN","--ibeet.project-root="+ROOT.toString().replace('\\','/'),
                "--spring.datasource.url=jdbc:h2:file:"+win+"/db;DB_CLOSE_ON_EXIT=FALSE",
                "--ibeet.root-key-file="+win+"/root.key",
                "--ibeet.crypto-directory="+win+"/crypto","--ibeet.initialize="+init);
            base="http://127.0.0.1:"+context.getEnvironment().getProperty("local.server.port");
            return context;
        } finally { System.setIn(old); }
    }
    @Test void realCryptoAndSessionAcceptance() throws Exception {
        Files.createDirectories(RUN.resolve("crypto"));
        byte[] root=new byte[32];new SecureRandom().nextBytes(root);Files.write(RUN.resolve("root.key"),root);
        long aliceId,bobId;
        try(var context=start(true);var guest=new Client();var alice=new Client();var bob=new Client();var admin=new Client()) {
            status(401,guest.get("/api/files/list")); pass("未登入 API 拒絕");
            status(403,guest.send("POST","/api/auth/login","application/x-www-form-urlencoded","username=alice&password=x".getBytes(),false)); pass("登入 CSRF 防護");
            status(401,guest.login("alice","wrong-password")); pass("錯誤密碼拒絕");
            guest.get("/api/auth/csrf");
            String before=guest.cookies.getCookieStore().getCookies().get(0).getValue();
            status(200,guest.login("alice",PASSWORD));
            String after=guest.cookies.getCookieStore().getCookies().get(0).getValue();
            assertNotEquals(before,after); pass("Session Fixation 輪替");
            var cookie=new Client();
            try(cookie) {
                var response=cookie.get("/api/auth/csrf");
                String set=response.headers().firstValue("set-cookie").orElseThrow().toLowerCase(Locale.ROOT);
                assertTrue(set.contains("ibeet_v31_session=")&&set.contains("httponly")&&set.contains("samesite=strict"));
                pass("HttpOnly / SameSite / V3 Cookie");
            }
            status(200,alice.login("alice",PASSWORD));status(200,bob.login("bob",PASSWORD));status(200,admin.login("admin",PASSWORD));
            pass("Alice / Bob / Admin BCrypt 登入");
            var ur=context.getBean(UserRepository.class);
            assertTrue(ur.findByUsername("admin").orElseThrow().ibeetId==null);
            assertTrue(ur.findByUsername("alice").orElseThrow().passwordHash.startsWith("$2"));
            pass("Admin 無解密身分，密碼為 BCrypt");
            aliceId=alice.upload("alice.txt","ocean2026,第二個關鍵字","bob");
            bobId=bob.upload("bob.txt","ocean2026","alice");pass("雙使用者真實上傳");
            var listA=tree(alice.get("/api/files/list?ownerId=bob"));
            assertEquals(1,listA.size());assertEquals(aliceId,listA.get(0).get("fileId").asLong());
            assertEquals(bobId,tree(bob.get("/api/files/list?ownerId=alice")).get(0).get("fileId").asLong());
            pass("列表與 ownerId 偽造隔離");
            var aDownload=alice.get("/api/files/download/"+aliceId);status(200,aDownload);
            var bDownload=bob.get("/api/files/download/"+bobId);status(200,bDownload);
            assertArrayEquals(digest(("V3 real payload alice.txt").getBytes(StandardCharsets.UTF_8)),digest(aDownload.body()));
            assertArrayEquals(digest(("V3 real payload bob.txt").getBytes(StandardCharsets.UTF_8)),digest(bDownload.body()));
            pass("雙使用者下載 SHA-256 相同");
            status(404,alice.get("/api/files/download/"+bobId+"?ownerId=bob"));
            status(404,bob.get("/api/files/download/"+aliceId));pass("fileId 越權下載拒絕");
            status(404,alice.json("PATCH","/api/files/"+bobId+"/rename",Map.of("fileName","attack.txt","ownerId","bob")));
            status(404,alice.json("DELETE","/api/files/"+bobId,Map.of()));pass("越權重新命名與刪除拒絕");
            status(404,alice.get("/api/files/"+bobId+"/keywords"));
            status(404,alice.json("POST","/api/files/"+bobId+"/keywords",Map.of("keyword","attack","ownerId","bob")));
            var bi=context.getBean(FileKeywordIndexRepository.class).findByFileId(bobId).get(0);
            status(404,alice.json("DELETE","/api/files/"+bobId+"/keywords/"+bi.getId(),Map.of()));
            status(404,alice.json("DELETE","/api/files/"+aliceId+"/keywords/"+bi.getId(),Map.of()));
            pass("跨使用者與跨檔案關鍵字操作拒絕");
            for(var pair:List.of(Map.entry(alice,aliceId),Map.entry(bob,bobId))) {
                var r=pair.getKey().json("POST","/api/files/search",Map.of("query","ocean2026","mode","keyword","ownerId","forged"));
                status(200,r);assertEquals(1,tree(r).size());assertEquals(pair.getValue(),tree(r).get(0).get("fileId").asLong());
                assertEquals("ibeet",tree(r).get(0).get("matchType").asText());
            }
            pass("同關鍵字以真實 IBEET 搜尋且僅回傳自己的檔案");
            String longWord="A".repeat(80)+"-one",otherWord="A".repeat(80)+"-two";
            long longId=alice.upload("longword.txt",longWord,"bob");
            assertEquals(0,tree(alice.json("POST","/api/files/search",Map.of("query",otherWord,"mode","keyword"))).size());
            assertEquals(1,tree(alice.json("POST","/api/files/search",Map.of("query",longWord,"mode","keyword"))).size());
            assertEquals(3,context.getBean(FileKeywordIndexRepository.class).findByFileId(longId).get(0).getHashVersion());
            status(200,alice.json("DELETE","/api/files/"+longId,Map.of()));pass("F01 HV3 長共同前綴 HTTP 真實配對回歸");
            assertEquals(0,tree(alice.json("POST","/api/files/search",Map.of("query","not-existing","mode","keyword"))).size());
            assertEquals(0,tree(alice.json("POST","/api/files/search",Map.of("query","alice.txt","mode","keyword"))).size());
            assertEquals(1,tree(alice.json("POST","/api/files/search",Map.of("query","ALICE","mode","filename"))).size());
            pass("不存在關鍵字、搜尋模式隔離與檔名搜尋");
            status(200,alice.json("POST","/api/files/"+aliceId+"/keywords",Map.of("keyword","newword,newword")));
            assertEquals(3,tree(alice.get("/api/files/"+aliceId+"/keywords")).get("keywords").size());
            long newIndex=tree(alice.get("/api/files/"+aliceId+"/keywords")).get("keywords").get(2).get("indexId").asLong();
            status(200,alice.json("DELETE","/api/files/"+aliceId+"/keywords/"+newIndex,Map.of()));
            assertEquals(0,tree(alice.json("POST","/api/files/search",Map.of("query","newword","mode","keyword"))).size());
            pass("多關鍵字新增、去重、刪除與搜尋一致");
            var fr=context.getBean(FileRepository.class);
            var ir=context.getBean(FileKeywordIndexRepository.class);
            var f=fr.findById(aliceId).orElseThrow();
            assertFalse(f.getFilePayload().contains("V3 real payload"));
            assertFalse(Arrays.equals(Base64.getDecoder().decode(f.getFilePayload()),aDownload.body()));
            assertTrue(f.getAesKeyProtected().startsWith("GCM3:"));
            for(var i:ir.findAll()) {
                assertTrue(i.getKeywordProtected().startsWith("GCM3:"));
                assertFalse(i.getKeywordProtected().contains("ocean2026"));
            }
            pass("資料庫檔案、檔案金鑰與關鍵字認證加密");
            try(var stream=Files.list(RUN.resolve("crypto"))) {
                for(Path p:stream.filter(p->p.toString().endsWith(".gcm")).toList())
                    assertEquals("IBEV3GCM",new String(Files.readAllBytes(p),0,8,StandardCharsets.US_ASCII));
            }
            pass("IBEET 主秘密與私鑰認證加密持久化");
            var dashboard=admin.get("/api/admin/dashboard");status(200,dashboard);
            var dash=tree(dashboard);assertEquals(2,dash.get("fileCount").asInt());
            assertFalse(dash.get("privateKeys").get(0).get("ciphertext").asText().isBlank());
            assertFalse(new String(dashboard.body(),StandardCharsets.UTF_8).contains("ocean2026"));
            assertFalse(new String(dashboard.body(),StandardCharsets.UTF_8).contains(PASSWORD));
            assertEquals(f.getFilePayload().substring(0,Math.min(192,f.getFilePayload().length())),dash.get("encryptedFiles").get(0).get("ciphertextPreview").asText());
            pass("管理後台使用真實密文且無敏感明文");
            status(403,admin.get("/api/files/list"));status(403,admin.get("/api/files/download/"+aliceId));
            status(403,admin.get("/api/files/"+aliceId+"/keywords"));
            status(403,admin.json("POST","/api/files/search",Map.of("query","ocean2026")));
            status(403,alice.get("/api/admin/dashboard"));pass("Admin 與 USER 權限分離");
            status(403,alice.json("POST","/api/algorithm/encrypt-and-save",Map.of()));
            status(403,admin.json("POST","/api/algorithm/encrypt",Map.of()));pass("舊演算法 API 停用");
            status(403,alice.send("PATCH","/api/files/"+aliceId+"/rename","application/json","{\"fileName\":\"bad\"}".getBytes(),false));pass("寫入 API CSRF 拒絕");
            String payload=f.getFilePayload();
            byte[] corrupted=Base64.getDecoder().decode(payload);corrupted[0]^=1;
            f.setFilePayload(Base64.getEncoder().encodeToString(corrupted));fr.saveAndFlush(f);
            status(500,alice.get("/api/files/download/"+aliceId));
            f=fr.findById(aliceId).orElseThrow();f.setFilePayload(payload);fr.saveAndFlush(f);
            var protection=context.getBean(KeyProtectionService.class);
            String envelope=protection.seal("sensitive","keyword","owner:test");
            assertThrows(GeneralSecurityException.class,()->protection.open(envelope,"file-key","owner:test"));
            assertThrows(GeneralSecurityException.class,()->protection.open(envelope,"keyword","wrong-owner"));
            byte[] wrong=new byte[32];new SecureRandom().nextBytes(wrong);Files.write(RUN.resolve("wrong.key"),wrong);
            var wrongKeys=new KeyProtectionService(ROOT.toString(),RUN.resolve("wrong.key").toString());
            assertThrows(GeneralSecurityException.class,()->wrongKeys.open(envelope,"keyword","owner:test"));
            pass("錯誤金鑰、用途、AAD 與檔案密文竄改拒絕");
            var originalIndex=ir.findByFileId(aliceId).get(0);
            String originalC3=originalIndex.getC3();
            originalIndex.setC3(originalC3.charAt(0)=='a'?"b"+originalC3.substring(1):"a"+originalC3.substring(1));
            ir.saveAndFlush(originalIndex);
            status(500,alice.json("POST","/api/files/search",Map.of("query","ocean2026","mode","keyword")));
            originalIndex=ir.findById(originalIndex.getId()).orElseThrow();
            originalIndex.setC3(originalC3);ir.saveAndFlush(originalIndex);
            pass("IBEET 索引密文完整性驗證拒絕竄改");
            Path systemPath=RUN.resolve("crypto/system.gcm");
            byte[] systemBytes=Files.readAllBytes(systemPath),badSystem=systemBytes.clone();
            badSystem[badSystem.length-1]^=1;Files.write(systemPath,badSystem);
            long countBefore=fr.count(),indexesBefore=ir.count();
            String boundary="rollback-boundary";
            String rollbackBody="--"+boundary+"\r\nContent-Disposition: form-data; name=\"keyword\"\r\n\r\nrollbackword\r\n--"+boundary+"\r\nContent-Disposition: form-data; name=\"file\"; filename=\"rollback.txt\"\r\n\r\nrollback\r\n--"+boundary+"--\r\n";
            try {
                status(500,alice.send("POST","/api/files/upload","multipart/form-data; boundary="+boundary,rollbackBody.getBytes(StandardCharsets.UTF_8),true));
                assertEquals(countBefore,fr.count());assertEquals(indexesBefore,ir.count());
                assertArrayEquals(badSystem,Files.readAllBytes(systemPath));
            } finally { Files.write(systemPath,systemBytes); }
            pass("C 加密失敗時檔案與索引整筆回滾且不重建金鑰");
            long aliceUser=ur.findByUsername("alice").orElseThrow().id;
            status(200,admin.json("PATCH","/api/admin/users/"+aliceUser,Map.of("enabled",false)));
            status(401,alice.get("/api/files/list"));status(401,guest.login("alice",PASSWORD));
            status(200,admin.json("PATCH","/api/admin/users/"+aliceUser,Map.of("enabled",true)));
            status(401,guest.get("/api/files/list"));
            status(200,alice.login("alice",PASSWORD));pass("停用帳號立即撤銷既有 Session");
            status(200,alice.json("PATCH","/api/files/"+aliceId+"/rename",Map.of("fileName","renamed.txt")));
            assertEquals("renamed.txt",tree(alice.get("/api/files/list")).get(0).get("fileName").asText());pass("本人重新命名成功");
            var logout=alice.send("POST","/api/auth/logout",null,null,true);status(200,logout);
            status(401,alice.get("/api/auth/me"));status(401,alice.get("/api/files/list"));pass("登出 Session 失效");
        }
        try(var restarted=start(false);var alice=new Client();var bob=new Client()) {
            status(200,alice.login("alice",PASSWORD));status(200,bob.login("bob",PASSWORD));
            status(200,alice.get("/api/files/download/"+aliceId));
            assertEquals(1,tree(alice.json("POST","/api/files/search",Map.of("query","ocean2026","mode","keyword"))).size());
            status(200,bob.get("/api/files/download/"+bobId));
            pass("系統重啟後帳號、檔案與真實 IBEET 搜尋正常");
            status(200,alice.json("DELETE","/api/files/"+aliceId,Map.of()));
            assertEquals(0,restarted.getBean(FileKeywordIndexRepository.class).findByFileId(aliceId).size());
            status(404,alice.get("/api/files/download/"+aliceId));
            pass("本人刪除檔案與索引交易一致");
        }
        Files.write(RUN.resolve("acceptance-results.txt"),passed,StandardCharsets.UTF_8);
        for(String item:passed) System.out.println("PASS: "+item);
        System.out.println("V3_ACCEPTANCE_GROUPS="+passed.size());
    }
    @Test void rejectUnsafeEnvironmentBeforeDatabaseCreation() {
        var env=new org.springframework.core.env.StandardEnvironment();
        env.getPropertySources().addFirst(new org.springframework.core.env.MapPropertySource("unsafe",
            Map.of("spring.datasource.url","jdbc:h2:file:C:/IBEET-Cloud-V2/DO-NOT-OPEN;DB_CLOSE_ON_EXIT=FALSE")));
        assertThrows(IllegalStateException.class,()->new V3EnvironmentGuard().postProcessEnvironment(env,null));
    }
    Process child(Path dir,int port,boolean init) throws Exception {
        String win=dir.toString().replace('\\','/');
        List<String> command=new ArrayList<>(List.of(Path.of(System.getProperty("java.home"),"bin","java.exe").toString(),
            "-cp",System.getProperty("surefire.test.class.path",System.getProperty("java.class.path")),
            IbeetApplication.class.getName(),"--server.port="+port,"--spring.main.banner-mode=off","--spring.datasource.password=","--logging.level.root=WARN","--ibeet.project-root="+ROOT.toString().replace('\\','/'),
            "--spring.datasource.url=jdbc:h2:file:"+win+"/db;DB_CLOSE_ON_EXIT=FALSE","--ibeet.root-key-file="+win+"/root.key",
            "--ibeet.crypto-directory="+win+"/crypto","--ibeet.initialize="+init));
        Process p=new ProcessBuilder(command).redirectErrorStream(true)
            .redirectOutput(dir.resolve("process-"+UUID.randomUUID()+".log").toFile()).start();
        try(var input=p.getOutputStream()) {
            if(init) input.write((HexFormat.of().formatHex(PASSWORD.getBytes(StandardCharsets.UTF_8))+"\n").repeat(3).getBytes(StandardCharsets.US_ASCII));
        }
        return p;
    }
    int freePort() throws Exception { try(var socket=new java.net.ServerSocket(0,0,InetAddress.getLoopbackAddress())) { return socket.getLocalPort(); } }
    void ready(Process p,int port) throws Exception {
        base="http://127.0.0.1:"+port;
        try(var client=new Client()) {
            long deadline=System.nanoTime()+java.time.Duration.ofSeconds(40).toNanos();
            while(System.nanoTime()<deadline && p.isAlive()) {
                try { if(client.get("/api/auth/csrf").statusCode()==200) return; } catch(IOException e) {}
                Thread.sleep(150);
            }
        }
        fail("獨立 Java 程序未就緒；請檢查測試專用 process log");
    }
    void stop(Process p) throws Exception { if(p!=null&&p.isAlive()) { p.destroy();if(!p.waitFor(10,java.util.concurrent.TimeUnit.SECONDS)) p.destroyForcibly(); } }
    @Test void actualJavaProcessRestart() throws Exception {
        Path dir=RUN.getParent().resolve(UUID.randomUUID().toString());Files.createDirectories(dir.resolve("crypto"));
        byte[] root=new byte[32];new SecureRandom().nextBytes(root);Files.write(dir.resolve("root.key"),root);
        Process init=child(dir,0,true);
        try { assertTrue(init.waitFor(45,java.util.concurrent.TimeUnit.SECONDS));assertEquals(0,init.exitValue()); }
        finally { stop(init); }
        long id;int port=freePort();Process first=child(dir,port,false);
        try {
            ready(first,port);
            try(var alice=new Client()) { status(200,alice.login("alice",PASSWORD));id=alice.upload("restart.txt","restartword","bob"); }
        } finally { stop(first); }
        port=freePort();Process second=child(dir,port,false);
        try {
            ready(second,port);
            try(var alice=new Client()) {
                status(200,alice.login("alice",PASSWORD));
                var d=alice.get("/api/files/download/"+id);status(200,d);
                assertArrayEquals(digest("V3 real payload restart.txt".getBytes(StandardCharsets.UTF_8)),digest(d.body()));
                var r=alice.json("POST","/api/files/search",Map.of("query","restartword","mode","keyword"));
                status(200,r);assertEquals(id,tree(r).get(0).get("fileId").asLong());
            }
        } finally { stop(second); }
        byte[] oldSystem=Files.readAllBytes(dir.resolve("crypto/system.gcm"));
        byte[] wrong=new byte[32];new SecureRandom().nextBytes(wrong);Files.write(dir.resolve("root.key"),wrong);
        Process rejected=child(dir,0,false);
        try {
            assertTrue(rejected.waitFor(40,java.util.concurrent.TimeUnit.SECONDS));assertNotEquals(0,rejected.exitValue());
            assertArrayEquals(oldSystem,Files.readAllBytes(dir.resolve("crypto/system.gcm")));
        } finally { stop(rejected);Files.write(dir.resolve("root.key"),root); }
        Files.writeString(dir.resolve("process-restart-results.txt"),"PASS: Java process restart, SHA-256 download, real IBEET search, wrong-key startup refusal\n");
        System.out.println("PASS: ACTUAL_JAVA_PROCESS_RESTART_AND_WRONG_KEY_REFUSAL");
    }
}

