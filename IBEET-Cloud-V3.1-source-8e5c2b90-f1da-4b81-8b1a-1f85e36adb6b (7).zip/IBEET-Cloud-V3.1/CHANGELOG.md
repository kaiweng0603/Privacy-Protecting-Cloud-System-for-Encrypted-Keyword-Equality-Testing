# V3.1 修正清單

2026-11-15。此版從 V3 已驗證來源獨立複製；V3 基準及真實資料均未更動。修正來源已完成，驗收仍有環境阻礙，不能標示全面通過。

| 缺陷 | 來源變更 | 已有實測／待補 |
| --- | --- | --- |
| F01 | hash.c/hash.h 新增核准的 HV3 完整輸入 SHA-256 前處理；ibeet_cli 新增 encrypt/compare/match-v3；CloudService 新建版本 3；參數指紋固定 | 已有向量／真實 CLI／HTTP 測試來源，WSL 與 HTTP 受限，未驗證 C 執行 |
| F02 | UploadBoundary、固定 MultipartConfigElement、20/22 MiB 大小及兩個重型名額、411/413/503 | Tomcat parser、20 MiB 記憶體保存、超限拒絕與並行釋放通過；HTTP 磁碟監測待補 |
| F03 | SafeDataSourceConfig／GuardedDataSource、啟動覆寫拒絕、最終連線前重驗 | 替代設定與不符最終 URL 零連線拒絕、真實新 H2 操作通過 |
| F04 | V3Paths 全祖先檢查、Java/C 路徑同源推導；C openat/linkat/unlinkat 與固定 dirfd | dot／外部範圍拒絕通過；NTFS junction 夾具被拒、C 祖先／競態測試待補 |
| F05 | SearchLimits、最多兩個 C 程序與 Linux timeout、LoginThrottle、owner 列鎖配額、SQL 中繼資料投影、使用者及管理分頁 | 預算／逾時／節流／真實 H2 配額與隔離／片段投影通過；C 終止及完整 HTTP 待補 |

## 主要修改檔案

- backend：V3Paths、V3EnvironmentGuard、SafeDataSourceConfig、CredentialConfig、UploadBoundary、LoginThrottle、SearchLimits、FileSummary。
- backend：AlgorithmService、CloudService、FileController、AdminController、FileRepository、FileKeywordIndexRepository、UserRepository、SecurityConfig、KeyProtectionService、DataInitializer、ApiErrors、application.properties、pom.xml。
- 測試：保留並調整 IbeetApplicationTests；新增 V31RegressionTests、V31HttpAcceptanceTests、CSIE_project/tests/hash_v3_vectors.c；擴充 crypto_regression.py 及 Makefile。
- 前端：files API 分頁、HomeView 候選分頁及錯誤清除、AdminView 雙分頁、Vite 5176/8083。
- 腳本：Common、Build、Initialize、Start、Migrate、Package 均限定 V3.1；新增 Run-Validation 分項保留輸出／退出碼／受測來源雜湊。
- 文件全部更新，新增已確認的 HASH_VERSION3_DESIGN.md、.ibeet-v31、V3_BASELINE_MANIFEST.json 及去除秘密的 evidence/。

encrypt.c、decrypt.c、trapdoor.c、test.c 及舊 HV1/HV2 映射函式本體保留；對照證據見 evidence/legacy-core-check.json。沒有改用假演算法或明文 SQL 關鍵字搜尋。目錄與版本的完整修改／新增清單見 evidence/CHANGED_FILES.json。

V3.1 改用 8083/5176 與 IBEET_V31_SESSION，避免碰到既有 V3。研究型參數、舊版索引風險與伺服器端信任邊界未被誇大成已解決。

