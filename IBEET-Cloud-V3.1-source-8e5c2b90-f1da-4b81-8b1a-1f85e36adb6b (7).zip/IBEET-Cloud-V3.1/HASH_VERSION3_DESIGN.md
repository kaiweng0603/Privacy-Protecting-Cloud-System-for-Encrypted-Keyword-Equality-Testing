# F01：hashVersion 3 設計提案（2026-11-15 已獲使用者確認）

使用者已在本對話明確同意本方案並允許實作。V3 基準不變，V3.1 的 hashVersion 1、2 核心語意保持原樣；version 3 已依此方案新增來源，真實 C/PBC 執行驗證仍待可用環境。

## 原因與方案比較

現有 version 2 將 0x02 加完整 UTF-8 關鍵字直接送入 PBC element_from_hash；PBC 會截斷長輸入，造成共同前綴的不同詞碰撞。domain separation 的單 byte 前綴無法代替完整輸入雜湊。

建議採研究專案的最小範圍修正：先以 SHA-256 對明確編碼的完整訊息做雜湊，再將固定 32-byte digest 映射到既有 PBC Type A 群。保留現有配對等式與公開參數。此為 PBC 專用研究映射，不宣稱為 RFC 9380 hash-to-curve suite，也不因此取得現代 128-bit 整體安全保證。

另一選項為遷移至有明確 RFC 9380 suite 與現代參數的配對曲線；這會影響參數、主秘密、私鑰與所有索引，超過本次相容修正範圍，應另做密碼學專案。不得改用「雜湊成 scalar 後對已知 generator 乘冪」這類未經分析的替代映射。

## 精確提案

- 新編號為 hashVersion=3，與應用程式版本 V3.1 分開。
- k 為已經過 API 原有外圍 trim、格式驗證後的完整 UTF-8 bytes；區分大小寫，不新增 NFC／NFKC／大小寫摺疊。新增及搜尋採同一前處理；拒絕 NUL、控制字元及無效 Unicode，單詞上限維持 500 UTF-8 bytes。
- DST 為固定 ASCII bytes `IBEET-CLOUD/KEYWORD/HV3/PBC-TYPE-A/SHA256`，其後加入單一 0x00 分隔 byte。
- D = SHA-256(DST || 0x00 || I2OSP(len(k),4) || k)，長度為 unsigned 32-bit big endian。
- Q = PBC element_from_hash(G1, D, 32)，使用既有受版本控制的 a.param；不得把 k 本身送給映射，不截短 k，不以明文 SQL 或私自解密名稱取代配對比對。
- 結果須檢查非群單位元素；失敗即拒絕，不靜默退回 version 2。參數檔的 SHA-256 必須記錄於測試向量及啟動驗證。
- 不修改 h1(ID||S)、h2(ID)、extract、encrypt、trapdoor、test 的既有公式；其完整密碼學安全性仍屬獨立稽核範圍。

固定 32-byte digest 低於目前 a.param 的底層 field 尺寸，避免原先「尾端完全未影響映射輸入」的確定性截斷問題；這不是無碰撞的數學保證，也不消除原配對參數、搜尋模式及伺服器端信任的限制。

## 相容性與預設政策

1. 保留 version 1／2 的原實作及明確版本分派；未知版本拒絕，不猜測或降級。
2. 經確認實作後，V3.1 全新索引預設只寫 version 3；不會把舊索引的 version 欄位改成 3。版本亦須列入索引完整性驗證。
3. version 1／2 的密文不能直接用 version 3 查詢；仍需按舊版本映射產生查詢密文。舊版原有長詞碰撞風險仍存在，不能宣稱因新增 version 3 就消失。
4. 本次 V3.1 只建立全新獨立資料庫，不載入真實 V3／V1／V2 資料。未提供自動遷移或自動重新索引。舊資料未來須由擁有者在明確授權下，以受保護名稱重新加密成新索引，逐檔驗證後再處理舊索引。
5. 對 version 1／2 的相容測試只使用本次新產生的測試金鑰與合成索引。維持其既有語意，並保留已知碰撞的重現測試作歷史證據；不得把該測試說成舊版安全通過。

## 實作後必須執行的驗證

- SHA-256 編碼的固定公開測試向量、C／Java 版本分派及參數指紋。
- 80 個 A 加不同尾碼的 84-byte 詞、500-byte 上限、長 UTF-8 共同前綴、空白／大小寫邊界；相同詞必須符合，不同詞案例不得符合。
- 真實 C encrypt／match／decrypt、Alice／Bob 相同關鍵字隔離、重啟，以及版本欄位遭竄改的拒絕。
- version 1／2 原測試仍執行；未知版本 fail closed；不以 stub 或假密文取得通過。

參考：[PBC 手冊](https://crypto.stanford.edu/pbc/manual.html)、[PBC 截斷說明](https://crypto.stanford.edu/pbc/manual/ch12s01.html)、[RFC 9380](https://www.rfc-editor.org/rfc/rfc9380.html)。

