# V3.1 安全架構與限制

本版為安全修正候選來源，**尚未通過真實 C/PBC、完整 HTTP、重啟及 Windows ACL 驗收**。請先閱讀 TEST_REPORT.md；不得以個別元件通過取代全面驗收。

## 信任與角色

USER 只能透過已驗證 Session 存取自己 IBEET_ID 的資料；不信任傳入 ownerId。ADMIN 僅能取得管理 DTO、實際私鑰密文、檔案密文片段及 IBEET 索引，沒有一般檔案解密身分、重設他人密碼、修改角色或冒充入口。Spring Security 的 Session、BCrypt cost 12、CSRF、session id 輪替及停用帳號撤銷規則保留。

伺服器處理上傳、搜尋及下載明文。OS／程序操作者位於信任邊界內，不能宣稱最高權限者無法解密。不是端對端或零知識加密。

## hashVersion 3

使用者已確認：D=SHA-256(ASCII DST || 0x00 || 4-byte big-endian UTF-8 byte length || 完整 UTF-8 keyword)，DST 為 IBEET-CLOUD/KEYWORD/HV3/PBC-TYPE-A/SHA256；將 32-byte D 送入原 PBC element_from_hash，檢查非單位元素。單詞最大 500 UTF-8 bytes，拒絕無效 Unicode、NUL 及控制字元，新增與搜尋使用相同 trim；沒有 Unicode 正規化或大小寫摺疊。

既有 version 1/2 映射及配對核心語意不變；未知版本拒絕。新建索引標示 3，索引完整性涵蓋版本。舊 1/2 的長共同前綴碰撞仍屬已知風險，需擁有者明確授權重建，不能只改版本欄位。沒有自動讀取或遷移舊資料。

此方案避免直接把長關鍵字送入會截斷的映射，並非 RFC 9380 suite 或獨立安全證明。原 Type A／PBC 參數仍屬研究等級，不宣稱現代 128-bit 整體安全。a.param 的 SHA-256 固定為 b9efd49cd3e32bda1c9c31a789eb442aa427e40743cc919ee3804afe1f684e6b，Java 與 C 啟動路徑均核對。

## 上傳與記憶體

固定 MultipartConfigElement：每檔 20 MiB、每請求 22 MiB、落盤門檻 22 MiB。因此合法 part 不會到達落盤門檻；超限由解析器拒絕。未信任任意外部 threshold 設定；啟動防護拒絕覆寫安全大小。一般 API JSON／表單請求也限制大小，Tomcat 文字表單上限 8 KiB；新增關鍵字可分批處理。

在 CSRF／multipart 解析前檢查 USER、Content-Length、Transfer-Encoding 及請求大小。路徑以容器解碼後的 servlet path 比對；編碼登入路徑仍節流，HEAD 下載也受同一限制。上傳／下載共用兩個 semaphore 名額，超出回 503，未知長度／chunked 上傳回 411。處理完畢或例外都釋放名額。兩個上傳 body 的原始輸入預算最多約 44 MiB；AES、Base64、JPA 與資料庫仍有額外配置，這不是整個 JVM 的硬記憶體上限。啟動腳本提供 768 MiB heap；仍須另做高負載與慢速連線測試。

獨立 Tomcat 元件已驗證欄位及上限內檔案留在記憶體，超限請求在讀取前拒絕。實際 HTTP 上傳／中斷時的磁碟監測尚未完成。無法保證 OS 交換區、崩潰傾印或 JVM String 的即時清除；主機防護仍必要。

## DataSource 與隔離

根目錄只接受名為 IBEET-Cloud-V3.1 且有精確標記的獨立目錄，拒絕放在舊專案內。執行資料只可在 runtime-v31 或 .test-runs。Java 驗證所有既有祖先，拒絕 symlink／junction 解析至其他實際位置及 dot 跳脫。

EnvironmentPostProcessor 拒絕替代 Hikari URL／driver／DataSource class、JNDI、其他 pool、JPA 連線屬性及 Flyway/Liquibase 類設定；H2 Console 與一般 SQL init 關閉。SafeDataSourceConfig 不交由一般 Hikari 屬性繫結，固定 org.h2.Driver、sa、SET WRITE_DELAY 0；每次取得連線前再核對最終 pool URL、額外資料來源設定與實際路徑。非預期值在連線前失敗。資料庫檔案沒有 H2 全檔加密，檔案與關鍵字內容先以 AES-GCM 加密後才寫入。

C 從本版執行檔位置定位根目錄，驗證標記及祖先，每一層用 O_DIRECTORY/O_NOFOLLOW 開啟，再固定 state dirfd。lock、讀取、0600 暫存、linkat 原子提交、unlinkat、fsync 都相對該描述符處理；拒絕符號連結和不正常硬連結檔案。Java 與 C 執行路徑都由同一根目錄與 crypto-directory 推導，不接受獨立 c-runtime 覆寫。

Java 的跨平台路徑檢查不是對抗惡意 OS 操作者並行換目錄的完整保證，執行目錄仍須 NTFS ACL 保護。C 的描述符固定可防路徑替換重新導向；實際 symlink／競態與 Windows junction 驗收受限，尚未全面驗證。腳本只設定全新 V3.1 目錄權限，沒有改動舊資料。

## 加密儲存

沿用每檔 AES-256-GCM、12-byte nonce、128-bit tag 及 owner/context AAD；每檔 key 用不同用途的 GCM3 封裝；關鍵字名稱使用另一用途的 GCM3，索引用 HMAC 綁定 owner/file/context/version/密文。C 系統主秘密與私鑰保留 IBEV3GCM/OpenSSL AES-256-GCM 認證加密。

本版只生成新的 root.key，透過 HMAC-SHA-256 分離用途。保留既有 envelope 與用途標籤是格式相容選擇，不代表重用 V3 金鑰。root.key 自身靠主機 ACL 與一致備份保護。缺失或認證失敗時拒絕，不自動重生。Java／WSL 以 stdin 傳送敏感資料，命令列不含金鑰或關鍵字，錯誤不回傳 C 敏感輸出。

檔名、檔案大小、帳號、擁有者與存取／相等模式仍可能外洩。私鑰／主秘密竄改與重啟需在可執行 WSL 的環境重跑，本次僅保留測試來源，沒有宣稱通過。

## 有界工作與配額

- 每來源位址每 60 秒最多 10 次登入嘗試，成功及失敗均計數，先於 BCrypt；不信任 X-Forwarded-For，最多保存 1024 個位址視窗。反向代理部署需另行設計可信來源政策，不宜共用一個位址直接對外。
- 每個帳號同時一個搜尋，跨帳號 C 程序最多兩個，排隊取得程序名額有上限；單次最多 512 個比對／10 秒，超限 422、逾時 504，不回部分結果。Linux timeout 與 Java 程序終止共同限制子程序；Windows/WSL 實際終止驗證待補。
- 每帳號最多 100 檔／200 MiB，可在安全上限內調低。上傳先對帳號列加悲觀鎖，再在同一交易檢查 count/sum；失敗回滾，刪除後自然釋放額度。配額不寫入帳號版本，避免正常上傳撤銷 Session。
- 列表與搜尋頁大小 1–25，預設 10；搜尋的每頁是候選檔案範圍。後台檔案及索引也分頁。檔案中繼資料／後台片段在資料庫內投影，不把全部檔案 payload 讀入 Java。

尚無 MFA、自助密碼重設、惡意檔案掃描、正式安全稽核、HSM、根金鑰輪替、多節點 Session、完整稽核監控或高負載驗證。預設只監聽 loopback；HTTPS 必須啟用 Secure Cookie。這些邊界不能因來源已修正就標為已驗證。

參考：[PBC 手冊](https://crypto.stanford.edu/pbc/manual.html)、[RFC 9380](https://www.rfc-editor.org/rfc/rfc9380.html)、[Spring CSRF](https://docs.spring.io/spring-security/reference/servlet/exploits/csrf.html)。

