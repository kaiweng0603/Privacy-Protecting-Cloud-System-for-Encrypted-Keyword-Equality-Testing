# V3.1 測試報告

日期：2026-11-15，Asia/Taipei。受測版本為本次獨立 V3.1 副本；F01 核心映射設計已先取得使用者明確確認。所有測試資料、root.key、帳號及資料庫都新建在 V3.1 的 .test-runs；沒有操作既有 V1/V2/V3 執行資料。

**結論：來源修正與部分實測已完成；全面驗收未通過。** 完整 Maven package 的退出碼為 1，不提供假通過或已驗證正式執行檔。

## 最終實際結果

本次正式記錄由 scripts/Run-Validation.ps1 -Offline 執行，原始作業開始／結束時間、exit code、受測來源 SHA-256 與去除秘密的 Surefire XML/TXT 保存在 evidence/。

| 工作 | exit code | 實際結果 |
| --- | --- | --- |
| C 真實編譯／回歸 | -1 | WSL E_ACCESSDENIED，make 未執行；HV3 固定向量、配對與 C 路徑回歸未驗證 |
| Java 安全元件與 H2 服務測試 | 0 | 13 tests：12 通過、0 failures、0 errors、1 skipped；時間見 XML |
| 完整 Maven package | 1 | 17 tests：13 通過、1 failure、2 errors、1 skipped；完整建置未通過 |
| Vue production build | 0 | Vite 8.1.1，258 modules，成功 |
| 修改範圍 ESLint | 0 | 無自動修檔；oxlint 插件提示缺少 .oxlintrc.json，不是 lint failure |
| PowerShell parser／封裝核對 | 見 evidence | 最終語法與來源 ZIP CRC／SHA-256 核對另有證據 |

完整 package 包含原 3 個 JUnit、V3.1 元件 13 個、另增 HTTP 1 個，沒有刪除原功能驗收。原 3 個中，危險環境拒絕測試通過；真實 Session/IBEET 測試在啟動 Tomcat 時遇到 Permission denied: connect；獨立程序初始化亦因 loopback 權限退出 1，故重新啟動流程未完成。新增 HTTP 測試遇到相同限制，並非已通過。

跳過的 1 項是 ancestorLinkRejected：環境拒絕建立 NTFS junction 測試夾具（子程序 exit 1）。保留 skipped 記錄，不計為路徑逃逸已驗證。

WSL 及 localhost 連線的提升權限要求均被目前自動核准規則拒絕，該規則停用了 sandbox_approval。本次沒有繞過拒絕，也沒有改全域設定或安裝系統套件。

## 已通過的範圍

- Tomcat 11.0.22 實際 multipart parser／DiskFileItemFactory：合成 keyword 欄位、檔案及 20 MiB 檔案都在記憶體；22 MiB 超限請求在讀取前拒絕。
- 上傳 admission filter：大小／未知長度拒絕；兩個並行工作佔滿後第三個回 503；例外與完成會釋放名額。這是過濾器元件測試，不冒充實際 HTTP 上傳測試。
- DataSource：替代 jdbc-url、環境變數別名、DataSource class、JNDI、JPA 連線屬性及額外 H2 INIT 被拒絕；不一致的最終 Hikari 設定在連線前失敗；合成目標目錄零資料庫檔案。
- Java 路徑：非執行範圍、dot 跳脫、錯誤專案根目錄拒絕；實際 NTFS junction 測試未驗。
- 搜尋：每帳號並行拒絕、Bob 不被 Alice 的帳號鎖擋住、比對次數上限、逾時與釋放；真實 C 程序的計時／終止尚未驗。
- 登入節流：包含編碼路徑的相同節流及 HEAD 下載名額驗證；10 次／60 秒、視窗恢復與最多 1024 個來源記錄；真實登入 HTTP 整合尚未驗。
- UTF-8、500-byte／控制字元／無效 surrogate 與分頁大小邊界。
- 真實 H2/JPA 及原 FileEncryptionService：合成 Alice/Bob 使用未設關鍵字的合法檔案上傳，實際 AES-GCM 儲存及下載還原；檔案數／byte 配額、交易回滾、刪檔釋放額度、跨 owner 拒絕、列表分頁、後台密文片段 SQL 投影均通過。這個測試不使用任何假 IBEET；它沒有呼叫 IBEET，也不被列為 IBEET 通過。

## 已新增但尚未完成執行的測試

- CSIE_project/tests/hash_v3_vectors.c：固定完整輸入編碼向量、84-byte／500-byte／UTF-8、invalid UTF-8、V1/V2 原映射語意。
- scripts/crypto_regression.py：保留原 8 組覆蓋並增加 HV3 真實 encrypt/match/decrypt、長共同前綴、祖先連結及 dot 跳脫零寫入。V2 已知碰撞另作歷史風險重現，不宣稱舊版安全通過。
- IbeetApplicationTests：原 30 組 HTTP 邏輯保留，調整為新目錄／Cookie／分頁後，加上 HV3 長詞配對回歸；既有私鑰／主秘密竄改、AAD、交易、帳號撤銷及重新啟動仍保留。
- V31HttpAcceptanceTests：真實 HTTP Session、上下載、雙帳號隔離、配額／刪除釋放、列表／後台分頁及 multipart-unused 零檔案。

## 開發期間的失敗與修正

沒有沿用 V3 報告的全數通過聲稱。首次元件回歸發現 Hibernate 不接受對 CLOB 套用 HQL substring，已改成在 H2 端做有界 SQL 片段投影並以真實資料驗證；上傳測試夾具的 Content-Length 模擬亦已修正。非 web 服務測試初期缺少 PasswordEncoder，已將 cost 12 的 BCrypt bean 獨立為 CredentialConfig。這些早期失敗輸出保留在 evidence，最終通過記錄獨立保存。

一般編譯仍有 deprecated／test unchecked 提示；沒有隱藏成零警告。前端 build 未做瀏覽器畫面或下載儲存操作驗收。沒有進行真實資料遷移、正式互動初始化、完整 20 分鐘等待、負載／慢速上傳／備援還原及 HTTPS 驗證。

## 重跑與放行條件

在具備合法 WSL 與 localhost 權限的環境，以全新 IBEET-Cloud-V3.1 目錄執行：

```powershell
.\scripts\Build-V3.ps1 -InstallFrontendDependencies
.\scripts\Run-Validation.ps1
```

不得略過失敗測試再宣稱 package 通過。所有 C 固定向量、真實配對、完整 17 tests（含 junction）、HTTP multipart 暫存監測、重新啟動及 ACL 檢查通過後，才能評估本機展示；正式使用仍需獨立安全稽核。沒有讀取 V1/V2/V3 真實資料作為拒絕測試目標。



